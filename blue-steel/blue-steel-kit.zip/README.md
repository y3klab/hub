# Blue Steel - a theme + status bar for Claude Code

A really, really, ridiculously good-looking terminal. For
[Claude Code](https://claude.com/claude-code):

- **Status bar** - your project name swept in a magenta→cyan gradient, plus
  live gauges: context-window %, 5-hour and 7-day rate-limit % (they color
  green→amber→red as they fill), session time, and the active model.
- **Pinned** - the bar stays at the bottom of the terminal while the
  conversation scrolls above it.
- **Blue Steel theme** - a dark theme to match, including a steel-blue
  background tint behind your own messages.

## Install

### One command

This does everything below for you (it announces every file it touches and
backs up your settings first):

```sh
curl -fsSL https://y3klab.com/blue-steel/install.sh | bash
```

### By hand

You need the two files that came with this README: `statusline.sh` and
`blue-steel.json`. Copy them into place:

```sh
mkdir -p ~/.claude/themes
cp statusline.sh ~/.claude/statusline.sh
chmod +x ~/.claude/statusline.sh
cp blue-steel.json ~/.claude/themes/blue-steel.json
```

Merge this into `~/.claude/settings.json` (create the file if it doesn't
exist):

```json
{
  "statusLine": {
    "type": "command",
    "command": "~/.claude/statusline.sh"
  },
  "tui": "fullscreen",
  "theme": "custom:blue-steel"
}
```

Restart Claude Code. Done - the bar fills in as the session runs.

## Update

Updating is the install command, run again - it fetches the latest files
over the old ones and leaves your settings alone:

```sh
curl -fsSL https://y3klab.com/blue-steel/install.sh | bash
```

Installed by hand? Same idea: grab the current kit from
https://y3klab.com/blue-steel/ and re-copy the two files - they're the only
things that change.

## Uninstall

Everything this kit touches is the two files you copied and the three
settings keys - nothing else. One command removes all of it:

```sh
curl -fsSL https://y3klab.com/blue-steel/install.sh | bash -s -- --uninstall
```

Or by hand: delete `~/.claude/statusline.sh` and
`~/.claude/themes/blue-steel.json`, then remove the `"statusLine"`, `"tui"`,
and `"theme"` lines from `~/.claude/settings.json`. Restart Claude Code and
you're back to stock.

## Notes

- The gauges need `jq` to parse Claude's status JSON. macOS 15+ ships it
  built-in; on anything older, `brew install jq`. Without it you still get
  the gradient project name, just no meters.
- Custom themes need Claude Code v2.1.118 or later (any current install).
- Gauges appear as their values exist - a fresh session starts with just the
  name and fills in as you go.
- Prefer the bar to ride along with the conversation instead of staying
  pinned at the bottom? Delete the `"tui"` line.
