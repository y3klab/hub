<!-- Best viewed in a monospace font (terminal, editor, or GitHub). -->

```
 ▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁
 ░▒▓█▌                                                    ▐█▓▒░

    ╔═╗ ╦═╗ ╔═╗  ╦  ╔═╗ ╔═╗ ╔╦╗ ╔═╗
    ╠═╝ ╠╦╝ ║ ║  ║  ╠═  ║    ║  ╚═╗
    ╩   ╩╚═ ╚═╝ ╚╝  ╚═╝ ╚═╝  ╩  ╚═╝
         ╔═╗ ╦ ╦ ╔═╗ ╔╦╗ ╔═╗ ╔╦╗
         ╚═╗ ╚╦╝ ╚═╗  ║  ╠═  ║║║
         ╚═╝  ╩  ╚═╝  ╩  ╚═╝ ╩ ╩

 ░▒▓█▌   a tiny operating system for your projects       ▐█▓▒░
 ▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔
        rev 1  ·  pure bash  ·  zero daemons  ·  install ▸ go
```

You were handed a **zip**. Nice. Inside is a complete little system for
running a personal project portfolio from the command line — spin up
projects, shelve them, archive them, and keep one tidy index of it all.

It's **yours the moment you unzip it**: no account, no telemetry, nothing
personal of the author's baked in. Pure bash. ~5 minutes. Let's boot it.

## ✦ EASIEST: just double-click

Open the unzipped folder and **double-click `Double-Click to Install.command`**.
Terminal opens, it moves itself to `~/project-system`, runs the installer, and
drops you into a ready shell — then type `newproject`.

> **If macOS blocks it** ("could not verify it is free of malware", offering
> only *Move to Trash* / *Done*): click **Done**, then open **System Settings →
> Privacy & Security**, scroll down to *Security*, and click **Open Anyway**.
> Double-click the installer again and confirm. You only do this once — macOS
> just wants you to confirm you trust a script you downloaded.
> *(Or skip the dialog entirely: run `bash "Double-Click to Install.command"`
> in Terminal from the unzipped folder.)*

Prefer the terminal (or want to preview first)? The three manual moves are below.

```
 ┌─[ SYSTEM REQUIREMENTS ]──────────────────────────────────────
 │
 │   ▸ git ................. required (the engine under the hood)
 │   ▸ Claude Code ........ for the slash commands (/setup-project,
 │                          /grill, /init-claude-md, /architect)
 │   ▸ gh (GitHub CLI) .... OPTIONAL — only to auto-create remotes;
 │                          skip it and paste any clone URL by hand
 │   ▸ a zsh-ish shell .... bash works too; the aliases target zsh
 │
 └──────────────────────────────────────────────────────────────
```

## ▸ INSTALL  —  three moves

```sh
# 1 ▸ UNPACK  ──  it lands as a ready-to-use git repo
unzip project-system.zip -d ~

# 2 ▸ RUN THE INSTALLER  ──  it checks your tools, links the slash commands,
#     seeds your LEXICON, creates the ~/Projects workspace, and offers to
#     wire the aliases into your ~/.zshrc — all in one animated pass
~/project-system/install.sh

# 3 ▸ RELOAD  ──  pick up the new aliases
exec zsh
```

That's the whole install. The installer does the heavy lifting — just answer
its one or two prompts. It announces every path it touches and never modifies
anything outside them. `█`

Cautious? **Preview every change first, writing nothing:**

```sh
~/project-system/install.sh --dry-run
```

## ✦ MAKE IT YOURS

```
 ┌─[ LEXICON ]──────────────────────────────────────────────────
 │
 │   install.sh seeded  LEXICON.md  from a generic example:
 │   placeholders to replace, plus the system's own vocabulary
 │   (FSDN — keep that one). It's your personal cross-project
 │   vocabulary — the brands, acronyms, and coined words you
 │   reuse everywhere, each with its canonical spelling. Edit it:
 │
 │       $ open ~/project-system/LEXICON.md     # or your editor
 │
 │   New projects seed their own GLOSSARY.md from any term that
 │   shows up in them, and offer to promote new cross-project terms
 │   back. It's gitignored — it's YOURS; updates never clobber it.
 │
 └──────────────────────────────────────────────────────────────
```

Nothing else needs customizing. The system doesn't touch your git config,
SSH keys, or shell prompt — it rides whatever you already have.

## ▸ FIRST CONTACT

```sh
newproject     # interactive — names it, describes it, registers it
importproject  # interactive — adopt an EXISTING folder or git repo
```

`newproject` registers your first project in `~/Projects/Active/`: it asks for a
title and one line about what the thing is, writes the few files a project always
carries, and pre-trusts it so Claude Code opens it without asking. That's a
finished project - it shows on the dashboard (the dashboard reads the workspace,
so it cannot miss one) and you can start working in it. It then *offers* to hand
off to Claude Code for a fuller setup, and no is a perfectly good answer.

Already have project folders? `importproject` is the adoption on-ramp: point
it at a folder (or paste a git URL) and it brings it into `Active/`, indexes it,
and commits — non-destructively (nothing inside your folder is ever written) and
fast, with the fuller Claude setup *offered* afterward. Go build.

## ✦ WHAT YOU JUST INSTALLED

```
   Active/     engaged now — building or using (shown)
   Inactive/   dormant but alive — paused, placeholder, will-resume (shown)
   Archive/    finished work, kept to read later — year-prefixed, hidden
```

A handful of commands drive it all:

```
   newproject ......... spin up a new active project
   importproject ...... adopt an existing folder or git repo into Active
   proj  /  projects .. browse with arrow keys, Enter to open (launches Claude),
                        m to move/delete · n new · i import · a Archive
   audit-backups ...... which projects have no off-machine backup?
```

Moving a project — deactivate / activate / archive / unarchive / delete — all
happens from the `proj` dashboard: arrow to a project (or type its number) and
press `m`, then pick a destination. There are no transition commands to memorise.

Want the *why* behind the design? Read **`CONVENTIONS.md`** — the system's
principles. Want the deeper adopter notes (and the two ways to adopt)? See
**`SETUP.md`**.

## ▸ UPDATING

Grab the newest zip and lay it over your install. One file in here is *yours*
and must survive the update: **`LEXICON.md`** (your vocabulary). Your workspace
overview (`~/Projects/projects.md`) lives outside this folder and is never
touched by an update. This preserves what needs preserving:

```sh
unzip -q ~/Downloads/project-system.zip -d /tmp/ps-update
rsync -a --exclude LEXICON.md \
  /tmp/ps-update/project-system/ ~/project-system/
xattr -dr com.apple.quarantine ~/project-system 2>/dev/null  # downloaded files carry it
~/project-system/install.sh    # idempotent — relinks anything that moved
rm -rf /tmp/ps-update
```

(Installed by `git clone` instead? `git pull` is the whole update.)

```
 ┌─[ done ]──────────────────────────────────────────────────────
 │
 │   ▸  type  newproject  and make something.
 │
 │              ░▒▓ have fun out there ▓▒░   — the management
 │
 └──────────────────────────────────────────────────────────────
```
