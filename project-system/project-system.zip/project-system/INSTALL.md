<!-- Best viewed in a monospace font (terminal, editor, or GitHub). -->

```
 ▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁
 ░▒▓█▌                                                    ▐█▓▒░

    ╔═╗ ╦═╗ ╔═╗  ╦  ╔═╗ ╔═╗ ╔╦╗ ╔═╗
    ╠═╝ ╠╦╝ ║ ║  ║  ╠═  ║    ║  ╚═╗
    ╩   ╩╚═ ╚═╝ ╚╝  ╚═╝ ╚═╝  ╩  ╚═╝
         ╔═╗ ╦ ╦ ╔═╗ ╔╦╗ ╔═╗ ╔╦╗
         ╚═╗ ╚╦╝ ╚═╗  ║  ╠═  ║║║
         ╚═╝  ╩  ╚═╝  ╩  ╚═╝ ╩ ╩

 ░▒▓█▌   a tiny operating system for your projects       ▐█▓▒░
 ▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔
        rev 1  ·  pure bash  ·  zero daemons  ·  install ▸ go
```

You were handed a **zip**. Nice. Inside is a complete little system for
running a personal project portfolio from the command line — spin up
projects, shelve them, archive them, and keep one tidy index of it all.

It's **yours the moment you unzip it**: no account, no telemetry, nothing
personal of the author's baked in. Pure bash. ~5 minutes. Let's boot it.

## ✦ EASIEST: just double-click

Open the unzipped folder and **double-click `Double-Click to Install.command`**.
Terminal opens, it moves itself to `~/project-system`, runs the installer, and
drops you into a ready shell — then type `newproject`.

> **If macOS blocks it** ("unidentified developer" / "cannot be opened"),
> **right-click the file → Open → Open.** You only do this once — macOS just
> wants you to confirm you trust a script you downloaded.

Prefer the terminal (or want to preview first)? The three manual moves are below.

```
 ┌─[ SYSTEM REQUIREMENTS ]──────────────────────────────────────
 │
 │   ▸ git ................. required (the engine under the hood)
 │   ▸ Claude Code ........ for the slash commands (/setup-project,
 │                          /grill, /init-claude-md, /architect)
 │   ▸ gh (GitHub CLI) .... OPTIONAL — only to auto-create remotes;
 │                          skip it and paste any clone URL by hand
 │   ▸ a zsh-ish shell .... bash works too; the aliases target zsh
 │
 └──────────────────────────────────────────────────────────────
```

## ▸ INSTALL  —  three moves

```sh
# 1 ▸ UNPACK  ──  it lands as a ready-to-use git repo
unzip project-system.zip -d ~

# 2 ▸ RUN THE INSTALLER  ──  it checks your tools, links the slash commands,
#     seeds your LEXICON, creates the ~/Projects workspace, and offers to
#     wire the aliases into your ~/.zshrc — all in one animated pass
~/project-system/install.sh

# 3 ▸ RELOAD  ──  pick up the new aliases
exec zsh
```

That's the whole install. The installer does the heavy lifting — just answer
its one or two prompts. It announces every path it touches and never modifies
anything outside them. `█`

Cautious? **Preview every change first, writing nothing:**

```sh
~/project-system/install.sh --dry-run
```

## ✦ MAKE IT YOURS

```
 ┌─[ LEXICON ]──────────────────────────────────────────────────
 │
 │   install.sh seeded  LEXICON.md  from a generic example with
 │   placeholder terms. It's your personal cross-project vocabulary
 │   — the brands, acronyms, and coined words you reuse everywhere,
 │   each with its canonical spelling. Edit it directly:
 │
 │       $ open ~/project-system/LEXICON.md     # or your editor
 │
 │   New projects seed their own GLOSSARY.md from any term that
 │   shows up in them, and offer to promote new cross-project terms
 │   back. It's gitignored — it's YOURS; updates never clobber it.
 │
 └──────────────────────────────────────────────────────────────
```

Nothing else needs customizing. The system doesn't touch your git config,
SSH keys, or shell prompt — it rides whatever you already have.

## ▸ FIRST CONTACT

```sh
newproject     # interactive — names it, scaffolds it, opens Claude
importproject  # interactive — adopt an EXISTING folder or git repo
```

`newproject` spins up your first project in `~/Projects/Active/`, drops in a
starter scaffold, records it in the master `INDEX.md`, and hands off to
Claude Code to help you define what the thing actually is.

Already have project folders? `importproject` is the adoption on-ramp: point
it at a folder (or paste a git URL) and it copies/clones it into `Active/`,
indexes it, and commits — non-destructively (your original is never touched)
and fast, with the full Claude setup *offered* afterward. Go build.

## ✦ WHAT YOU JUST INSTALLED

```
   Active/     engaged now — building or using (shown)
   Inactive/   dormant but alive — paused, placeholder, will-resume (shown)
   Archive/    finished work, kept to read later — year-prefixed, hidden
```

A handful of commands drive it all:

```
   newproject ......... spin up a new active project
   importproject ...... adopt an existing folder or git repo into Active
   proj  /  projects .. browse with arrow keys, Enter to open (launches Claude),
                        m to move/delete · n new · i import · a Archive
   audit-backups ...... which projects have no off-machine backup?
```

Moving a project — deactivate / activate / archive / unarchive / delete — all
happens from the `proj` dashboard: arrow to a project (or type its number) and
press `m`, then pick a destination. There are no transition commands to memorise.

Want the *why* behind the design? Read **`CONVENTIONS.md`** — the system's
principles. Want the deeper adopter notes (and the two ways to adopt)? See
**`SETUP.md`**.

```
 ┌─[ done ]──────────────────────────────────────────────────────
 │
 │   ▸  type  newproject  and make something.
 │
 │              ░▒▓ have fun out there ▓▒░   — the management
 │
 └──────────────────────────────────────────────────────────────
```
