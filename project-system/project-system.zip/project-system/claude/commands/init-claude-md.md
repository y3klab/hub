---
description: Re-populate CLAUDE.md from current project state. Use after adding a stack, scaffolding directories, or any change that puts CLAUDE.md out of sync.
---

Re-populate the project's `CLAUDE.md` from current repo state. Use this when the project has evolved (added a stack, scaffolded directories, established commands, surfaced conventions) and the file no longer reflects reality.

## Posture

- **Generate structure, don't fill a template.** Each section is present only if it has real content for *this* project right now. The `_template/CLAUDE.md` is a menu, not a mandate.
- **Read first, change later.** Read the current `CLAUDE.md` AND the project state before proposing edits.
- **Audit before claiming done.** Cross-check against `~/.claude/CLAUDE.md` and the system prompt; state what was checked.

## Step 1 — Read

**Project state:**
- Current `CLAUDE.md` — see what's already captured
- `package.json` / `pyproject.toml` / `go.mod` / `Cargo.toml` / `Gemfile` — stack signals
- `.system/project.md` — project title (H1) + a short description (body, drafted by `/setup-project`'s Phase 0) + the started date (frontmatter). This is the canonical orientation source for the project's intent.
- Top-level directory layout (`ls -la`) — for Structure
- `Makefile`, `package.json` scripts, `justfile` — for Commands
- `<project-name>.md` at project root if it exists — the project overview (Claude's synthesis, named after the project folder)
- Recent commits (`git log --oneline -20`) — what's active

**Shape references:**
- **Canonical spec:** `AUTHORING.md` § "`CLAUDE.md` — the section menu" — it defines every section and how to author it (shared with `/setup-project`).
- **In-house examples:** read a couple of existing managed `CLAUDE.md` files in `~/Projects/Active/` (and `~/Projects/Archive/`) that match this project's kind — the workspace's own mature CLAUDE.mds are the pattern library.

**Related projects:** scan `~/Projects/Active/` and `~/Projects/Archive/` for projects with overlapping scope or naming. If one exists, read its CLAUDE.md — its conventions may inform this project's.

Pattern updates on the section menu + those examples; adapt for THIS project's specifics.

## Step 2 — Diff against reality

Identify what `CLAUDE.md` is missing, stale on, or no longer reflects. Common patterns:
- Stack was added since last populate → add Stack and Commands sections
- Scaffolded `src/` and `tests/` directories → Structure now warrants real content
- Established conventions in the overview or via code review → Conventions section earns entries
- Captured a "Claude made the same mistake twice" → Don't section earns the entry

**If nothing has changed since last populate**, say so and stop — don't make changes just to make changes.

## Step 3 — Generate updates

Pattern on the references you read in Step 1.

**The section-by-section spec is canonical in `AUTHORING.md` § "`CLAUDE.md` — the section menu" — read it before updating.** It defines every section and how to author it: Status, Project, Identifiers, Open Decisions (+ `locked-open` semantics), Stack (no-limbo), Structure (two modes + name-don't-materialize, README opt-in), Router table, Commands, Conventions, Don't, Related projects, Claude Code tooling — plus the two cross-cutting rules (no "Working Agreement" summary layer; length follows substance, no `<placeholder>`). That menu is shared with `/setup-project`; don't re-inline it here.

What follows is only what's specific to **re-syncing an evolved project**:

- **Update, don't regenerate.** Touch only the sections whose backing reality changed (the Step 2 diff). Project and Status are usually already right — leave correct sections alone, and remove any section that no longer has content.
- **An evolved project is exactly when Identifiers and a Router table become populatable** — and these are the two sections most likely to be *addable* on a re-sync that weren't at intake. A repo URL / deployed URL / infra IDs now exist → add the **Identifiers** block. 3+ supporting docs now exist → add the **Router table**. (These were the historical drift gap: this command used to omit both.)
- **Drop bookkeeping from Structure once project-specific dirs have emerged** — an early-stage project listed its full file inventory; once `src/` / `packages/` / `templates/` etc. exist, switch to sketching those and stop listing `PLAN.md` / `DECISIONS.md` / etc.
- **Propose each Conventions/Don't candidate one at a time before writing** — a convention surfaced from code review or the overview gets proposed, not silently written. (No scripted shortcut line is needed outside `/setup-project`'s greenfield interview — a one-at-a-time conversational proposal is enough here.)

## Step 4 — Content-level audit

Before claiming done, verify and **state plainly what you checked**:
- No `<placeholder>` text remains
- No restatement of rules already in `~/.claude/CLAUDE.md` or the system prompt
- No auto-listing of bookkeeping files in Structure (unless this is an early-stage project with no project-specific dirs yet — then listing the inventory IS the Structure)
- **Open Decisions ↔ PLAN.md ↔ CHECKLIST.md alignment:** every Open Decision has a phase tag; Phase 1 decisions appear as tasks in CHECKLIST.md Phase 1; decisions tagged for later phases don't appear in Phase 1's checklist. **Each Open Decision must appear as an explicit decision-deliverable task in its tagged PLAN phase.**
- **Stack ↔ DECISIONS.md alignment:** committed and default-yes carried-forward Stack items have corresponding DECISIONS.md entries. No Stack item in "proposed without resolution path" limbo.
- **PLAN ↔ CHECKLIST task order alignment:** within each phase, the task order in CHECKLIST.md mirrors PLAN.md. If they disagree, update PLAN (CHECKLIST tends to be the more accurate document — that's where execution lives).
- **Phase name consistency:** the same phase name appears in CLAUDE.md Status, CLAUDE.md Open Decisions phase tags, PLAN.md headers, CHECKLIST.md headers, and CHECKLIST.md closeout tasks — verbatim. PLAN.md is the canonical source.
- **Concrete details preservation:** hardware specs, version pins, vendor IDs, exact requirements in source materials should appear in CLAUDE.md (Stack/Conventions) — synthesis organizes data; it doesn't lose it.
- Sections present have real, non-trivial content; empty sections removed
- The diff reflects actual change in project state, not whitespace churn
- **Cross-reference jargon hygiene:** if a section uses a term defined in a later section, either reorder or gloss it on first use

## Step 5 — Show and confirm

Show the user the diff (or the final file if small). Do NOT auto-commit. Wait for review.

## Out of scope

- Do not modify `CLAUDE.local.md` — personal scratch.
- Do not modify `~/project-system/_template/CLAUDE.md`.
- Do not commit changes.
