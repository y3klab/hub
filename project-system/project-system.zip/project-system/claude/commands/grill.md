---
description: Relentlessly interview the user about a plan or design — one question at a time, walking the decision tree — sharpening project language into GLOSSARY.md and recording hard-to-reverse choices in DECISIONS.md as they crystallize. Self-contained; reconciles to project-system conventions.
---

You are running a **grill pass** on the current project's plan or design. This is a project-system command — it is fully self-contained and does not depend on any external skill. It reconciles its outputs to *this* system's conventions: a glossary lives in `GLOSSARY.md`, decisions live in `DECISIONS.md`.

`/setup-project` reuses this same discipline as its **Phase 0** — a bounded, always-entered grill at project inception that defines what a fresh project is before scaffolding. The rules here (one question at a time, the "When to stop" test, pin-terms-in-conversation, the closing glossary sweep) apply there too, just scoped tighter to a brand-new project.

## Orient first — the decision tree is already written

Before asking anything, **read the project's own files** — the system has usually pre-enumerated the tree you're about to walk:

- **`CLAUDE.md` → `Open Decisions`** — this is your agenda. Each entry is a `locked-open` decision, phase-tagged (`(Phase 1)`, `(Phase 2)`, …). The current phase's open decisions are the branches to walk *this* pass; later-phase ones are out of scope unless the user pulls them forward.
- **`<project-name>.md`** (the project overview) — what this is, success criteria, unknowns.
- **`GLOSSARY.md`** — the glossary you'll challenge against and extend (it usually already exists — see below).
- **`PLAN.md`** — the phase the project is in, and the decision-deliverable tasks in it.
- **`<project-name>.md` / `CLAUDE.md` Status** — the project kind (planning / code / docs / operational), inferred from the overview and whether code exists. This shapes how you cross-reference (see "Cross-reference against the project's sources").

If `CLAUDE.md` has no `Open Decisions` section, fall back to discovering the tree by interview — but check first. Don't walk in blind when the agenda is sitting in `CLAUDE.md`.

## What to do

Interview the user relentlessly about the open decisions until each branch is resolved. Walk dependencies in order. For each, **provide your recommended answer** — don't just ask, propose.

- **Ask one question at a time.** Wait for the answer before the next. No numbered batteries of questions.
- **Respect `locked-open`.** A decision tagged `locked-open` in `CLAUDE.md` closes **only on the user's explicit confirmation** — never by inference, and never via "propose-and-proceed." Propose your recommendation and make the case, but the branch stays open until the user actually picks. This is the one place "propose, don't just ask" yields to a firmer system rule.
- **If a question can be answered from the project's sources, look instead of asking.** Read the code / `references/` / overview, then report what you found rather than making the user recite it.
- **Walk dependencies in order.** When decision B only makes sense after A is settled, settle A first. Surface the dependency out loud ("this hinges on the X we just decided").

## During the session

### Challenge against the glossary
If `GLOSSARY.md` exists and the user uses a term that conflicts with its definition, call it out immediately: *"`GLOSSARY.md` defines 'the friend' as the new adopter, but you seem to mean David here — which is it?"*

### Sharpen fuzzy language
When the user uses a vague or overloaded term, propose a precise canonical one: *"You're saying 'customize' — do you mean rewrite the file, or override a value in it? Those are different operations."* Pin the winner; note the rejected synonyms under `_Avoid_`.

### Discuss concrete scenarios
Stress-test relationships with specific invented scenarios that probe edge cases and force precision about the boundaries between concepts.

### Cross-reference against the project's sources
When the user states how something works, check whether the project's own material agrees, and surface contradictions. *What* you cross-reference against depends on the project kind (infer it from the overview, `CLAUDE.md`, and whether code exists):
- **code project** → the code. *"Your `customize.sh` rewrites both repos, but you just said it only touches `dotfiles` — which is right?"*
- **planning / docs / operational** → `references/`, the overview, and prior `DECISIONS.md`. *"The brief says single-pass, but this plan implies a second manual step — reconcile?"*

This step doubles as any survey/enumeration the current phase needs — let it produce the inventory as a side effect.

## Update the docs inline (the half that makes this "with-docs")

Capture decisions as they happen — don't batch them to the end.

### Resolved terms → `GLOSSARY.md` (and cross-project terms → `LEXICON.md`)
When a term is pinned, write it to `GLOSSARY.md` right then. **`GLOSSARY.md` usually already exists** — `/setup-project` seeds it from your personal `LEXICON.md` (any cross-project term that actually appears in the project) plus any terms that settled during Phase 0, so you're almost always *extending* it, not creating it. Only create it fresh if the project somehow has none (term-less at setup); in that case create it lazily, once the first term resolves — don't pre-create an empty glossary. `GLOSSARY.md` is **glossary-only — totally devoid of implementation detail.** It is not a spec, a scratch pad, or a decision log. Define what a term *is*, not what it does.

**Promote cross-project terms back to the lexicon.** When a term you just pinned into `GLOSSARY.md` is one you'll reuse *across* projects — a brand, a recurring acronym, a product/feature name, a coined term not specific to this one project — offer to add it to `~/project-system/LEXICON.md` so future projects seed it automatically: *"Add **<term>** to your lexicon so future projects seed it? [Y/n]"* — default **Yes** for a clear cross-project term, **never silent**, and **never offered for a project-specific term**. On yes, append it to `LEXICON.md` in the same `**Term**:` / `_Avoid_:` shape (dedupe; reconcile if it's already there) — and set its **visibility**: append with **no `_Visibility_` line** for the usual case (private — a client, company, or personal-venture name; private is the default), or add a **`_Visibility_: public`** line if the term is safe to appear in shared/published work (a product brand you ship). Propose the visibility alongside the offer and confirm in one breath; **default to private when unsure** — that's the safe direction, since the shareable-release guard scans every *private* lexicon term, so mislabeling something public is a loud, fixable false-positive rather than a silent leak. This is the pull/promote loop: projects seed *from* the lexicon and push new shared terms *back* to it.

Rules:
- **Only project-specific terms.** General programming concepts (timeouts, error types, utility patterns) don't belong even if the project uses them heavily. Test before adding: unique to this project, or general? Only the former.
- **Be opinionated, and capture the wrong forms.** When several words exist for one concept, pick the canonical one; list the rest under `_Avoid_`. **`_Avoid_` holds every form to correct *to* the term** — wrong casings, common misspellings, spacing errors, deprecated synonyms — so the glossary doubles as an autocorrect/consistency source (and stays machine-readable for other skills to consume).
- **Keep definitions tight** — one or two sentences.

Format:

```md
# <Project Title>

{1-2 sentence description of what this glossary is.}

## Language

**Term**:
One or two sentence definition — what it IS, not what it does.
_Avoid_: wrong-casing, common-misspelling, rejected-synonym
```

(This is the same `GLOSSARY.md` format `AUTHORING.md` defines canonically and `/setup-project` points at — keep them identical.)

### Resolved decisions → `DECISIONS.md` (and the write-back the close requires)
When a decision crystallizes — **after the user explicitly confirms it, if it was `locked-open`** — record it. But closing a decision isn't a one-file write: a resolved open decision has to propagate, or the project drifts. Do all of:

1. **Record it in `DECISIONS.md`** — the single decision record (no separate file or folder).
2. **Update `CLAUDE.md`'s `Open Decisions`** — remove the now-resolved entry (or mark it resolved). Leaving a closed decision sitting in `Open Decisions` is exactly the drift the system fights.
3. **Note what it unblocks** — if the decision settles a `Stack` or `Structure` item that was deferred to it, surface that so it gets filled in. (You may make the edit or flag it, but don't let it silently lag.)

This is the grill's core job in this system — it's why the command writes back to more than just `DECISIONS.md`.

**Only record a decision when all three are true** (the same bar `DECISIONS.md` uses everywhere):
1. **Hard to reverse** — the cost of changing your mind later is meaningful.
2. **Surprising without context** — a future reader will wonder "why did they do it this way?"
3. **The result of a real trade-off** — there were genuine alternatives and you picked one for specific reasons.

If any is missing, skip the entry — it'll get reversed cheaply, nobody will wonder, or there was no alternative to record. (Resolving a `locked-open` decision almost always clears this bar; a passing remark in conversation usually doesn't.) Offer entries sparingly.

Use the existing `DECISIONS.md` format — `## YYYY-MM-DD: <title>` followed by Context / Options / Chose / Reasoning — and add a reconsideration trigger when one exists (`Revisit if:` for condition-based, `Revisit:` for a scheduled future task). Don't invent triggers for forever-locked decisions.

## Reconciliation summary (why this command, not the external skill)

This command deliberately keeps the *value* of the grill-with-docs technique while speaking project-system's native conventions:
- **Glossary** → `GLOSSARY.md` at project root (not a per-context map).
- **Decisions** → `DECISIONS.md` entries (the single decision record).
- **A resolved decision also updates `CLAUDE.md`'s `Open Decisions`** (remove the closed entry) and unblocks any `Stack`/`Structure` that was waiting on it — closing a decision without this is drift.
- `PLAN.md` / `CHECKLIST.md` phase bookkeeping is otherwise left to the normal session workflow — except that a *still-open* branch becomes a decision-deliverable task in its tagged phase (see Wrap up).

## When to stop

"Relentless" means *thorough*, not *endless*. Before asking each new question, apply this test: **would the answer change a decision, a definition, or the plan?** If not, don't ask it.

- **Stop when every branch of the decision tree is resolved** and no remaining question would change an output. The tree — not a feeling of "shared understanding" — is the finish line: it's enumerable, so you can tell when it's covered.
- **Don't manufacture questions to prolong the session.** A short grill that resolves everything is a *complete* grill, not a lazy one. Resist inventing marginal questions just to keep going.
- **A genuinely-open branch isn't a reason to keep drilling.** If a decision can't be resolved now (missing info, depends on something external, user wants to defer), note it as open and move on — surface it in the wrap-up rather than forcing a premature answer.

## Wrap up

When the decision tree is walked and shared understanding is reached, summarize:
- **Terms** pinned to `GLOSSARY.md` — and confirm the captured set with the user in one closing pass (*"Here's the vocabulary I captured: X, Y, Z — that right?"*). Do this only if terms actually surfaced; skip it when nothing was pinned beyond a pre-seeded brand (don't manufacture a confirmation).
- **Decisions** that landed in `DECISIONS.md`, plus the `CLAUDE.md` `Open Decisions` entries they cleared and any `Stack`/`Structure` they unblocked.
- **Still-open branches** — for each, ensure it lives as a **decision-deliverable task in its tagged phase in `PLAN.md`** (the system's rule: an open decision is a first-class phase task, not an implied side-quest), so the next pass or that phase picks it up. Don't force a premature answer just to close it.
