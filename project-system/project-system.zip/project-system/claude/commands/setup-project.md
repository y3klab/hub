---
description: Expert project intake, two modes (auto-detected via the `.system/project.md` `state:` marker). Greenfield (a freshly-spawned `newproject`): reads source materials, runs a Phase 0 grill, generates tailored project files. Adopt (an existing/imported project): non-destructively fills only the missing baseline docs — never overwriting what's already there — then offers `/grill`.
---

You are setting up a project into the system, in one of two modes: **greenfield** (freshly spawned by `newproject`) or **adopt** (a project that already exists — imported, or set up before). **Step 0 detects which — read it first.** Steps 1–10 below are the *greenfield* path; **adopt** is a distinct, compact path in "Adopt mode (existing projects)" near the end.

Greenfield: source materials (briefs, requirements docs, transcripts, scripts, prior-art folders) are pre-copied into the project's `references/` directory by `newproject.sh` — including multi-file or directory drops. Read what's there during orientation.

Your role: act as the senior project-setup expert the user hired. Read what's there, understand the project, ask only what you don't already know, then produce a professional starting point.

## Posture (read this first)

- **Read first, ask later.** Always read all available material — `.system/project.md` (title; the description is a placeholder you'll draft), and any source materials — before forming questions.
- **Orient with the Read tool and simple commands, not compound shell.** Use Read/Glob for files; if you need Bash, keep it to one plain command (`ls -la`), never `&&`/`;` chains or `echo` headers. On a fresh install with default permissions, a compound one-liner greets the user with a "cannot be statically analyzed" permission wall as their very first Claude Code experience; simple reads keep first contact calm.
- **Propose with reasoning. Proceed by default.** Only ask when there's no defensible default OR when external state is involved (e.g., connecting or creating a git remote).
- **Ask only what you don't already know.** If the source materials answer a question, don't ask it.
- **"I don't know" / "you decide" → proceed with your best inference.** Never re-ask the same question.
- **Conventions and Don't entries are the exception to "proceed by default."** These are project rules that depend on context you don't have — decisions made by the user/team, knowledge about people involved, ground-truth answers to ambiguities. Propose each candidate entry one at a time and wait for the user's response. Watch for the *"convention vs. question"* trap: if you spotted an unknown in the source (a discrepancy, ambiguity, missing info), don't reflexively turn it into a "verify-before-X" convention. *Ask the user directly* — they may have the answer right now, and then the convention isn't needed at all.
- **Conversational throughout — no numbered menus for open-ended questions.** Exception: the Conventions / Don't per-entry review is a fixed 3-way choice repeated many times in a row; that one uses a `[1] confirm [2] change [3] reject` shortcut line. See Step 6.
- **Write the project overview when it adds over CLAUDE.md.** `<project-name>.md` (named after the project folder, lowercase kebab) is your synthesis — the source-of-truth document — written whenever there's something to synthesize (multiple sources, non-trivial intent/why, success criteria, open unknowns). **Skip it for thin projects** where it would merely restate CLAUDE.md's Project line + the `.system/project.md` description (typical of small operational "do something" tasks). See Step 4. The word "brief" refers only to the user's *originating* input in `references/`, never to your synthesis.
- **Generate structure, don't fill a template.** Each project file is generated to fit THIS project — not iterated through fixed sections. The `_template/` files are common starting points, not mandates.
- **Content-level audit before claiming done.**
- **Never tell the user "remember to do X later."** Detection belongs in the system, not the user's head.

## Step 0 — Detect mode (greenfield vs. adopt)

Before anything else, read `.system/project.md`'s frontmatter `state:` field to decide the mode:

- **`state: fresh`** → **greenfield.** A brand-new `newproject` scaffold; its docs are `_template/` stubs meant to be generated over. Run Steps 1–10 below. (Step 8 consumes the marker — `fresh` → `active` — at closeout.)
- **`.system/project.md` absent · `state: active` · the project already carries real (non-stub) content** → **adopt mode.** The project *already exists* (imported, or set up before). Go to **"Adopt mode (existing projects)"** near the end and follow that path. **Do not run the greenfield generate steps** — they would overwrite real content.

When unsure (e.g. the marker says `fresh` but the docs are clearly filled with real content, not stubs), treat it as **adopt** — the safe, non-destructive default.

## Step 1 — Orient

Read in order:
- `.system/project.md` — the title (H1) and frontmatter written by `newproject`:
  - `started:` — creation date

  The body is a **placeholder** — `newproject` no longer asks for a description, summary, mode, or end-state at intake (it stays purely structural). Drafting the description is the first thing you do in **Step 2 (Phase 0)**, from the title + dropped sources.

  **Project kind is inferred, not stored.** `newproject` no longer asks for a "mode" (planning / code-build / docs / …); the old fixed taxonomy didn't fit operational "do something" projects, and the Step 3 inference already covers every case. Infer the project kind from the title, the dropped sources, and what Phase 0 surfaces, state the inference in one line, and proceed (see Step 3).

  **Audience is inferred, not stored.** `newproject` no longer asks who the project is for; infer it from the project's content and what Phase 0 surfaces — is this client/stakeholder-facing or personal? Client- or stakeholder-facing work leans shared/external — README on the table if it ships, comment style and polish matter. Personal work leans solo / personal-only — terser is fine. State the inference in one line if it shapes doc framing (e.g. *"This reads as client-facing, so I'll keep docs presentable and put a README on the table if it ships"*) and proceed; let the user correct it rather than locking it in. (This *audience* lean drives doc framing only — keep it distinct from a repo's **visibility** (private/public), a separate axis that the git-push rule keys on via live `gh` detection.)
- `ls references/` — list every file and subdirectory there. Whatever the user dropped during `newproject` lives here initially. Read each item enough to understand what it is (Read tool handles PDFs and images; `.rtf` is readable but noisy; directories: walk and read what looks substantive — skip lock-files, build artefacts).
- If `references/` is empty, treat the project as brief-less and rely on `.system/project.md` + the user's responses in Step 2.

State briefly to the user what you understand the project to be — title, project intent in one sentence. Don't ask "is this right?" yet — just orient.

## Step 1.5 — Sort references intake (working content vs. source material)

`newproject.sh` dumped everything the user dropped into `references/`. Two categories tend to be mixed in there:

- **Source material** *(stays in `references/`)*: descriptive documents that explain what the project IS or its background — single `.md` / `.pdf` / `.txt` / `.docx` files, sometimes archived reference collections (e.g., a `Bolo_Goodies/` directory of FAQs and original source code that the project will *consult* but not edit).
- **Working content** *(promote to project root)*: code, configs, media, or directories of project assets that the project will actively edit/build on — e.g., a dropped `scripts/`, `sounds/`, `docs/`, `src/`, `packages/`, individual `.sh` / `.lua` / `.py` / `.ts` / `.json` / `.wav` / `.png` files.

**Use judgment, not a rigid pattern match.** Read what items actually contain when ambiguous. A `docs/` directory of project documentation = working content. A `references-from-vendor/` directory of vendor PDFs = source material. The distinction is *will the project actively edit this* vs. *will the project read this for context*.

If you identify items to promote, list them back as a one-shot confirmation: *"I'd like to promote these to project root as working content: `<list>`. Sound right? [Y/n]"* — default Y. On confirmation, `mv` each one out of `references/` to project root. Don't promote a `<project-name>.md` overview if it exists (it's the synthesis from a prior run, not project content).

If nothing needs promoting, skip the confirmation entirely.

## Step 2 — Phase 0: define the project (always)

This is the project's first act and the heart of setup: figure out what it actually *is* before scaffolding anything. It runs for **every** project — but it's **self-terminating**, so a thin/operational project clears it in seconds while a fuzzy one gets real interrogation. **Grill first, scaffold second** — everything below (overview, phases, files) draws on what Phase 0 surfaces.

**Open with the early moves** (these need only the title + sources, no deep project knowledge):

1. **Seed cross-project vocabulary from the lexicon.** Read `~/project-system/LEXICON.md` — your personal cross-project vocabulary. For any lexicon term that actually appears in *this* project — in the title, the dropped sources, or surfacing early in the grill — seed it into the project's `GLOSSARY.md` (copy the term's definition + `_Avoid_` line verbatim; format + details in Step 6 § GLOSSARY.md). Multiple terms may seed; that's expected. A brand is the common case (a project for your agency seeds that agency's canonical spelling), but any recurring acronym / product name / coined term in the lexicon qualifies. Skip lexicon terms that don't appear here. If `LEXICON.md` is absent or nothing matches, seed nothing — fine.
2. **Draft the description.** From the title + everything in `references/`, draft 2-4 sentences of what this project is and why. If `references/` is empty, it's a best guess from the title alone — fine; the grill corrects it.

**Reflect, then grill** (the reflect beat is non-negotiable):

State the draft back — *"Here's my read of what this is: … — correct me."* Never let a drafted description stand silently; a plausible-but-wrong framing nobody pressure-tested is the failure mode of drafting.

Then run a **bounded grill** to sharpen it. `claude/commands/grill.md` owns the full discipline (one-question-at-a-time, the "When to stop" test); the essentials are recapped here so you don't have to context-switch mid-setup:

- **One question at a time, and only if the answer would change an output** — the description, success criteria, a phase, or a decision. If it wouldn't change anything, it's busywork; don't ask it. (This is why an operational "do something" project asks ~zero questions and a fuzzy product asks several — same machine, self-regulating depth.)
- **Target the high-leverage unknowns:** what v1 "done" looks like (success criteria); the primary constraint (time / accuracy / cost / scope); the top unknown (least-certain dependency or decision); any hard-to-reverse choice that gates progress.
- **Pin terms organically.** When a coined name or overloaded word surfaces *in conversation*, write it to `GLOSSARY.md` right then. Don't solicit a term list cold — people recognize jargon in use, not on demand.
- **Promote cross-project terms to the lexicon.** When a term you just pinned is one the owner will reuse *across* projects — a brand, a recurring acronym, a product/feature name, a cross-project coined term, *not* a project-specific concept — offer *"Add **<term>** to your lexicon so future projects seed it? [Y/n]"* — default **Yes** for a clear cross-project term, **never silent**, **never offered for a project-specific term**. On yes, append it to `~/project-system/LEXICON.md` in the same `**Term**:` / `_Avoid_:` shape (dedupe; reconcile if it already exists) — and set its **visibility**: append with **no `_Visibility_` line** for the usual case (private — a client, company, or personal-venture name; private is the default), or add a **`_Visibility_: public`** line if the term is safe to appear in shared/published work (a product brand the owner ships). Propose the visibility alongside the offer and confirm in one breath; **default to private when unsure** — the safe direction, since the shareable-release guard scans every *private* lexicon term, so mislabeling something public is a loud, fixable false-positive rather than a silent leak. This is the loop's other half: projects pull terms from the lexicon (the seed in move 1) and push new shared ones back.
- **Surface gating decisions** → record the hard-to-reverse + surprising + real-trade-off ones in `DECISIONS.md` (its bar; see Step 6 § DECISIONS.md).
- **Stop the instant it's dry, and bias toward stopping.** *"Looks right — proceed"* is available to the user at every step; honor it immediately.

**Escalate** to a full `/grill` pass only when the decision tree is genuinely deep (several interlocking locked-open decisions) — offer it, don't force it.

**Close with a glossary sweep — only if terms surfaced:** *"Here's the vocabulary I captured: X, Y, Z — that right?"* Skip it entirely when nothing surfaced beyond lexicon-seeded terms (don't manufacture a confirmation).

**Then write the verified description into `.system/project.md`**, replacing the `_Description pending…_` placeholder `newproject` left in the body — 1-2 sentences, the concise version. (The fuller synthesis becomes the overview `<project-name>.md` in Step 4; this is just the short intro that lives beside the metadata.) Leave the frontmatter and the trailing `_This file holds system metadata…_` note intact.

## Step 3 — Project type and stack (inferred)

Infer the project kind from the title, what Phase 0 surfaced, and dropped sources — it sets whether there's a stack to infer at all. Then state your inference in one sentence and proceed. **Don't** ask "Sound right?" — if the inference is obvious, state and continue. (Often Phase 0 has already made the kind obvious; this step just names it.)

- **Planning/research** → no stack yet (designs, data sourcing, open decisions). Add one later when the user's ready.
- **Docs/process** → no stack (documentation, playbooks).
- **Operational / "do something"** (set up a machine, migrate data, clean up a service) → usually no code stack; the work *is* the steps, captured in PLAN.md.
- **Code build** → infer the **language/runtime/build-tool layer** from sources + brief.

State the inferred kind (and stack, if any) with one sentence of reasoning. Examples:
- *"This is a Python project — the ML work (prediction algorithm + atmospheric data) makes it the obvious fit. Going with that."*
- *"This is a planning/research project for now — no code yet, just designs and data sourcing. We'll add a stack later when you're ready."*
- *"This is an operational task — setting up the system on a new machine — so there's no code stack; I'll capture the steps in PLAN.md."*

Proceed unless the user pushes back. Only if genuinely ambiguous (e.g., the project could reasonably be Python or Node), state your two options with a leaning, ask once, and proceed.

## Step 4 — Write the project overview (when it adds over CLAUDE.md)

Source materials (if any) are in `references/` (already sorted in Step 1.5; **do NOT re-copy or modify them**). Working content (if any) has been promoted to project root.

**First decide whether the overview earns its place.** Write it when there's a synthesis to make — multiple sources to integrate, non-trivial intent/why, success criteria, or open unknowns. **Skip it** when the project is thin enough that the overview would just restate CLAUDE.md's Project line + the `.system/project.md` description with nothing added (small operational "do something" tasks: no sources, intent fits a sentence, no real unknowns). When you skip it, say so in one line (*"Skipping a separate overview — CLAUDE.md + the project.md description already capture this thin a project"*) and move on. When in doubt, write it.

**When you write it, write it as `<project-name>.md` at the *project root*** — named after the project folder, lowercase kebab (e.g. `website-builder/` → `website-builder.md`). Compute the name with `basename "$PWD"`. It sits alongside `CLAUDE.md` / `PLAN.md` / `DECISIONS.md` / `CHECKLIST.md`, but unlike those fixed ALLCAPS system slots it carries the project's own name (see `CONVENTIONS.md` § "Document naming"). It's the source-of-truth for what the project IS. Synthesize from ALL files in `references/` AND any promoted working-content directories at project root AND your conversation so far. If there are multiple sources, integrate across them — don't just summarize each one separately.

Structure (note the H1 is the project title, *not* "Brief:"):

```
# <Project Title>

**What this is:** 1-2 sentences.
**Why it exists:** 1-2 sentences — the problem this solves, the value it produces.
**Success criteria:** 2-4 bullets — what "done" looks like for v1.
**Unknowns / open questions:** 2-4 bullets — what we don't yet know.
**Source materials:** (only if any) — list each `references/<filename-or-dir>` with one sentence on what it contains and how it informed the overview. If working content was promoted to project root in Step 1.5, also note where it lives (e.g., "the scripts/ directory at project root holds the EdgeTX Lua scripts dropped at intake").
```

Show the overview to the user. Adjust if they push back. Do NOT ask "look good?" — show and proceed unless they object.

## Step 4.5 — Phase preview (gate before PLAN.md is written)

Before generating any project files, state the proposed PLAN.md phase decomposition as a short preview — 3-6 phases, **one line of scope each**. Use the canonical `Phase N: <Name>` shape PLAN.md will adopt (see Step 6 § PLAN.md). Example shape:

```
Proposed phases:
1. Phase 1: Bootstrap — set up repo, dependencies, baseline test harness.
2. Phase 2: Core engine — implement the prediction algorithm and unit tests.
3. Phase 3: Wire-up — connect engine to data sources + CLI.
4. Phase 4: Polish — error handling, docs, release packaging.
```

Then ask once: ***"Phases look right? [Y/n/edit]"***

- `Y` / Enter / silence → proceed to Step 5.
- `n` → ask which phase is wrong (number or name), adjust, re-show once, then proceed.
- Free-form edit ("split Phase 2 into engine + tests", "add a research phase up front") → fold in the change, re-show once, then proceed.

Don't re-loop more than once. If the user keeps editing, capture the final shape and move on — phase names can still be adjusted in PLAN.md later.

**Why this gate exists:** phase decomposition is an inference Claude makes from the brief, but the brief doesn't itself dictate phases. Mis-decomposed phases are expensive to recover from — they ripple into PLAN.md, CHECKLIST.md, CLAUDE.md's Status field, and Open Decisions phase tags. This is the one structural moment the brief-show in Step 4 doesn't cover. It's the only structural gate in the whole flow — keep it light.

## Step 5 — Scaffold (only for greenfield code projects)

For pure-docs / planning projects: skip.

For code projects with a clear stack and no existing code: ask once — *"Want me to scaffold the basics (e.g., `npm init -y`, `python3 -m venv .venv && pip install ...`)?"* — default yes for greenfield. Run the appropriate init commands.

## Step 6 — Generate project files

Generate each file to fit THIS project. Before generating CLAUDE.md, **read expert examples** so your output patterns on proven shapes — not just on principle distillation.

### Read references first (CLAUDE.md specifically)

Before generating, ground your output on proven shapes — not just principle distillation:

- **Canonical spec:** `AUTHORING.md` § "`CLAUDE.md` — the section menu" (see *CLAUDE.md generation* just below — read it first). It defines every section and how to author it.
- **In-house examples:** read a couple of existing managed `CLAUDE.md` files in `~/Projects/Active/` (and `~/Projects/Archive/`) that match this project's kind, as shape references — the workspace's own mature CLAUDE.mds are the pattern library.
- **Related projects:** if one has overlapping scope (e.g., this project supersedes a nearby "v1"), read its `CLAUDE.md` — its conventions, structure, and don'ts may extend here. Mention any such related project in this project's `CLAUDE.md`.

**Pattern your output on these examples; adapt for this specific project.** Do not copy verbatim. Do not omit sections the examples populate just because *this* project's content is partial or proposed — better to include with appropriate framing ("Proposed", "TBD", "tentative") than to omit and produce a thin file.

### CLAUDE.md generation

Generate based on the section menu + those in-house examples + this project's substance + project type.

**The section-by-section spec is canonical in `AUTHORING.md` § "`CLAUDE.md` — the section menu" — read it before generating.** It defines every section and how to author it: Status, Project, Identifiers, Open Decisions (+ `locked-open` semantics), Stack (no-limbo), Structure (two modes + name-don't-materialize), Router table, Commands, Conventions, Don't, Related projects, Claude Code tooling — plus the two cross-cutting rules (no "Working Agreement" summary layer; length follows substance, no `<placeholder>`). That menu is shared with `/init-claude-md`; don't re-inline it here.

What follows is only the **greenfield-specific** part: how you propose Conventions and Don't entries during intake.

#### Conventions / Don't — the per-entry review

Conventions and Don't entries are the exception to "proceed by default" — they're project rules that depend on context you don't have (decisions the user/team made, knowledge about people involved, ground-truth answers to ambiguities). **Propose each candidate one at a time before writing**, with one sentence of reasoning. End each proposal with a numbered shortcut line (the one exception to "no numbered menus" — a fixed 3-way choice repeated many times warrants it):

```
[1] confirm   [2] change   [3] reject   (or type your answer / edit)
```

Handle the response:
- `1` / affirmative / "yes" / silence → write as proposed
- `3` / "no" / reject → skip
- `2` / "change" / a modification → adjust and write the revised version
- "I have the answer" (free text) → don't make it a convention; capture the answer in the overview / plan / decisions instead
- **A question about the candidate** ("what does X mean?", "why this?", "where did this come from?", "give me an example") → answer concisely, then re-display the *same* candidate and shortcut line. Don't advance to the next candidate, don't write it, don't restart the review. Stay on this one until the user picks 1/2/3 or supplies an answer.

Track the queue explicitly. Label each proposal at the top with `Convention entry N of M:` or `Don't entry N of M:` — always with the "entry" buffer word (never "Convention 2" / "Don't 2" / "Don't #2", which read as imperatives) — and use the same phrasing in any follow-up reference ("ready to proceed with Don't entry 2?"). After 1/2/3, advance to N+1; questions do not advance N.

Watch for the **convention-vs-question trap:** if you spotted an unknown in the source (a discrepancy, missing info, ambiguity), don't reflexively turn it into a "verify-before-X" rule. *Ask the user directly* first — they may have the answer right now, and then the convention isn't needed at all.

### PLAN.md

Generate real phases derived from the overview. Each phase has a short descriptive name and 3-5 sub-bullets reflecting actual next actions. Reference the project overview (`<project-name>.md`) at the top so future-Claude knows where the source-of-truth is.

**PLAN.md owns the canonical phase names.** Use the form `Phase N: <Name>` (e.g., `Phase 1: Bootstrap`, `Phase 2: Sound-Library-Stable`). Every reference to a phase elsewhere — CLAUDE.md Status field, CLAUDE.md Open Decisions phase tags, CHECKLIST.md headers, CHECKLIST.md closeout tasks — uses these exact names verbatim. **Mismatched phase names across files is a recurring drift point** — name once in PLAN.md and copy from there.

**Every Open Decision must appear as an explicit decision-deliverable task in its tagged phase's PLAN.md section.** Tagging a decision `(Phase 2)` in CLAUDE.md isn't enough — the phase has to own its resolution. Bad: Phase 2 of PLAN.md is "Model backups" with no mention of the bind-phrase decision tagged Phase 2 in CLAUDE.md. Good: Phase 2 explicitly opens with *"Resolve `bind-phrase handling for models/*.yml` — pick: scrub / store-separately / accept-if-private. Capture in DECISIONS.md."* Decisions are first-class deliverables, not implied side-quests.

**Decisions that fork downstream phases deserve milestone status, not peer items.** If a Phase 1 decision (e.g., "self-file vs. CPA") fundamentally changes what Phase 4 looks like, promote it to its own milestone — not a peer bullet alongside information-gathering tasks like "enumerate sources." A forking decision and a fact-gathering task aren't the same shape of work.

Concrete shape (illustrative, not prescriptive):

```
# Plan

See `<project-name>.md` for the working contract and source materials.

## Phase 1: Research

- <concrete action>
- <concrete action>
- ...

## Phase 2: Design

- <concrete action>
- ...
```

Never write "Phase 1 / Step 1 / Step 2" placeholder text — write the actual work.

### DECISIONS.md

Write at least one entry — the project-type / scope decision — with today's date. Use the existing format (Context / Options / Chose / Reasoning).

**`DECISIONS.md` is the single decision record — record decisions here, not in any separate file or folder.** Beyond the always-recorded project-type/scope decision, record a choice only when **all three** hold: **(1) hard to reverse**, **(2) surprising without context** (a future reader will wonder "why this way?"), **(3) the result of a real trade-off** (genuine alternatives existed). If any is missing, usually skip it — it'll get reversed cheaply, or nobody will wonder, or there was no alternative to record. This bar is tighter than "meaningful choices" and keeps the log signal-dense.

**Include a reconsideration trigger** when one exists. Two valid shapes — pick one per entry:
- **`Revisit if:`** = condition-based. *"Revisit if: a concrete automation need surfaces during the 2025 walk-through."*
- **`Revisit:`** = scheduled trigger pointing at a specific future task. *"Revisit: Phase 4, task `Archive radio-master`."*

Use `Revisit if:` for "we'll know when we see it" cases and `Revisit:` for "look at this at moment X." Skip both when the decision is forever-locked — don't invent triggers that don't exist. The field pairs with the bolo-style retirement pattern: trigger to reconsider on the create side; the retirement line is the outcome of having reconsidered.

If the overview surfaces other early decisions (e.g., "docs-first because no stack yet", "default-yes carry-forward of TypeScript from related project") that clear the three-part bar, capture each as an entry.

### GLOSSARY.md (canonical project language)

`GLOSSARY.md` pins the project's **canonical language** — the coined terms specific to *this* project — so vocabulary doesn't drift across the overview, `PLAN.md`, `DECISIONS.md`, `CLAUDE.md`, and the code.

**Cross-project terms are seeded in Phase 0 (Step 2)** — the early opening move — by reading your personal `~/project-system/LEXICON.md` and copying into `GLOSSARY.md` any lexicon term that actually appears in this project (verbatim definition + `_Avoid_` line). (If for any reason it wasn't done there, do it now.) Brands are the common case — this is the dataless global "brand fidelity" rule, finally given data — but any recurring acronym / product name / coined term in the lexicon qualifies. Shape:

```md
**ACME**:
The agency this project is being built for.
_Avoid_: Acme, acme, AcmeCorp
```

Pull each canonical spelling and its `_Avoid_` forms verbatim from `LEXICON.md`. Multiple lexicon terms may seed; that's expected. (See [`LEXICON.example.md`](../../LEXICON.example.md) for the format.)

**Then add any other terms the overview/sources/Phase 0 already yielded** — coined names for concepts, overloaded words you've pinned to one meaning, and **third-party tool/product/brand names that are the project's subject matter or recur as canon** (give each an `_Avoid_` line for the common wrong-case variants and misspellings, e.g. `GitHub` — _Avoid_: Github, github, Git Hub; `npm` — _Avoid_: NPM, Npm). Those spellings are vocabulary and live here — *not* as a "spell names right" Convention (that just restates the global brand-fidelity rule). **Only skip `GLOSSARY.md` entirely** if the project is genuinely term-less — no lexicon term applies and no coined terms surfaced. Don't write empty stubs beyond the seeded term(s). The Phase 0 grill (Step 2) already sharpened and extended this as terms surfaced; a later standalone `/grill` does the same.

Rules: glossary-only (define what a term *is*, not what it does, 1-2 sentences); only project-specific terms (no general programming concepts); be opinionated (pick the canonical word, list rejected synonyms under `_Avoid_`). The lexicon-seed block above is the per-term shape; the full file format (the `# <Project Title>` heading, a one-line "what this glossary is", a `## Language` section) and these rules are defined canonically in **`AUTHORING.md` § "`GLOSSARY.md` — canonical project language"** and mirrored in `grill.md` — keep all three identical; don't fork a fourth copy here.

The glossary was already sharpened during the Phase 0 grill (Step 2); if you escalated to a full `/grill` there, it was extended further.

### CHECKLIST.md

Write Phase 1 tasks matching PLAN.md. Real, project-specific actions — not "Task 1 / Task 2".

**Phase-closeout tasks should name the successor state**, not be open-ended. Instead of *"Update CLAUDE.md Status away from Pre-decision"* write *"Update Status to Design (Phase 2) or Scaffolding (Phase 3), whichever Phase 1 closeout lands on."* Open-ended instructions get skipped or done vaguely.

### Typo pass on user-supplied content

When you read `.system/project.md` during orientation, flag obvious typos in the user-supplied **title** (the one field `newproject` captures verbatim). One line: *"Spotted 'algorythym' in the project title — likely 'algorithm'; want me to fix?"* Default yes if no objection. (Note: `newproject.sh` writes only the title into the body; the description is drafted and verified with the user in Phase 0, so it doesn't need a separate typo pass. There is no `README.md` by default; it's opt-in only.)

## Step 7 — Content-level audit

Before claiming Step 6 done, verify and **state plainly what you checked**:
- No `<placeholder>` text in any file
- `PLAN.md`, `DECISIONS.md`, `CHECKLIST.md` have real, project-specific content
- `CLAUDE.md` has only sections that apply (no empty Stack/Commands/Conventions/Don't)
- `<project-name>.md` (the project overview) exists, is named after the project folder, and reflects the synthesis
- `GLOSSARY.md` exists if the project has ≥1 coined term (else correctly absent — not an empty stub)
- Source materials in `references/<original-filename>` are preserved as-is (if provided)
- No restatement of rules already in `~/.claude/CLAUDE.md` or the system prompt
- **Cross-reference jargon hygiene:** if a section uses a term defined in a later section (e.g., a `## Related projects` line mentioning "Cheshire-spec canon" while `## Conventions` is the section that defines it), either reorder or gloss it on first use. Future-readers shouldn't have to read the file twice.
- **Open Decisions ↔ PLAN.md ↔ CHECKLIST.md alignment:** every Open Decision should have a phase tag matching where it gets resolved in PLAN.md. Phase 1 decisions should appear as tasks in CHECKLIST.md Phase 1. Decisions tagged for later phases shouldn't appear in Phase 1's checklist. **Each Open Decision must appear as a decision-deliverable task in its tagged PLAN phase** — tagging without follow-through is drift. Catches drift between the three files.
- **Stack ↔ DECISIONS.md alignment:** committed Stack items and default-yes carried-forward items should have corresponding DECISIONS.md entries. No item in Stack should be in a "proposed without resolution path" limbo state.
- **PLAN ↔ CHECKLIST task order alignment:** within each phase, the task order in CHECKLIST.md should mirror PLAN.md's narrative order. If PLAN says "decide X, then run Y" and CHECKLIST says "locate inputs, decide X, run Y," update PLAN to match — CHECKLIST tends to be the more accurate document because it's where execution lives.
- **Phase name consistency:** the phase names in CLAUDE.md Status field, CLAUDE.md Open Decisions phase tags, PLAN.md `## Phase N: <Name>` headers, CHECKLIST.md `## Phase N: <Name>` headers, and CHECKLIST.md closeout tasks must all use the *same name* for the same phase. PLAN.md is the canonical source — copy from there.
- **Concrete details preservation:** if source materials in `references/` contain concrete details — hardware specs (model numbers, receiver types, version pins), vendor IDs, account names, file sizes, exact version requirements — those details should appear in `CLAUDE.md`'s Stack/Conventions or in the project overview (`<project-name>.md`). If a detail is in the source but missing from synthesis, surface it before claiming done. The overview should never *lose* data; it should *organize* it.
- **Post-synthesis source-doc cleanup:** after synthesis, handle a consumed source doc in `references/` — but first classify what it is, because the two kinds are treated differently (see `CONVENTIONS.md` § "The project overview and references"):
  - **Originating brief** — a descriptive doc the user dropped to *spawn* the project, now substantially absorbed into the overview + `CLAUDE.md` + project files (the "brief-duplication smell"). Offer, behind an **explicit confirm**, the cleanest option: **(a) delete it** — it's fully absorbed and recoverable from git history (only offer delete once `git init` has committed it, or note it'll be committed first; for an *uncommitted/private* source where deletion would be unrecoverable, offer freeze instead). Alternatives if the user declines delete: **(b) freeze** with an archival header pointing to the live docs, or **(c) extract** any unique content not yet in `CLAUDE.md` and then remove. Default-recommend (a) when synthesis is verified complete; never silently leave the duplicate in place, and **never auto-delete without the confirm**.
  - **Reference archive** — material meant to be *consulted forever* (e.g., a `Bolo_Goodies/` directory of canonical source). **Never targeted** by cleanup — not deleted, frozen, or rewritten. Leave it exactly as-is.

  Only ever target a fully-absorbed *originating brief*. When in doubt about which kind a `references/` item is, treat it as a reference archive and leave it.
- **Date hygiene:** keep dates only where they carry weight — incident anchors (*"after the 2026-04-29 prod write"*), deadlines, version-pinned constraints. Strip "shipped on" / "updated on" / "as of" decoration that doesn't change Claude's behavior. Heuristic: **if removing the date wouldn't change how Claude reads or acts on the line, the date doesn't belong there** — it'll just age into noise.
- **Code-snippet check on rules that name a calling pattern:** every Convention or Don't that says *"always call X this way"* / *"use helper Y not Z"* should carry the 2-5 line snippet inline, not just the prose. If the snippet is missing, write it now — don't ship a prose-only rule that names a specific calling pattern.
- **Header-count consistency:** if CLAUDE.md introduces a section with a count claim (*"These 10 rules apply…"* / *"the 7-role set"* / *"all three folders"*) the count must match the actual contents. Mismatch is a drift signal — fix the number AND treat it as a flag to re-read nearby sections for other stale claims.
- **Router cell scope** (only when CLAUDE.md has a Router table): each left-column cell is a user-intent trigger phrase (5-15 words); each right-column cell is path + one sentence of orientation. If a cell has nested parentheticals summarizing the destination doc's contents, trim it — the destination doc carries the detail.

## Step 8 — Git init

Just do it (no question):
- `git init -b main`
- **Write the no-remote commit identity (umbrella include) — before the first commit.** Under `user.useConfigOnly = true`, a repo with no remote and no identity rule *refuses* to commit, so this must precede `git commit`. Resolve the umbrella, then write an `[include]` (indirection — the umbrella's name/email stays editable in one file):
  - **Umbrella id:** use `.system/project.md`'s `umbrella:` field if set (e.g. recorded by `newproject --umbrella`). If absent, list candidates with `git config -f ~/.gitconfig.local --get-regexp 'includeIf.*hasconfig.*\.path'` — each value is `~/.gitconfig-<id>` and the `<id>` suffix is an umbrella. One candidate → use it; several → ask which umbrella this project belongs to; **none** (single-identity user — no `hasconfig` rules) → **skip this step entirely** (the global git author already covers commits).
  - **Write it:** `git config --local include.path "~/.gitconfig-<id>"`, then record the chosen `<id>` back into `.system/project.md`'s `umbrella:` field if it wasn't already there.
- Write `.gitignore` appropriate to project type (Node: `node_modules/`, `dist/`, `.env*`; Python: `__pycache__/`, `*.pyc`, `.venv/`; pure docs: `.DS_Store` is enough) One pattern per line; never put an inline `#` comment after a pattern (git treats the whole line as the pattern, so the ignore silently fails). Put any comment on its own line.
- `git add` the populated files (include `references/` unless a source could be private — ask only in that case)
- `git commit -m "Initial commit — scaffolded via newproject"`
- **Consume the greenfield marker:** in `.system/project.md`, advance frontmatter `state: fresh` → `state: active`. (`.system/` is gitignored, so this is a local-disk update, not part of the commit.) This makes a future re-run of `/setup-project` enter **adopt** mode instead of regenerating over your now-real content.

## Step 9 — Connect a git remote (single y/N, default N)

Ask once: *"Connect this project to a git remote now? (y/N)"* — default N. If no, skip silently.

The system encodes **no** GitHub identity — no org table, no account constant, no SSH-alias. Everything is host-agnostic or read live from `gh`. If yes, offer three choices:

1. **Connect an existing repo** (any host — GitHub, GitLab, self-hosted).
2. **Create a new GitHub repo** (GitHub-only; needs `gh`).
3. **Skip.**

**Whenever a remote is connected (choices 1 or 2), drop the no-remote include:** `git config --local --unset include.path 2>/dev/null || true`. The remote URL's SSH alias now routes commit identity via `~/.gitconfig.local`'s `hasconfig` rules; a leftover include would shadow it. (This is the other half of the one rule — *write the include at `git init`, drop it on remote-connect.*)

### [1] Connect an existing repo (host-agnostic, the default path)

The repo must already exist. Ask: *"Paste the repo's clone URL — from its Code button, HTTPS or SSH both work. Create an empty repo first (e.g. github.com/new) if it doesn't exist yet."* Then:
- `git remote add origin <url>`
- **Check visibility before the first push:** run `~/project-system/bin/repo-visibility.sh "<url>"`. It prints `private` / `public` / `unknown` (robust to multi-account / SSH-alias setups). If `private`, push silently. If `public` or `unknown`, this push *publishes* to a repo that isn't confirmed-private — show what's about to go up and confirm first.
- `git push -u origin main`
- Success → show the remote URL. Failure (e.g. the remote already has commits) → surface git's error and the manual command; don't die. A custom SSH host alias (e.g. `git@github.com-you:org/repo.git`) just rides in the pasted URL — nothing to configure.

### [2] Create a new GitHub repo (optional, GitHub-only)

Requires `gh` installed + authenticated. If it isn't, say so and fall back to [1]. No org mapping, no hardcoded account — read it all live:
1. `gh auth status` — list the authenticated accounts. **If 2+**, ask the user which should own the repo (offer the accounts and, for the chosen one, its orgs via `gh api user/orgs --jq '.[].login'`); capture the currently-active account, then `gh auth switch --user <chosen>`. **If 1 account**, skip the prompt.
2. `gh repo create <owner>/<folder-name> --private --source=. --remote=origin --push --description "<the description from .system/project.md body>"` — `<owner>` is the chosen account or one of its orgs. (Default `--private`; ask if the user wants it public.)
3. If you switched accounts in step 1, `gh auth switch` **back** to the originally-active account so the user's terminal isn't left on a different identity.
4. Show the repo URL.

### [3] Skip — finish silently.

## Step 10 — Wrap up

### Step 10a — Open Finder (required, not optional)

Run this Bash command **now**, before composing the summary:

```sh
open .
```

This must actually be executed via the Bash tool — not described, not skipped, not left to the user. The user expects Finder to pop while they're still in the Claude session.

### Step 10b — Print the summary

After Finder has been opened, print a short summary. The first line must acknowledge that Finder was opened — this serves as confirmation:

```
📂 Project folder open in Finder.

- What this is: <1 line>
- Overview: <project-name>.md (project root)
- Remote: <URL if connected, otherwise omit>
- (If relevant) CLAUDE.local.md is opt-in for personal-only setup; gitignored globally if you create it.

Ready to start working — what would you like to do?
```

If you skipped `open .` for some reason, do not include the "📂 Project folder open in Finder" line — that line is the user's signal that the open happened.

## Adopt mode (existing projects)

You're adopting a project that **already exists** — imported via `importproject`, or set up before. **Cardinal rule: only ADD what's missing; never modify, overwrite, or delete anything already here.** Deepening existing docs is `/grill`'s job, offered at the end — not this command's. This path *replaces* Steps 1–9; do **not** run the greenfield generate/scaffold steps.

### A0 — Announce, loudly
Open by framing it and stating the rule plainly, e.g.:
> "This project already exists, so I'm **adopting** it into the system — I'll only **add** what's missing and **never touch** anything that's already here."

### A1 — Inventory (and show it)
Read the project root. Show the user two lists:
- **Found, keeping as-is:** every baseline doc + foreign content present (`CLAUDE.md`, the `<project-name>.md` overview, `PLAN.md`, `DECISIONS.md`, `CHECKLIST.md`, `GLOSSARY.md`, `.system/project.md`, plus `README.md` / `src/` / `docs/` / …).
- **Missing, will draft:** the baseline docs that are absent.

### A2 — Read the existing project as the brief
The project's own files ARE the source material (not just `references/`). Read them to understand what it is — the comprehension you'd otherwise get from a brief.

### A3 — Visibility check (before writing any identifying content)
Run `git remote -v` (and `~/project-system/bin/repo-visibility.sh "<url>"` if there's a remote). Set the identifying-detail level for anything you write: **local-only (no remote) → real names OK; private → caution; public → abstract** ("the rental", "the client"). Account-PII (secrets, account numbers, the documents themselves) never enters the repo regardless. **State which level you used.**

### A4 — Create only what's absent (earns-its-place)
For each **missing** baseline doc, create it from the review — honoring "no empty stubs":
- `.system/project.md` — always, if missing. Frontmatter `started:` = the project's first commit date (or today); a real description; `state: active` (adopt-created projects are not "fresh").
- a minimal `CLAUDE.md` — if missing (orientation; only sections that apply).
- `<project-name>.md` overview / `GLOSSARY.md` / `DECISIONS.md` / `PLAN.md` / `CHECKLIST.md` — only when the reviewed content warrants (skip otherwise; no hollow stubs).
- **Skip every doc that already exists. Never regenerate.**

### A5 — The foreign-`CLAUDE.md` case
If the project already has its **own `CLAUDE.md`** in a different shape, **leave it exactly as-is**, say so, and offer the reconcile path:
> "You already have a `CLAUDE.md`; I left it untouched. It's shaped differently from the system's (Status / Open Decisions / …). Want it reconciled to that shape? Run `/grill` — that's the tool that edits existing docs, with your confirmation."

### A6 — Report + hand off
- Report **created vs. skipped** (the audit trail) and the **visibility level** used.
- **Offer `/grill`** for the deepening (extend/reconcile the now-baseline docs) — distinct from this adopt, which only added structure. Do **not** run the Phase 0 grill automatically.
- Then do **Step 10** (open Finder + print summary) as in greenfield.

**Git:** an adopted project usually already has a repo (`importproject` cloned/copied it). Don't `git init` over it. If it genuinely has no repo and you created baseline docs, offer `git init` (Step 8) — but never auto-commit a project you didn't create without surfacing what's being added first. **Identity backfill (non-destructive):** if the existing repo has **no remote** and no `include.path` set (so a future commit would hit `user.useConfigOnly` and be refused), resolve its umbrella and write the include exactly as in Step 8 (`git config --local include.path "~/.gitconfig-<id>"`). This only adds identity routing — never content or history. A repo that already has a remote is alias-routed; leave it.

## Out of scope

- Don't modify `~/project-system/`, `~/.claude/`, or `~/dotfiles/`.
- Don't auto-commit anything outside the new project's git repo.
- Don't skip the audit step.
