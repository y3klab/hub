---
description: Expert project intake. Non-destructive by construction - creates only the docs a project's content warrants and never modifies, overwrites, or deletes anything already there. Works the same on a project registered ten seconds ago and one imported from years of someone else's work. Offers a `/grill` hand-off before writing, where the project warrants one.
---

You are setting up a project into the system.

**The cardinal rule, and the only one you cannot bend: create only what is absent. Never modify, overwrite, or delete anything that is already here.** There is no second mode and no marker selecting one - this posture is correct whether the project was registered ten seconds ago or has five years of someone else's work in it. Deepening a doc that already exists is `/grill`'s job, offered at the end, never yours.

A **registered** project arrives with a floor: `.gitignore`, `.system/project.md` (carrying a real one-line description), and a minimal `CLAUDE.md`. Everything else - the overview, `PLAN.md`, `CHECKLIST.md`, `DECISIONS.md`, `GLOSSARY.md` - you create *only when the content warrants it*. An absent file is a correct state, not a gap to fill. Source materials, if any, are in `references/`.

Your role: act as the senior project-setup expert the user hired. Read what's there, understand the project, ask only what you don't already know, then produce a professional starting point.

## Posture (read this first)

- **Read first, ask later.** Always read all available material — `.system/project.md` (title + the one-line description given at registration), the existing `CLAUDE.md`, any other docs already present, and any source materials — before forming questions.
- **Orient with the Read tool and simple commands, not compound shell.** Use Read/Glob for files; if you need Bash, keep it to one plain command (`ls -la`), never `&&`/`;` chains or `echo` headers. On a fresh install with default permissions, a compound one-liner greets the user with a "cannot be statically analyzed" permission wall as their very first Claude Code experience; simple reads keep first contact calm.
- **Propose with reasoning. Proceed by default.** Only ask when there's no defensible default OR when external state is involved (e.g., connecting or creating a git remote).
- **Ask only what you don't already know.** If the source materials answer a question, don't ask it.
- **"I don't know" / "you decide" → proceed with your best inference.** Never re-ask the same question.
- **Conventions and Don't entries are the exception to "proceed by default."** These are project rules that depend on context you don't have — decisions made by the user/team, knowledge about people involved, ground-truth answers to ambiguities. Propose each candidate entry one at a time and wait for the user's response. Watch for the *"convention vs. question"* trap: if you spotted an unknown in the source (a discrepancy, ambiguity, missing info), don't reflexively turn it into a "verify-before-X" convention. *Ask the user directly* — they may have the answer right now, and then the convention isn't needed at all.
- **Conversational throughout — no numbered menus for open-ended questions.** Exception: the Conventions / Don't per-entry review is a fixed 3-way choice repeated many times in a row; that one uses a `[1] confirm [2] change [3] reject` shortcut line. See Step 6.
- **Write the project overview when it adds over CLAUDE.md.** `<project-name>.md` (named after the project folder, lowercase kebab) is your synthesis — the source-of-truth document — written whenever there's something to synthesize (multiple sources, non-trivial intent/why, success criteria, open unknowns). **Skip it for thin projects** where it would merely restate CLAUDE.md's Project line + the `.system/project.md` description (typical of small operational "do something" tasks). See Step 4. The word "brief" refers only to the user's *originating* input in `references/`, never to your synthesis.
- **Generate structure, don't fill a template.** Each project file is generated to fit THIS project — not iterated through fixed sections. A registered project arrives with only a floor (`.gitignore`, `.system/project.md`, a minimal `CLAUDE.md`); everything else you write must earn its place.
- **Content-level audit before claiming done.**
- **Never tell the user "remember to do X later."** Detection belongs in the system, not the user's head.

## Step 0 — Announce, inventory, and set the detail level

Three things before you read anything closely. Adding to a project can touch work someone already did, so this flow is **loud** — the same "announce every path" ethos as `install.sh`.

**a. State the rule.** Open by saying plainly what you will and will not do, e.g.:

> "I'll add only what's missing and never touch anything that's already here."

**b. Show a found-vs-missing inventory.** Read the project root and show two lists:

- **Found, keeping as-is** — every doc and foreign file present (`CLAUDE.md`, the `<project-name>.md` overview, `PLAN.md`, `DECISIONS.md`, `CHECKLIST.md`, `GLOSSARY.md`, `.system/project.md`, plus `README.md` / `src/` / `docs/` / …).
- **Missing, candidates to draft** — the docs that are absent. Say "candidates," not "will create": each still has to earn its place below.

For a just-registered project the found list is short (three files) and the missing list is long; for an imported project it may be the reverse. Same step either way — the lists just have different lengths.

**c. Set the identifying-detail level before writing anything.** Run `git remote -v`, and `~/project-system/bin/repo-visibility.sh "<url>"` if there is a remote. Then: **local-only (no remote) → real names are fine; private → caution; public → abstract** ("the client", "the rental"). Account-PII — secrets, account numbers, the documents themselves — never enters the repo regardless of visibility. **State which level you chose**, in one line.

## Step 1 — Orient

Read in order:
- `.system/project.md` — the title (H1), the `started:` date, and **the one-line description given at registration**. That description is real, not a placeholder: registration refuses a project that cannot describe itself. Treat it as the author's own statement of intent — your job is to *build on* it, and to sharpen it only if what you read genuinely contradicts or outgrows it.

  **Project kind is inferred, not stored.** `newproject` no longer asks for a "mode" (planning / code-build / docs / …); the old fixed taxonomy didn't fit operational "do something" projects, and the Step 3 inference already covers every case. Infer the project kind from the title, the description, and the dropped sources, state the inference in one line, and proceed (see Step 3).

  **Audience is inferred, not stored.** `newproject` no longer asks who the project is for; infer it from the project's content — is this client/stakeholder-facing or personal? Client- or stakeholder-facing work leans shared/external — README on the table if it ships, comment style and polish matter. Personal work leans solo / personal-only — terser is fine. State the inference in one line if it shapes doc framing (e.g. *"This reads as client-facing, so I'll keep docs presentable and put a README on the table if it ships"*) and proceed; let the user correct it rather than locking it in. (This *audience* lean drives doc framing only — keep it distinct from a repo's **visibility** (private/public), a separate axis that the git-push rule keys on via live `gh` detection.)
- `ls references/` — list every file and subdirectory there. Whatever the user dropped during `newproject` lives here initially. Read each item enough to understand what it is (Read tool handles PDFs and images; `.rtf` is readable but noisy; directories: walk and read what looks substantive — skip lock-files, build artefacts).
- **The project's own existing files, when it has any.** For anything but a just-registered project — an import, or a folder someone has been working in — *those files ARE the brief.* Read the existing `CLAUDE.md`, `README.md`, the source tree, whatever docs are there, and take from them the comprehension you would otherwise get from a dropped brief. Step 0's inventory listed them; this is where you actually read them. Do not skip this because `references/` happened to be empty.
- If there is neither `references/` content nor existing project files, the project is genuinely brief-less: rely on the title, the registration description, and what the user tells you.

State briefly to the user what you understand the project to be — title, project intent in one sentence. Don't ask "is this right?" yet — just orient.

## Step 1.5 — Sort references intake (working content vs. source material)

`newproject.sh` dumped everything the user dropped into `references/`. Two categories tend to be mixed in there:

- **Source material** *(stays in `references/`)*: descriptive documents that explain what the project IS or its background — single `.md` / `.pdf` / `.txt` / `.docx` files, sometimes archived reference collections (e.g., a `Bolo_Goodies/` directory of FAQs and original source code that the project will *consult* but not edit).
- **Working content** *(promote to project root)*: code, configs, media, or directories of project assets that the project will actively edit/build on — e.g., a dropped `scripts/`, `sounds/`, `docs/`, `src/`, `packages/`, individual `.sh` / `.lua` / `.py` / `.ts` / `.json` / `.wav` / `.png` files.

**Use judgment, not a rigid pattern match.** Read what items actually contain when ambiguous. A `docs/` directory of project documentation = working content. A `references-from-vendor/` directory of vendor PDFs = source material. The distinction is *will the project actively edit this* vs. *will the project read this for context*.

If you identify items to promote, list them back as a one-shot confirmation: *"I'd like to promote these to project root as working content: `<list>`. Sound right? [Y/n]"* — default Y. On confirmation, `mv` each one out of `references/` to project root. Don't promote a `<project-name>.md` overview if it exists (it's the synthesis from a prior run, not project content).

If nothing needs promoting, skip the confirmation entirely.

## Step 2 — Sharpen the definition, and decide whether to grill *first*

The project already has a one-line description, given at registration. Start from it.

**The early move — seed cross-project vocabulary.** Read `~/project-system/LEXICON.md`, your personal cross-project vocabulary. For any lexicon term that actually appears in *this* project — in the title, the description, the dropped sources — seed it into `GLOSSARY.md` (definition + `_Avoid_` line verbatim; format in Step 6 § GLOSSARY.md). A brand is the common case, but any recurring acronym, product name, or coined term qualifies. Skip terms that don't appear here. If `LEXICON.md` is absent or nothing matches, seed nothing — fine.

**Then reflect the description back, once.** State what you understand the project to be, in a sentence or two, drawing on the description plus everything in `references/`: *"Here's my read of what this is: … — correct me."* Take a correction if one comes; otherwise proceed. This is a single beat, not an interview.

### The grill decision — this is the moment for it

**Never run a grill unasked.** Setup used to *always* enter a bounded interrogation. It no longer does: a two-hour errand and a year-long build both come through here, and marching both through an interview is the forcing this flow exists to remove.

But when a grill *is* wanted, **it belongs here, before anything is written** — not at the end. A grill that runs after the overview and the phase plan exist has to *revise* them; a grill that runs now *informs* them. You have just read everything, so this is the first moment you can judge the question and the last moment the answer is free.

**Judge it, then say so plainly.** A grill is worth offering when the project has several interlocking open decisions, a success criterion nobody could state in a sentence, or vocabulary that keeps shifting. It is **not** worth offering for a thin operational project — skip the offer entirely rather than manufacturing one, and just proceed. Most projects should get no offer.

**If it is warranted, offer to stop.** Do not inline the interview — `/grill` owns that discipline (one question at a time, the "When to stop" test, pinning terms as they surface) and is its single home. Say something like:

> "Before I write anything: there are three interlocking decisions here I'd rather not guess at — <name them>. Want to grill it first? Run `/grill`, then re-run `/setup-project`. Setup is non-destructive, so the second pass just builds on whatever the grill pins down."

- **Accepted → stop here.** Do not continue to Step 3. Nothing has been generated yet, so there is nothing to undo, and the grill's outputs (`GLOSSARY.md`, `DECISIONS.md`, a sharpened description) become inputs to your next run.
- **Declined, or not warranted → continue to Step 3 and write.** Don't raise it again later; the summary in Step 10 mentions `/grill` exists, and that is enough.

**Ask a question only when its answer would change a file you are about to write** — the overview, a success criterion, a phase, a decision. If it would not change an output, it is busywork. In practice this means most projects get zero questions from you here, and that is the correct outcome.

**Pin terms as they surface.** If a coined name or overloaded word comes up in conversation, write it to `GLOSSARY.md` right then. Don't solicit a term list cold — people recognize jargon in use, not on demand.

**Promote cross-project terms to the lexicon.** Follow **`AUTHORING.md` § "Promoting a term back to the lexicon"** — the canonical procedure (the offer wording, the default-Yes rule, the visibility default). Read it before offering; don't improvise the wording.

**Only rewrite the `.system/project.md` description if it is now wrong.** It came from the author. If the sources reveal it to be materially inaccurate or too narrow, propose a replacement and say why; otherwise leave it exactly as it is. Do not rewrite it merely to sound more like you.

## Step 3 — Project type and stack (inferred)

Infer the project kind from the title, the description, and the dropped sources — it sets whether there's a stack to infer at all. Then state your inference in one sentence and proceed. **Don't** ask "Sound right?" — if the inference is obvious, state and continue.

- **Planning/research** → no stack yet (designs, data sourcing, open decisions). Add one later when the user's ready.
- **Docs/process** → no stack (documentation, playbooks).
- **Operational / "do something"** (set up a machine, migrate data, clean up a service) → usually no code stack; the work *is* the steps, captured in PLAN.md.
- **Code build** → infer the **language/runtime/build-tool layer** from sources + brief.

State the inferred kind (and stack, if any) with one sentence of reasoning. Examples:
- *"This is a Python project — the ML work (prediction algorithm + atmospheric data) makes it the obvious fit. Going with that."*
- *"This is a planning/research project for now — no code yet, just designs and data sourcing. We'll add a stack later when you're ready."*
- *"This is an operational task — setting up the system on a new machine — so there's no code stack; I'll capture the steps in PLAN.md."*

Proceed unless the user pushes back. Only if genuinely ambiguous (e.g., the project could reasonably be Python or Node), state your two options with a leaning, ask once, and proceed.

## Step 4 — Write the project overview (when it adds over CLAUDE.md)

Source materials (if any) are in `references/` (already sorted in Step 1.5; **do NOT re-copy or modify them**). Working content (if any) has been promoted to project root.

**First decide whether the overview earns its place.** Write it when there's a synthesis to make — multiple sources to integrate, non-trivial intent/why, success criteria, or open unknowns. **Skip it** when the project is thin enough that the overview would just restate CLAUDE.md's Project line + the `.system/project.md` description with nothing added (small operational "do something" tasks: no sources, intent fits a sentence, no real unknowns). When you skip it, say so in one line (*"Skipping a separate overview — CLAUDE.md + the project.md description already capture this thin a project"*) and move on. When in doubt, write it.

**When you write it, write it as `<project-name>.md` at the *project root*** — named after the project folder, lowercase kebab (e.g. `website-builder/` → `website-builder.md`). Compute the name with `basename "$PWD"`. It sits alongside `CLAUDE.md` / `PLAN.md` / `DECISIONS.md` / `CHECKLIST.md`, but unlike those fixed ALLCAPS system slots it carries the project's own name (see `CONVENTIONS.md` § "Document naming"). It's the source-of-truth for what the project IS. Synthesize from ALL files in `references/` AND any promoted working-content directories at project root AND your conversation so far. If there are multiple sources, integrate across them — don't just summarize each one separately.

Structure (note the H1 is the project title, *not* "Brief:"):

```
# <Project Title>

**What this is:** 1-2 sentences.
**Why it exists:** 1-2 sentences — the problem this solves, the value it produces.
**Success criteria:** 2-4 bullets — what "done" looks like for v1.
**Unknowns / open questions:** 2-4 bullets — what we don't yet know.
**Source materials:** (only if any) — list each `references/<filename-or-dir>` with one sentence on what it contains and how it informed the overview. If working content was promoted to project root in Step 1.5, also note where it lives (e.g., "the scripts/ directory at project root holds the EdgeTX Lua scripts dropped at intake").
```

Show the overview to the user. Adjust if they push back. Do NOT ask "look good?" — show and proceed unless they object.

## Step 4.5 — Phase preview (gate before PLAN.md is written)

Before generating any project files, state the proposed PLAN.md phase decomposition as a short preview — 3-6 phases, **one line of scope each**. Use the canonical `Phase N: <Name>` shape PLAN.md will adopt (see Step 6 § PLAN.md). Example shape:

```
Proposed phases:
1. Phase 1: Bootstrap — set up repo, dependencies, baseline test harness.
2. Phase 2: Core engine — implement the prediction algorithm and unit tests.
3. Phase 3: Wire-up — connect engine to data sources + CLI.
4. Phase 4: Polish — error handling, docs, release packaging.
```

Then ask once: ***"Phases look right? [Y/n/edit]"***

- `Y` / Enter / silence → proceed to Step 5.
- `n` → ask which phase is wrong (number or name), adjust, re-show once, then proceed.
- Free-form edit ("split Phase 2 into engine + tests", "add a research phase up front") → fold in the change, re-show once, then proceed.

Don't re-loop more than once. If the user keeps editing, capture the final shape and move on — phase names can still be adjusted in PLAN.md later.

**Why this gate exists:** phase decomposition is an inference Claude makes from the brief, but the brief doesn't itself dictate phases. Mis-decomposed phases are expensive to recover from — they ripple into PLAN.md, CHECKLIST.md, CLAUDE.md's Status field, and Open Decisions phase tags. This is the one structural moment the brief-show in Step 4 doesn't cover. It's the only structural gate in the whole flow — keep it light.

## Step 5 — Scaffold (code projects that have no code yet)

For pure-docs / planning projects: skip.

For a code project with a clear stack and no existing code: ask once — *"Want me to scaffold the basics (e.g., `npm init -y`, `python3 -m venv .venv && pip install ...`)?"* — default yes when the project is genuinely empty. Run the appropriate init commands.

## Step 6 — Generate project files

Generate each file to fit THIS project. Before generating CLAUDE.md, **read expert examples** so your output patterns on proven shapes — not just on principle distillation.

### Read references first (CLAUDE.md specifically)

Before generating, ground your output on proven shapes — not just principle distillation:

- **Canonical spec:** `AUTHORING.md` § "`CLAUDE.md` — the section menu" (see *CLAUDE.md generation* just below — read it first). It defines every section and how to author it.
- **In-house examples:** read a couple of existing managed `CLAUDE.md` files in `~/Projects/Active/` (and `~/Projects/Archive/`) that match this project's kind, as shape references — the workspace's own mature CLAUDE.mds are the pattern library.
- **Related projects:** if one has overlapping scope (e.g., this project supersedes a nearby "v1"), read its `CLAUDE.md` — its conventions, structure, and don'ts may extend here. Mention any such related project in this project's `CLAUDE.md`.

**Pattern your output on these examples; adapt for this specific project.** Do not copy verbatim. Do not omit sections the examples populate just because *this* project's content is partial or proposed — better to include with appropriate framing ("Proposed", "TBD", "tentative") than to omit and produce a thin file.

### CLAUDE.md generation

Generate based on the section menu + those in-house examples + this project's substance + project type.

**The section-by-section spec is canonical in `AUTHORING.md` § "`CLAUDE.md` — the section menu" — read it before generating.** It defines every section and how to author it: Status, Project, Identifiers, Open Decisions (+ `locked-open` semantics), Stack (no-limbo), Structure (two modes + name-don't-materialize), Router table, Commands, Conventions, Don't, Related projects, Claude Code tooling — plus the two cross-cutting rules (no "Working Agreement" summary layer; length follows substance, no `<placeholder>`). That menu is shared with `/init-claude-md`; don't re-inline it here.

What follows is only the part specific to *this* command: how you propose Conventions and Don't entries.

#### Conventions / Don't — the per-entry review

Conventions and Don't entries are the exception to "proceed by default" — they're project rules that depend on context you don't have (decisions the user/team made, knowledge about people involved, ground-truth answers to ambiguities). **Propose each candidate one at a time before writing**, with one sentence of reasoning. End each proposal with a numbered shortcut line (the one exception to "no numbered menus" — a fixed 3-way choice repeated many times warrants it):

```
[1] confirm   [2] change   [3] reject   (or type your answer / edit)
```

Handle the response:
- `1` / affirmative / "yes" / silence → write as proposed
- `3` / "no" / reject → skip
- `2` / "change" / a modification → adjust and write the revised version
- "I have the answer" (free text) → don't make it a convention; capture the answer in the overview / plan / decisions instead
- **A question about the candidate** ("what does X mean?", "why this?", "where did this come from?", "give me an example") → answer concisely, then re-display the *same* candidate and shortcut line. Don't advance to the next candidate, don't write it, don't restart the review. Stay on this one until the user picks 1/2/3 or supplies an answer.

Track the queue explicitly. Label each proposal at the top with `Convention entry N of M:` or `Don't entry N of M:` — always with the "entry" buffer word (never "Convention 2" / "Don't 2" / "Don't #2", which read as imperatives) — and use the same phrasing in any follow-up reference ("ready to proceed with Don't entry 2?"). After 1/2/3, advance to N+1; questions do not advance N.

Watch for the **convention-vs-question trap:** if you spotted an unknown in the source (a discrepancy, missing info, ambiguity), don't reflexively turn it into a "verify-before-X" rule. *Ask the user directly* first — they may have the answer right now, and then the convention isn't needed at all.

### PLAN.md

Generate real phases derived from the overview. Each phase has a short descriptive name and 3-5 sub-bullets reflecting actual next actions. Reference the project overview (`<project-name>.md`) at the top so future-Claude knows where the source-of-truth is.

**PLAN.md owns the canonical phase names.** Use the form `Phase N: <Name>` (e.g., `Phase 1: Bootstrap`, `Phase 2: Sound-Library-Stable`). Every reference to a phase elsewhere — CLAUDE.md Status field, CLAUDE.md Open Decisions phase tags, CHECKLIST.md headers, CHECKLIST.md closeout tasks — uses these exact names verbatim. **Mismatched phase names across files is a recurring drift point** — name once in PLAN.md and copy from there.

**Every Open Decision must appear as an explicit decision-deliverable task in its tagged phase's PLAN.md section.** Tagging a decision `(Phase 2)` in CLAUDE.md isn't enough — the phase has to own its resolution. Bad: Phase 2 of PLAN.md is "Model backups" with no mention of the bind-phrase decision tagged Phase 2 in CLAUDE.md. Good: Phase 2 explicitly opens with *"Resolve `bind-phrase handling for models/*.yml` — pick: scrub / store-separately / accept-if-private. Capture in DECISIONS.md."* Decisions are first-class deliverables, not implied side-quests.

**Decisions that fork downstream phases deserve milestone status, not peer items.** If a Phase 1 decision (e.g., "self-file vs. CPA") fundamentally changes what Phase 4 looks like, promote it to its own milestone — not a peer bullet alongside information-gathering tasks like "enumerate sources." A forking decision and a fact-gathering task aren't the same shape of work.

Concrete shape (illustrative, not prescriptive):

```
# Plan

See `<project-name>.md` for the working contract and source materials.

## Phase 1: Research

- <concrete action>
- <concrete action>
- ...

## Phase 2: Design

- <concrete action>
- ...
```

Never write "Phase 1 / Step 1 / Step 2" placeholder text — write the actual work.

### DECISIONS.md

Write at least one entry — the project-type / scope decision — with today's date. Use the existing format (Context / Options / Chose / Reasoning).

**The bar for what merits an entry, the entry shape, and the `Revisit:` / `Revisit if:` triggers are canonical in `AUTHORING.md` § "`DECISIONS.md` — the bar for what merits an entry" — read it before generating.** In short: record a choice only when it is hard to reverse AND surprising without context AND the result of a real trade-off; the project-type/scope decision is the standing exception that is always recorded.

**Write the preamble into the file.** `AUTHORING.md` carries the exact block; it goes at the top of every generated `DECISIONS.md` so the standard is visible to whoever opens the file next. (It used to arrive via a `_template/DECISIONS.md` stub; the template is gone, so the generator writes it.)

If the overview surfaces other early decisions (e.g., "docs-first because no stack yet", "default-yes carry-forward of TypeScript from related project") that clear the three-part bar, capture each as an entry.

### GLOSSARY.md

**Read `AUTHORING.md` § "`GLOSSARY.md` — canonical project language" before generating.** It is the single home for the file format, the entry shape, the rules (glossary-only, project-specific terms only, be opinionated, `_Avoid_` holds every form to correct *to* the term), and the lexicon seed. Don't restate any of it here.

Specific to this command:

- **The lexicon seed already happened in Step 2** — the early opening move. If for any reason it didn't, do it now.
- **Then add whatever the overview and sources yielded**: coined names, overloaded words you've pinned to one meaning, and **third-party tool/product/brand names that are the project's subject matter or recur as canon** (each with an `_Avoid_` line for the common wrong-case variants — `GitHub` — _Avoid_: Github, github, Git Hub). Those spellings are *vocabulary* and live here — **not** as a "spell names right" Convention, which would only restate the global brand-fidelity rule.
- **Skip the file entirely** when the project is genuinely term-less: no lexicon term applies and nothing coined surfaced. Don't write a stub beyond the seeded term(s). A later `/grill` creates or extends it as terms resolve.

### CHECKLIST.md

Write Phase 1 tasks matching PLAN.md. Real, project-specific actions — not "Task 1 / Task 2".

**Phase-closeout tasks should name the successor state**, not be open-ended. Instead of *"Update CLAUDE.md Status away from Pre-decision"* write *"Update Status to Design (Phase 2) or Scaffolding (Phase 3), whichever Phase 1 closeout lands on."* Open-ended instructions get skipped or done vaguely.

### Typo pass on user-supplied content

When you read `.system/project.md` during orientation, flag obvious typos in the user-supplied **title** (the one field `newproject` captures verbatim). One line: *"Spotted 'algorythym' in the project title — likely 'algorithm'; want me to fix?"* Default yes if no objection. (Note: the description was written by the author at registration — don't silently reword it; see Step 2. There is no `README.md` by default; it's opt-in only.)

## Step 7 — Content-level audit

Before claiming Step 6 done, verify and **state plainly what you checked**:
- No `<placeholder>` text in any file
- `PLAN.md`, `DECISIONS.md`, `CHECKLIST.md` have real, project-specific content
- `CLAUDE.md` has only sections that apply (no empty Stack/Commands/Conventions/Don't)
- `<project-name>.md` (the project overview) exists, is named after the project folder, and reflects the synthesis
- `GLOSSARY.md` exists if the project has ≥1 coined term (else correctly absent — not an empty stub)
- Source materials in `references/<original-filename>` are preserved as-is (if provided)
- No restatement of rules already in `~/.claude/CLAUDE.md` or the system prompt
- **Cross-reference jargon hygiene:** if a section uses a term defined in a later section (e.g., a `## Related projects` line mentioning "Cheshire-spec canon" while `## Conventions` is the section that defines it), either reorder or gloss it on first use. Future-readers shouldn't have to read the file twice.
- **Open Decisions ↔ PLAN.md ↔ CHECKLIST.md alignment:** every Open Decision should have a phase tag matching where it gets resolved in PLAN.md. Phase 1 decisions should appear as tasks in CHECKLIST.md Phase 1. Decisions tagged for later phases shouldn't appear in Phase 1's checklist. **Each Open Decision must appear as a decision-deliverable task in its tagged PLAN phase** — tagging without follow-through is drift. Catches drift between the three files.
- **Stack ↔ DECISIONS.md alignment:** committed Stack items and default-yes carried-forward items should have corresponding DECISIONS.md entries. No item in Stack should be in a "proposed without resolution path" limbo state.
- **PLAN ↔ CHECKLIST task order alignment:** within each phase, the task order in CHECKLIST.md should mirror PLAN.md's narrative order. If PLAN says "decide X, then run Y" and CHECKLIST says "locate inputs, decide X, run Y," update PLAN to match — CHECKLIST tends to be the more accurate document because it's where execution lives.
- **Phase name consistency:** the phase names in CLAUDE.md Status field, CLAUDE.md Open Decisions phase tags, PLAN.md `## Phase N: <Name>` headers, CHECKLIST.md `## Phase N: <Name>` headers, and CHECKLIST.md closeout tasks must all use the *same name* for the same phase. PLAN.md is the canonical source — copy from there.
- **Concrete details preservation:** if source materials in `references/` contain concrete details — hardware specs (model numbers, receiver types, version pins), vendor IDs, account names, file sizes, exact version requirements — those details should appear in `CLAUDE.md`'s Stack/Conventions or in the project overview (`<project-name>.md`). If a detail is in the source but missing from synthesis, surface it before claiming done. The overview should never *lose* data; it should *organize* it.
- **Post-synthesis source-doc cleanup:** after synthesis, handle a consumed source doc in `references/` — but first classify what it is, because the two kinds are treated differently (see `CONVENTIONS.md` § "The project overview and references"):
  - **Originating brief** — a descriptive doc the user dropped to *spawn* the project, now substantially absorbed into the overview + `CLAUDE.md` + project files (the "brief-duplication smell"). Offer, behind an **explicit confirm**, the cleanest option: **(a) delete it** — it's fully absorbed and recoverable from git history (only offer delete once `git init` has committed it, or note it'll be committed first; for an *uncommitted/private* source where deletion would be unrecoverable, offer freeze instead). Alternatives if the user declines delete: **(b) freeze** with an archival header pointing to the live docs, or **(c) extract** any unique content not yet in `CLAUDE.md` and then remove. Default-recommend (a) when synthesis is verified complete; never silently leave the duplicate in place, and **never auto-delete without the confirm**.
  - **Reference archive** — material meant to be *consulted forever* (e.g., a `Bolo_Goodies/` directory of canonical source). **Never targeted** by cleanup — not deleted, frozen, or rewritten. Leave it exactly as-is.

  Only ever target a fully-absorbed *originating brief*. When in doubt about which kind a `references/` item is, treat it as a reference archive and leave it.
- **Date hygiene:** keep dates only where they carry weight — incident anchors (*"after the 2026-04-29 prod write"*), deadlines, version-pinned constraints. Strip "shipped on" / "updated on" / "as of" decoration that doesn't change Claude's behavior. Heuristic: **if removing the date wouldn't change how Claude reads or acts on the line, the date doesn't belong there** — it'll just age into noise.
- **Code-snippet check on rules that name a calling pattern:** every Convention or Don't that says *"always call X this way"* / *"use helper Y not Z"* should carry the 2-5 line snippet inline, not just the prose. If the snippet is missing, write it now — don't ship a prose-only rule that names a specific calling pattern.
- **Header-count consistency:** if CLAUDE.md introduces a section with a count claim (*"These 10 rules apply…"* / *"the 7-role set"* / *"all three folders"*) the count must match the actual contents. Mismatch is a drift signal — fix the number AND treat it as a flag to re-read nearby sections for other stale claims.
- **Router cell scope** (only when CLAUDE.md has a Router table): each left-column cell is a user-intent trigger phrase (5-15 words); each right-column cell is path + one sentence of orientation. If a cell has nested parentheticals summarizing the destination doc's contents, trim it — the destination doc carries the detail.

## Step 8 — Git

**First check whether there is already a repo:** `git rev-parse --git-dir`. If there is, **do not `git init` over it**, and do not commit work you didn't create without showing what's being added first. Skip to the identity backfill at the bottom of this step.

If there is **no** repo, initialize one:
- `git init -b main`
- **Write the no-remote commit identity (umbrella include) — before the first commit.** Under `user.useConfigOnly = true`, a repo with no remote and no identity rule *refuses* to commit, so this must precede `git commit`. Resolve the umbrella, then write an `[include]` (indirection — the umbrella's name/email stays editable in one file):
  - **Umbrella id:** use `.system/project.md`'s `umbrella:` field if set (e.g. recorded by `newproject --umbrella`). If absent, list candidates with `git config -f ~/.gitconfig.local --get-regexp 'includeIf.*hasconfig.*\.path'` — each value is `~/.gitconfig-<id>` and the `<id>` suffix is an umbrella. One candidate → use it; several → ask which umbrella this project belongs to; **none** (single-identity user — no `hasconfig` rules) → **skip this step entirely** (the global git author already covers commits).
  - **Write it:** `git config --local include.path "~/.gitconfig-<id>"`, then record the chosen `<id>` back into `.system/project.md`'s `umbrella:` field if it wasn't already there.
- Write `.gitignore` appropriate to project type (Node: `node_modules/`, `dist/`, `.env*`; Python: `__pycache__/`, `*.pyc`, `.venv/`; pure docs: `.DS_Store` is enough) One pattern per line; never put an inline `#` comment after a pattern (git treats the whole line as the pattern, so the ignore silently fails). Put any comment on its own line.
- `git add` the populated files (include `references/` unless a source could be private — ask only in that case)
- `git commit` the initial commit.

**Identity backfill (for a repo that already existed).** If it has **no remote** and no `include.path` set, a future commit would hit `user.useConfigOnly` and be refused. Resolve its umbrella and write the include exactly as above (`git config --local include.path "~/.gitconfig-<id>"`). This adds identity routing only — never content, never history. A repo that already has a remote is alias-routed; leave it alone.

There is no marker to consume. `/setup-project` is safe to re-run at any time by construction: it creates only what is absent, so a second pass simply finds less to do.

## Step 9 — Connect a git remote (single y/N, default N)

Ask once: *"Connect this project to a git remote now? (y/N)"* — default N. If no, skip silently.

The system encodes **no** GitHub identity — no org table, no account constant, no SSH-alias. Everything is host-agnostic or read live from `gh`. If yes, offer three choices:

1. **Connect an existing repo** (any host — GitHub, GitLab, self-hosted).
2. **Create a new GitHub repo** (GitHub-only; needs `gh`).
3. **Skip.**

**Whenever a remote is connected (choices 1 or 2), drop the no-remote include:** `git config --local --unset include.path 2>/dev/null || true`. The remote URL's SSH alias now routes commit identity via `~/.gitconfig.local`'s `hasconfig` rules; a leftover include would shadow it. (This is the other half of the one rule — *write the include at `git init`, drop it on remote-connect.*)

### [1] Connect an existing repo (host-agnostic, the default path)

The repo must already exist. Ask: *"Paste the repo's clone URL — from its Code button, HTTPS or SSH both work. Create an empty repo first (e.g. github.com/new) if it doesn't exist yet."* Then:
- `git remote add origin <url>`
- **Check visibility before the first push:** run `~/project-system/bin/repo-visibility.sh "<url>"`. It prints `private` / `public` / `unknown` (robust to multi-account / SSH-alias setups). If `private`, push silently. If `public` or `unknown`, this push *publishes* to a repo that isn't confirmed-private — show what's about to go up and confirm first.
- `git push -u origin main`
- Success → show the remote URL. Failure (e.g. the remote already has commits) → surface git's error and the manual command; don't die. A custom SSH host alias (e.g. `git@github.com-you:org/repo.git`) just rides in the pasted URL — nothing to configure.

### [2] Create a new GitHub repo (optional, GitHub-only)

Requires `gh` installed + authenticated. If it isn't, say so and fall back to [1]. No org mapping, no hardcoded account — read it all live:
1. `gh auth status` — list the authenticated accounts. **If 2+**, ask the user which should own the repo (offer the accounts and, for the chosen one, its orgs via `gh api user/orgs --jq '.[].login'`); capture the currently-active account, then `gh auth switch --user <chosen>`. **If 1 account**, skip the prompt.
2. `gh repo create <owner>/<folder-name> --private --source=. --remote=origin --push --description "<the description from .system/project.md body>"` — `<owner>` is the chosen account or one of its orgs. (Default `--private`; ask if the user wants it public.)
3. If you switched accounts in step 1, `gh auth switch` **back** to the originally-active account so the user's terminal isn't left on a different identity.
4. Show the repo URL.

### [3] Skip — finish silently.

## Step 10 — Wrap up

### Step 10a — Open Finder (required, not optional)

Run this Bash command **now**, before composing the summary:

```sh
open .
```

This must actually be executed via the Bash tool — not described, not skipped, not left to the user. The user expects Finder to pop while they're still in the Claude session.

### Step 10b — Print the summary

After Finder has been opened, print a short summary. The first line must acknowledge that Finder was opened — this serves as confirmation:

```
📂 Project folder open in Finder.

- What this is: <1 line>
- Overview: <project-name>.md (project root)
- Remote: <URL if connected, otherwise omit>
- (If relevant) CLAUDE.local.md is opt-in for personal-only setup; gitignored globally if you create it.
- `/grill` any time to go deeper; `/project-status` refreshes the dashboard chip.

Ready to start working — what would you like to do?
```

If you skipped `open .` for some reason, do not include the "📂 Project folder open in Finder" line — that line is the user's signal that the open happened.

### Step 10c — Report, then offer the deepening

**Report created vs. skipped** — the audit trail that closes the loop opened by Step 0's inventory. Name the files you created, the ones you deliberately skipped (and why: "no coined terms surfaced, so no `GLOSSARY.md`"), and the **identifying-detail level** you wrote at.

**If the project already had its own `CLAUDE.md`** in a different shape, you left it untouched — say so explicitly and offer the reconcile path:

> "You already have a `CLAUDE.md`; I left it untouched. It's shaped differently from the system's (Status / Open Decisions / …). Want it reconciled to that shape? Run `/grill` — that's the tool that edits existing docs, with your confirmation."

**Do not offer the grill again here.** That decision was made in Step 2, at the only point where it was free — before anything was written. Re-raising it now would be asking the user to authorize *revising* the documents you just produced. A single factual line in the summary is enough: `/grill` is available any time.

## Out of scope

- Don't modify `~/project-system/`, `~/.claude/`, or `~/dotfiles/`.
- Don't auto-commit anything outside the new project's git repo.
- Don't skip the audit step.
