---
description: Refresh a project's cached status chip — an agent judgment of where the project actually stands, read from PLAN/CHECKLIST/DECISIONS/git, written ONLY to the local gitignored .system/status (never edits CLAUDE.md, never commits, never pushes — a purely local refresh). No arg = the project at cwd; `--all` = every Active/Inactive project, skipping unchanged ones.
---

You are refreshing the **status chip** the projects dashboard shows next to each project.

## Why this exists

The dashboard (`proj`) couldn't show *what step* a project is on. A hand-typed status
field was rejected long ago — it "became silently incorrect because nothing rewrote it
on `mv`" (CONVENTIONS.md). A grep-derived one is no better: checkboxes go stale, so a raw
`4/7 done` count *lies* when the work is actually finished.

The honest source is a **judgment** — exactly what you do when you read a project and reason
about where it stands (including reconciling stale-but-done checkboxes). This command caches
that judgment, **timestamped and stamped with the commit it was judged against**, so the
dashboard can show it *and* flag when it has gone stale. The project's own artifacts
(`PLAN.md` / `CHECKLIST.md` / `DECISIONS.md` / code / git) stay the source of truth; the chip
is a re-derivable cache of your read of them.

## Mode

- **No argument** → judge the project at the current directory. Resolve its root with
  `git rev-parse --show-toplevel` (fall back to the nearest ancestor under
  `~/Projects/{Active,Inactive,Archive}/<name>/`). If the cwd isn't a managed project, say so
  and stop.
- **`--all`** → judge every Active + Inactive project. Get the list from
  `~/project-system/bin/list-projects.sh --paths` (lines `N:Section/name` →
  `~/Projects/Section/name`). **Skip any project that hasn't changed** (see *Skip-unchanged*).

## Per project — judge, then write

For each project directory `$DIR`:

### 1. Skip-unchanged (only in `--all`)
Read `$DIR/.system/status` if it exists; its third field is the HEAD sha it was judged
against. If that sha equals `git -C "$DIR" rev-parse HEAD`, the cached chip is still
accurate — **skip this project**, don't re-judge. (In no-arg mode, always re-judge — the
user asked for it explicitly.)

### 2. Read the artifacts and judge
Read what's present — don't assume every file exists:
- `PLAN.md` — the current phase and what's left in it.
- `CHECKLIST.md` — **judge, don't count.** Reconcile boxes against reality: an item left
  unchecked but plainly done (the work shipped, a later doc supersedes it) counts as done.
  This reconciliation is the whole point — it's what a raw count can't do.
- `DECISIONS.md` — recent decisions, and any `Revisit:` triggers now due.
- `git -C "$DIR" log -1 --format='%cr · %s'` and `git -C "$DIR" tag --sort=-creatordate`
  / `git -C "$DIR" describe --tags --abbrev=0` — recency and the latest milestone tag.
- The existing `## Status` in `CLAUDE.md`, if any — useful prior context to *read* (you will
  **not** write to `CLAUDE.md`; see step 4).

Form a verdict: what step is this project genuinely on, and what (if anything) blocks it.

### 3. The chip (output contract — pin this)
Produce **one line, ≤ 50 characters**: current milestone/phase, then an optional blocker,
separated by ` · `. It is a glance, not a sentence — no trailing period.
- `v1 stable · maintenance only`
- `Phase 2 · blocked on FreshBooks API`
- `Phase 3 · PoC code in, smoke test pending`
- `Phase 1 · sourcing data`

### 3b. Classify the state (drives the dashboard colour)
Tag the chip with one **state** — judged by *where the user's attention belongs*, not by
keywords. **Judge, don't pattern-match** (`Phase 1 done · Phase 2 design next` says "done" but
is **actionable** — the user's move is Phase 2):
- **`actionable`** — the ball is in the *user's* court: a next step is ready, a phase just
  closed and the next is teed up, something's built and waiting for them to run/wire/ship it
  (`Phase 2 design next`, `runbook ready, not yet run`, `smoke test pending`). The high-impact
  bucket — the dashboard highlights these.
- **`pending`** — waiting on someone/something *external* (a reply, an input, a credential, an
  upstream): the user can't move it themselves right now (`blocked on Chris's reply`,
  `awaiting playbook interview`, `gated on David`).
- **`good`** — done / stable / a healthy resting state needing nothing (`v1 stable · maintenance
  only`, `Engine live`, `feature-complete`). The dashboard demotes these.

When genuinely ambiguous, prefer **`actionable`** over `good` — better to surface work than hide it.

### 4. Write the chip — local only, no git
Write the chip to **one** place: `$DIR/.system/status` (the dashboard's cache, gitignored via
the per-project `.system/` rule). A single line, exactly:

```
<chip> ⟂ <YYYY-MM-DD> ⟂ <judged-HEAD-sha> ⟂ <state>
```

Use ` ⟂ ` (U+27C2, space-padded) as the delimiter — it never appears in chip text. Date from
`date +%F`. The sha is the **current** HEAD — you are NOT committing, so stamping current HEAD
makes the dashboard read the chip as fresh until the next commit moves HEAD past it. If `$DIR`
isn't a git repo, write an empty sha field (the dashboard skips the stale check). `<state>` is
the bucket from step 3b (`actionable` / `blocked` / `good`).

```sh
SHA=$(git -C "$DIR" rev-parse HEAD 2>/dev/null)
printf '%s ⟂ %s ⟂ %s ⟂ %s\n' "<chip>" "$(date +%F)" "$SHA" "<state>" > "$DIR/.system/status"
```

**This is a purely local operation.** Do NOT edit `CLAUDE.md`. Do NOT `git add` / `commit` /
`push` anything. The chip lives only in `.system/status` (gitignored) — it never enters the
project's git history or GitHub. (The project's `CLAUDE.md ## Status` is a *separate*,
human/`/grill`-maintained narrative; this command does not write it.)

## Report
- No-arg: one line — the project and its new chip.
- `--all`: a short table — refreshed (with chips) vs skipped-unchanged. Note anything you had
  to reconcile (e.g. "<project>: 2 checklist items were done-but-unchecked — counted as done").

## Don't
- Don't invent progress the artifacts don't support — if a project is genuinely stalled, the
  honest chip says so.
- Don't touch `CLAUDE.md` at all — the refresh is local-only; `## Status` there is the human's.
- Don't `git add` / `commit` / `push` — the chip is a local gitignored cache, never git history.
- Don't write the chip anywhere but `.system/status` (no new field, no INDEX.md annotation).
