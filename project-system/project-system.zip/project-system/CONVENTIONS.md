# Project System Conventions

The principles and decisions behind how my project system is organized.
Read this before reorganizing, adding structure, or changing the system.

## The split: workspace vs system

The project system lives in two sibling directories under `~/`:

```
~/
├── Projects/              # WORKSPACE — where the actual work happens
│   ├── Active/            # engaged now — building or using (shown)
│   ├── Inactive/          # dormant but alive — paused, placeholder, will-resume (shown)
│   └── Archive/           # done/terminal record, date-stamped (hidden by default)
│
└── project-system/       # SYSTEM — the meta-layer that defines and operates on the workspace
    ├── README.md          # what this repo is, how to bootstrap on a new machine
    ├── CONVENTIONS.md     # this file
    ├── INDEX.md           # master list of all projects
    ├── LEXICON.md         # personal cross-project vocabulary (gitignored)
    ├── _template/         # starter files for new projects
    └── bin/               # scripts that operate on the system itself
```

**Why split:** `~/Projects/` is the *workspace* — pure content, every item is a project or a folder of projects. `~/project-system/` is the *system* — the conventions, index, scaffolding, and tooling that define how the workspace is organized. They are different concerns and deserve to live separately. The capital-P / lowercase distinction reinforces that visually: Apple-style "this is content" vs. Unix-style "this is infrastructure."

`~/project-system/` is itself a private git repo (`y3klab/project-system` on GitHub). The workspace is not a git repo — individual projects in `~/Projects/Active/` and `~/Projects/Inactive/` may be their own git repos with their own remotes, but the workspace as a whole is just a folder.

**Workspace backup is per-project, and the system can see the gaps.** Because the workspace isn't a repo, a project is only recoverable off-machine if *it* is a git repo with a pushed `origin` remote. The system doesn't enforce that — but `bin/audit-backups.sh` (alias `audit-backups`) reports it: a read-only sweep of Active + Inactive that flags projects with no remote (or no repo at all), so "is my portfolio recoverable?" is answerable. `Archive/` is out of scope (a local-only keepsake shelf is fine). A project that is *deliberately* local opts out with a `backup: local` line in its `.system/project.md` (see `AUTHORING.md`), which the audit acknowledges instead of flagging.

## Project identity: umbrellas

Each project belongs to an **umbrella** — an *access identity*: a GitHub account, its SSH host-alias, and the orgs it can reach. A multi-identity user runs more than one; the identity map (human names, accounts, aliases, orgs) lives in the global `CLAUDE.md`, loaded into every session. A project declares its umbrella in `.system/project.md` (`umbrella: <id>`) — the *self-describing node* principle: the project carries the fact, the tooling reads it rather than guessing. **The id is the suffix of the umbrella's `~/.gitconfig-<id>` identity file** (e.g. `umbrella: acme` → `~/.gitconfig-acme`), not a friendly label — that suffix is the value the no-remote include resolves against (below); the human name (e.g. "Acme Corp") stays in the identity map.

The umbrella's job is to make **commit-author identity correct and never guessed**. Three identity axes are deliberately decoupled — conflating them is what stamps one umbrella's commits with another's email:

- **Access** — which `gh` account can *see* a repo (org membership). Lives on GitHub.
- **Push routing** — which SSH key reaches a remote. Pinned per repo by the remote URL's host-alias (`git@github.com-<id>:…`).
- **Commit author** — the name/email *stamped on commits*. Resolved by `~/.gitconfig.local`, never guessed. Repos **with a remote** are matched by their SSH alias (`includeIf "hasconfig:remote.*.url:…"` → `~/.gitconfig-<umbrella>`). Repos **with no remote** carry a repo-local `[include] path = ~/.gitconfig-<umbrella>` — *indirection, not a copied-in email*, so an umbrella's identity changes in one file and every no-remote repo of that umbrella follows. `user.useConfigOnly = true` makes git **refuse to commit** where neither matches — the refusal *is* the guarantee.

The candidate umbrellas are exactly the ones named by the `hasconfig` rules in `~/.gitconfig.local` (a `gitdir:`-routed file — a single project's override — is *not* an umbrella). The author-resolution rule is uniform: **write the include at `git init`** (so the project's first commit has an identity under `useConfigOnly`) and **drop it when a remote is connected** (the SSH alias routes from then on). One writer owns it — `setup-project`: Step 8 writes it after `git init`, before the first commit; Step 9 drops it on remote-connect; adopt mode backfills it for an existing no-remote repo that lacks one. `newproject` never inits a repo, so its optional `--umbrella <id>` flag only records the field in `.system/project.md` for `setup-project` to consume. A remote added **by hand** leaves the include behind to shadow the alias — `audit-backups.sh` flags any repo whose remote and lingering include disagree.

A new umbrella is a new pair of `includeIf` rules + a `~/.gitconfig-<id>` identity file; a project moves umbrellas by changing one field (and its alias, if it has a remote). Single-identity users never need any of this — one global git author covers everything and `umbrella:` is omitted.

## The three folders: Active, Inactive, Archive

The workspace asks one question constantly: **am I engaged with this or not?** That's the `Active` ⇄ `Inactive` split. `Archive` is the third folder because archiving is an *action*, not merely a state — it date-stamps the folder and takes the project out of the daily view. Each folder has one clear role:

- **`Active/`** — Engaged now: building *or* using. Anything you're currently working on or currently reaching for — a half-built tool, a finished-but-in-use tool, a job in progress. A project's type or completion % is a property you *see on opening it*, not a folder.
- **`Inactive/`** — Dormant but alive: paused builds, captured-but-not-started placeholders, things waiting on a stakeholder or on your attention. Not engaged right now, but you might resume — so it stays *in view*.
- **`Archive/`** — Done/terminal, preserved for reference. The artifact has graduated elsewhere (into a separate repo, into `dotfiles/`, into a tool you've installed) or there was never a runnable artifact to begin with. Date-stamped (`foo` → `2026-foo`) and **hidden from the daily view** — you keep it to read later, not to re-run.

All three are **things you keep**. The trash bin is the mover's Delete action — separate and deliberate, never one keystroke away.

A **temperature map** captures it: Active = warm, Inactive = cool, Archive = grey (hot / cold / dead). The dashboard colours the headers to match — warm advances, cool recedes — so Active naturally pops forward and Inactive recedes; the colour enforces the hierarchy for free.

### Why type doesn't earn a folder

The old system kept a separate `Library/` for living tools, on the theory that a tool and a job are different kinds of object. They aren't — they're the same object at different completion %. The deciding insight: **using a tool produces a *result*, not a project.** The result goes to an external system of record (a client's Drive folder, your tax records), *not* the workspace. So a finished, in-production tool you still reach for is simply **Active** (you're engaged with it); a tool you've set down is **Inactive**; a tool whose job is wholly done is **Archive**. No type axis required — see "The tool vs job pattern" below.

### The lifecycle flow

```
   Active   ⇄  Inactive          (deactivate / activate)
   Active   →  Archive           (archive — date-stamped, leaves the view)
   Inactive →  Archive           (archive)
   Archive  →  Inactive          (unarchive — drops the date prefix; thaws to
                                  Inactive, then activate if you want it warm)
   (any)    →  Delete            (deliberate, double-confirmed)
```

**How you move things along it.** Transitions happen from the dashboard, not by memorising command names — there are no standalone *transition* scripts (creation has two standalone commands — `newproject` to scaffold, `importproject` to adopt — but moving along the lifecycle does not). At the `proj` / `list projects` picker, arrow to a project (or type its number to jump the cursor) and press `m` to open the mover for it — `m<#>` in the non-interactive fallback prompt. It offers only the transitions valid from where that project currently sits — Active → deactivate/archive/delete, Inactive → activate/archive/delete, Archive → unarchive/delete — and drives the shared `_lifecycle.sh` engine. Moves are single-action (picking the destination is the confirm, since you already chose the project); only delete double-confirms. **Unarchiving thaws to `Inactive`, not `Active`** — coming back from the cold vault means "alive again," not "engaged again"; `activate` it afterward if you want it warm.

### Creation is scaffold-then-setup — and setup never auto-runs headless

Both create-into-`Active` commands are **two phases, not one**: a *mechanical scaffold* in plain bash (folder + template stubs / copy-or-clone + INDEX + commit + pre-trust), then an *interactive setup* — the single slash command `/setup-project`, which reads the project and runs its Phase 0 grill. The scaffold is dumb and deterministic; setup is intelligent and needs Claude. `newproject` (scaffold a new project) and `importproject` (adopt an existing one) are the two on-ramps; they both hand off to that *same* setup brain, which picks **greenfield** vs **adopt** mode from the `.system/project.md` `state:` marker. They are not two scaffolders — they are two entrances to one pipeline.

`newproject` has two **invocation** modes, gated solely on whether any flag is present:

- **Interactive** (zero args): the human is at the terminal. It prompts, scaffolds, and launches `/setup-project` inline — straight into the grill.
- **Headless** (`--title …` + optional `--folder` / `--brief` / `--source`): a non-interactive caller — typically *another Claude session* spinning up a project on your behalf — scaffolds without prompts and stages `--brief` to `references/brief.md`.

**The load-bearing rule: a headless caller scaffolds but must DEFER setup — it never launches the grill.** The Phase 0 grill *interviews you*; auto-firing it from non-interactive bash is the wrong shape, and would either block on input nobody's there to give or run a fake interview. So headless mirrors `importproject`'s deferred ending: it prints the `/setup-project` offer as a text line and a final `PROJECT_DIR=<absolute path>` line (so the calling session can read the path back and offer you setup), and stops. The scaffold lands in `state: fresh`, so setup runs correctly in greenfield mode whenever a *human-attended* session next opens the project. The handoff stays a human decision — by design, not omission.

### When to use which: three tests

**Test 1 — "Am I engaged with this right now — building it or using it?"**

- Yes → **Active**. (Type and completion don't matter: a tool you use daily is as Active as a build in progress.)
- No, but it's still alive — I'll come back → **Inactive**.
- No, and it's done/terminal → **Archive** (if worth keeping) or Delete.

**Test 2 — "Is it dormant, or is it done?"** (Inactive vs Archive — the line that matters most.)

- **Dormant** — paused, blocked, captured-but-not-started, might resume → **Inactive**. Stays in the daily view because you might pick it back up.
- **Done/terminal** — the work is finished or abandoned, the artifact (if any) has graduated elsewhere, you keep it only to *read* later → **Archive**. Leaves the daily view; gets a year prefix.

The signal between them: *will I open this folder again to keep working, or only to remember?* Keep-working → Inactive. Only-remember → Archive.

**Test 3 — "Should it leave the daily view?"**

- No (you want it in front of you) → Active or Inactive.
- Yes (out of sight, preserved) → **Archive**. Archiving is the deliberate act of clearing the view — that's what distinguishes it from Inactive, which is also "not engaged" but stays visible.

Deactivation is always a deliberate human choice — there's no auto-flag for "this looks abandoned." In the new model that signal would be false: Active legitimately holds finished, in-production tools with zero recent commits ("stable in prod" is indistinguishable from "abandoned" by any automatic measure). Moving a project to Inactive or Archive is something *you* decide.

### Examples

| Item | Folder | Why |
|---|---|---|
| 1Password migration | `Active/` → `Archive/` | Done when family is onboarded; record kept for reference |
| Screaming Frog audit skill | `Active/` | A tool you cd in to invoke — you're engaged with it |
| A specific client SEO audit | `Active/` → `Archive/` | Done when report is delivered; the work is preserved |
| The SEO audit playbook | `Active/` (→ `Inactive/` if set down) | Reusable tool you reach for; deactivate when you stop using it |
| Terminal cheatsheet | `Active/` | Always growing, always in use |
| Game design doc | `Active/` | Evolves with the game you're building |
| Game playtest #3 | `Active/` → `Archive/` | Specific event with a finish line |
| Tax filing agent (building *or* running it each year) | `Active/` | You're engaged with it — building or using |
| File 2026 taxes | `Active/` → `Archive/` | Done when filed |
| claude-md-setup buildout | `Active/` → `Archive/` | Built dotfiles + project-system, artifacts graduated out |
| "Build the home server" — captured but not started | `Inactive/` | Named project, alive, not yet engaged |
| Half-finished blog post, blocked on data | `Active/` → `Inactive/` → `Active/` | Deactivated while waiting; reactivated when data arrived |

## The tool vs job pattern

A tool is a reusable, evolving artifact (a script, skill, playbook, agent,
template). While you're building it or reaching for it, it lives in **Active**
like anything else you're engaged with — type doesn't earn its own folder (see
"Why type doesn't earn a folder" above). What still matters is the deposit rule:
**using a tool produces a *result*, not a new project.** The tool stays put; the
result goes to wherever that kind of work is kept — its *system of record*, which
is usually **outside** the workspace:

- **SEO audit process** (a tool) → each client's **report** → the client's
  Drive folder. No workspace project.
- **Tax filing agent** (a tool) → each year's **filing** → your tax records.
  No workspace project.

The deliverable lives in Drive / a CRM / the client's repo, so the tool's folder
is untouched and nothing new is created. (The test, from the folder's side:
would using the tool deposit a *separate work product* into a folder meant to
stay a clean, reusable tool? Usually no — the result leaves.)

**The one exception is a *generator* tool, whose output *is itself a project*:**

- A reusable **website build process** → each **client site** (a new Active
  project: its own repo, deployed, maintained — a living thing, not a document
  that ships out).
- The **project template** / `newproject` → each **new project**.

So: a use spins up a new project *only* when the thing it produces is itself a
living project. Everything else produces a result that leaves (Drive) or sits
inside the tool's own folder. When you set a tool down for a stretch, deactivate
it (`Active → Inactive`); when its job is wholly done, archive it.

When building a new tool, frame the project as building reusable infrastructure,
not a one-off. Example: "Build a reusable tax filing agent" rather than "File
this year's taxes."

## Slash-aliased commands list the primary name first

When multiple aliases point to the same thing, list the primary (canonical,
more descriptive) name first, with shorter aliases following:

```
projects / proj                primary first
workbench / bench
```

This shows up in two places:
- Shell-alias definitions in this repo's `shell/zshrc-fragment.sh` (sourced by `~/.zshrc` when project-system is installed; order is cosmetic but signals canonical form)
- `~/Notes/cheatsheet.md` slash-aliased lines (the `cheat` picker uses the first)

The primary is the self-documenting name you'd write in instructions. The shorter
alias is muscle-memory shorthand. When `cheat` puts a command on your prompt,
it uses the primary so the result is clear and unambiguous.

**Note:** Secondary aliases are *optional*, not mandatory. Add a secondary only
if you'll actually type it. If you find yourself always reaching for the primary,
the secondary is dead weight.

## Premature structure rule

**Add structure only when the lack of it starts to hurt.**

Signs you've hit that point:
- 10+ items at one folder level and `ls` is hard to scan
- You're consistently confused about whether something is X or Y
- You want to operate on a category as a whole

Until then, keep folders flat. The cost of reorganizing later is one afternoon.
The cost of premature structure is years of slight overhead.

### If Active grows big enough to need subfolders

Organize by **org or area**, not by type. Reaching for "something for an Acme job"
is more natural than reaching for "an agent."

```
Active/
├── acme/
├── home/
└── shared/
```

Don't do this yet.

## The personal lexicon

`LEXICON.md` is your **personal, cross-project canonical vocabulary** — terms you
reuse *across* projects, each with its official spelling and the wrong forms to
correct. It is the personal-scope sibling of a project's `GLOSSARY.md`: the same
`**Term**:` / definition / `_Avoid_:` format, but it lives once at the system level
instead of once per project.

**Scope line — what goes where.** Cross-project canon goes in `LEXICON.md`;
project-specific terms stay in that project's `GLOSSARY.md`. Brands are the common
case (an agency name, a client name, a product line), but recurring acronyms,
product/feature names, and coined terms used in more than one project belong here
too. A term that only ever means something in *one* project does not.

**Visibility line — what's safe to share.** A distinct axis from scope-as-placement
above: each entry is **private by default** (clients, company, personal ventures); a
term safe to appear in shared or published work — a product brand you ship — carries a
`_Visibility_: public` line. Two guards enforce this, both deriving the private-term
list from one shared helper (`bin/_leakscan.sh`) so they can't drift: `make-release`
itself **refuses to emit** a release whose staged copy still contains a private term
(it aborts, naming the term + file — it does not scrub, so a leak is fixed not hidden),
and the `test/adopter-install.sh` end-to-end check scans a built release the same way.
So private vocab can't slip into a shared copy embedded in a file that's meant to ship —
even if someone builds a release without running the test.
`/setup-project` and `/grill` set it when they promote a term (defaulting to
private). Format detail lives in `LEXICON.example.md`.

**The pull/promote loop.** The lexicon and project glossaries stay in sync through a
two-way flow that `/setup-project` (Phase 0) and `/grill` run:

- **Pull (seed).** When a project is set up or grilled, any lexicon term that
  actually appears in it — in the title, the dropped sources, or the conversation —
  is copied into that project's `GLOSSARY.md` (definition + `_Avoid_` verbatim).
  Multiple terms may seed; that's expected. This is the per-project data behind the
  global "brand fidelity" rule: a project for a given agency starts knowing how to
  spell that agency's name.
- **Promote (push back).** When a term pinned into a project glossary is one you'll
  reuse across projects, the same commands offer to add it to `LEXICON.md` so future
  projects seed it — default yes for a clear cross-project term, never silent, never
  for project-specific terms.

### The lexicon is personal config (the `.example` pattern)

`LEXICON.md` is **gitignored** — it's *your* vocabulary, not shared system data. The
repo tracks only **`LEXICON.example.md`** (the format + generic placeholder terms).
This mirrors the `.env` / `.env.example` convention:

- **First run seeds it.** `install.sh` (and `newproject` defensively) copies
  `LEXICON.example.md` → `LEXICON.md` *only if `LEXICON.md` is absent* — an existing
  lexicon is never overwritten.
- **Pull-safe.** Rule/format changes ship via `LEXICON.example.md`; a `git pull` never
  touches your `LEXICON.md`.
- **Adoption-clean.** A friend who clones the repo doesn't inherit your brands — they
  get the placeholders plus the system's own vocabulary (FSDN) and make the lexicon
  their own.
- **Trade-off:** your lexicon is local-only (like `.system/` and `CLAUDE.local.md`) —
  not backed up via this repo. Back up `LEXICON.md` yourself if you want
  belt-and-suspenders.

## File conventions

### Every project has these files

- `<project-name>.md` — the **project overview**: Claude's synthesis, the project's canonical source-of-truth document (what it is, why it exists, success criteria, unknowns). Named after the project folder (lowercase kebab, mirroring it), *not* a fixed name. Written by `/setup-project` when it adds over `CLAUDE.md` — skipped for thin operational projects (see [The project overview and references](#the-project-overview-and-references) and [Document naming](#document-naming) below).
- `PLAN.md` — the approach, phases, milestones
- `DECISIONS.md` — meaningful choices with reasoning (future-you will want this). Has a bar for what merits an entry — see `AUTHORING.md`.
- `CHECKLIST.md` — running task list
- `GLOSSARY.md` — the project glossary: canonical project language, glossary-only, no implementation detail. Generated when the project has coined terms worth pinning (≥1 project-specific term); created lazily otherwise. See `AUTHORING.md`.
- `CLAUDE.md` — per-project Claude Code config (stack, commands, conventions). Committed.
- `.system/project.md` — system metadata (started date) + project title + a short description (drafted and verified by `/setup-project`'s Phase 0, not asked at intake). See below.

**Optional, opt-in per project:**

- `CLAUDE.local.md` — personal-only Claude Code config (local tools, MCP server preferences, machine-specific overrides on this project). Gitignored globally via dotfiles' `~/.gitignore_global`, so it never enters the project repo even if accidentally committed. **Not shipped by `newproject`** — create it manually only when a real need surfaces (the file was empty-on-day-one for almost every project, so it doesn't earn a default slot).
- `README.md` — **not shipped by `newproject`.** Almost no project goes public; the overlap with `CLAUDE.md` and the project overview (`<project-name>.md`) is heavy when it does exist; and any project that *does* go public will want a bespoke README anyway, not a template-generated one. Create manually when a project is about to be shared externally.

Lightweight projects can be lighter still — a reference clone or a small utility sometimes just needs a `.system/project.md` for its intro and nothing else (no `PLAN.md` / `DECISIONS.md` / `CHECKLIST.md`).

### `.system/project.md` — system metadata + project intro

`.system/project.md` carries two things:
- **Frontmatter:** the `started` date.
- **Body:** the project's title (as an H1) and a short description. `newproject` writes a `_Description pending…_` placeholder; `/setup-project`'s Phase 0 grill replaces it with the verified description (it's not collected at intake).

The folder location encodes lifecycle state — `Active/` for engaged (building or using), `Inactive/` for dormant-but-alive (paused/placeholder), `Archive/` for done/terminal (historical record, date-stamped). A `status:` field was tried previously but became silently incorrect because nothing rewrote it on `mv`. Folder-as-source-of-truth removed the drift.

**The status *chip* is the load-bearing successor that field's removal left room for** — the 2026-05-18 retirement explicitly said *reintroduce a field when there's proper update tooling*. `/project-status` (and the dashboard's `s` key) is that tooling: it does not store a hand-typed status, it **re-judges** a one-line verdict from the project's own artifacts (`PLAN.md` / `CHECKLIST.md` / `DECISIONS.md` / git — reconciling stale-but-done checkboxes a raw count would misread) and writes it to **one local home**: a `.system/status` cache line `<chip> ⟂ <date> ⟂ <judged-HEAD-sha>`, gitignored with the rest of `.system/`. **The refresh is purely local — it never edits `CLAUDE.md`, never commits, never pushes**: a deliberate choice so status churn never pollutes a project's git history or GitHub (a refresh is a local file write, nothing more). Because the cache stamps the HEAD it judged, the dashboard renders the chip dimmed and marks it ◆ **stale** the instant a *new commit* moves HEAD past that sha — so a missed refresh is *visible*, never silently wrong (the failure mode that killed the old field). Uncommitted edits don't count as stale (the chip is judged on the working tree; flagging every in-progress edit was noise). The chip is a **per-machine local view** — it doesn't travel with the repo, so a fresh clone simply has no chip until refreshed. Refresh is event-driven (on-demand `/project-status`, or the `s` key); the cache is regenerable: delete it and the next refresh rebuilds it. (The project's `CLAUDE.md ## Status` is a *separate*, human-maintained narrative — see `AUTHORING.md`.)

Why this layout:

- **`.system/` is ignored per-project.** `newproject` writes a `.gitignore`
  into every new project that excludes `.system/`. No per-repo editing required
  (the script does it), no chance of forgetting. Personal-system metadata
  (the started date) never accidentally enters a project's own git repo.
- **The generated `.gitignore` also hardens against secret leaks.** It excludes
  the common credential-bearing files (`.env*` with an `.env.example` exception,
  private keys — `*.pem` / `*.key` / `id_rsa*` / `id_ed25519*`, `*.p12` / `*.pfx`,
  `credentials.json` / `secrets.json` / `*.keystore`). Deliberately a *committed*
  per-project `.gitignore`, not the machine-global excludes (`dotfiles`' job for
  universal noise like `.DS_Store`): a committed ignore **travels with the repo**,
  so it protects everyone who clones it — adopters and collaborators who don't have
  your global excludes. This is the file-level half of secret protection; the
  inline half (a key pasted into source) is the agent's pre-push secret glance
  (see the global `CLAUDE.md` § "Git").
- **Internal projects use the same pattern.** Even projects that aren't their
  own git repo use `.system/project.md`. This means promoting a project to a
  public repo later costs zero refactoring — the title + intro travel along.
- **The body holds title + summary** so `/setup-project` and other tooling have a canonical place to read project intent during orientation, without needing a separate README that ends up duplicating `CLAUDE.md` and the project overview (`<project-name>.md`).

The `_template/.system/` directory itself is tracked in `project-system`
(it's the canonical scaffold). Because the `.gitignore` is generated at
project creation time — not stored inside `_template/` — there's no rule
inside `project-system` that would shadow-ignore its own template content.

#### `.system/project.md` format

The YAML shape (and the optional `type: agent` marker for agent projects) lives in `AUTHORING.md`.

### The project overview and references

Two distinct concepts that used to live in the same folder and confused everyone — and the word "brief" used to name both, which made it worse. They're now cleanly separated:

**`<project-name>.md` — the project overview (Claude's synthesis)** — lives at the **project root** alongside other bookkeeping (`CLAUDE.md`, `PLAN.md`, etc.), named after the project folder (see [Document naming](#document-naming)). The canonical source-of-truth document: 1-2 paragraph statement of what this is, why it exists, what success looks like for v1, what's still unknown. Written by `/setup-project` when it adds over `CLAUDE.md`; **skipped for thin operational projects** where it would merely restate `CLAUDE.md` + the `.system/project.md` description. When present, downstream files (`PLAN.md`, `DECISIONS.md`, `CHECKLIST.md`) derive from it.

**`references/` — source material the user provides** — two sub-kinds, treated differently at cleanup:
- **Originating brief** — a descriptive document the user wrote/dropped to *spawn* the project (a brief, requirements doc, transcript). It is *consumed once* into the project overview + project files. **Safe to remove after it's fully absorbed** (it's recoverable from git history); `/setup-project` offers this at the end of synthesis, behind an explicit confirm — never a silent auto-delete.
- **Reference archive** — material meant to be *consulted forever* (e.g., a game project's `references/OriginalAssets/` of canonical source material). **Never auto-deleted or rewritten** — preserved as-is.

The common thread for both: the project *reads* `references/` for context but doesn't actively *edit* it. The originating-brief-vs-reference-archive distinction is what lets cleanup target the consumed brief without ever touching a consult-forever archive.

**Multi-source supported.** `newproject.sh` accepts multiple paths at the source-material prompt (drag multiple files from Finder, or paste a space-separated list — escaped-spaces in filenames work). Each path can be a file or a directory; directories are recursive. Staging happens *before* Claude is launched.

**Move-vs.-copy rule for staging:** items in a known *scratch location* are **moved** into the new project's `references/` (so the scratch dir stays clean). Items anywhere else are owned by their original location — **copied**, so the original stays put.

Scratch locations:
- `~/Projects/` workspace root, *exact-match* only — top-level files like `~/Projects/<name>-brief.md` (NOT files inside `Active/`, `Inactive/`, or `Archive/` subprojects — those belong to another project).
- `~/Downloads/` (anywhere under) — drop zone for downloaded source material.
- `~/Desktop/` (anywhere under) — drop zone for in-progress files.

Anywhere else (`~/Documents/`, another project's folder, a system path, etc.) → copy, no move.

Practical: drag an originating brief from your Desktop and it's consumed (Desktop stays clean). Drag a folder from another project and it's copied (that project stays intact). Drag a file from `~/Documents/` and it's copied (your organized stuff stays where you put it).

**Working content auto-promoted out of `references/`.** When the user drags in items that are actually the project's working content (code, configs, media, project directories like `scripts/` or `sounds/`), `/setup-project` recognizes them during Step 1.5 (sort references intake) and moves them to project root. The rule: working content goes to project root; source material stays in `references/`. The slash command uses judgment based on what items contain, not a rigid pattern.

### Per-file authoring specs

The reference-grade *how to author* specs for the generated project files — **`CLAUDE.md`** (the section menu), **`GLOSSARY.md`** (canonical project language + format), and **`DECISIONS.md`** (the bar for what merits an entry) — live in **`AUTHORING.md`**, the authoring spec the slash commands cite. They are kept out of this principles doc deliberately: long, command-facing, and changing on a different cadence than the principles here. This file defines *what* those files are (see "Every project has these files"); `AUTHORING.md` defines *how* to write them.

### Grilling a plan into the docs

`/grill` (a project-system slash command — see `claude/commands/grill.md`) runs a relentless one-question-at-a-time interview that walks a plan's decision tree, sharpens fuzzy language, and cross-references claims against the code. It is **self-contained** — it carries its own `GLOSSARY.md` and `DECISIONS.md` format guidance and does not depend on any external skill.

When run inside a project here, its outputs reconcile to this system: **resolved terms → `GLOSSARY.md`** (glossary), **decisions that clear the bar → `DECISIONS.md`**. Its "cross-reference with code" step doubles as any survey/enumeration a phase needs.

Every new project runs a **bounded grill at inception** — Phase 0 of `/setup-project` (see the pipeline table below). It's **always entered** but **self-terminating**: it inherits `/grill`'s "When to stop" test (ask only what would change an output), so a thin/operational project clears it in seconds with ~zero questions while a fuzzy one gets real interrogation. The conditional judgment is no longer *whether* to grill — it's whether to **escalate** Phase 0 to a full standalone `/grill` pass, which `/setup-project` offers only when the decision tree is genuinely deep (several interlocking locked-open decisions). `/grill` also remains invokable any time later in a project's life, not just at intake.

### Naming

- Project folders: `kebab-case`
- Archive folders: prefix with year for natural sorting (`2025-google-workspace-licensing/`)

### Document naming

Two positive rules govern what a root `.md` file is named — and the name itself tells you which kind of file you're looking at:

1. **A folder's overview doc is named after the folder** (lowercase kebab, mirroring it exactly). The project overview is `<project-name>.md` — e.g. `Active/website-builder/website-builder.md`. This is the same law already used one level down inside projects: `blocks/accordion/accordion.md`, `blocks/hero/hero.md`. A folder's own source-of-truth document carries the folder's name. Located programmatically as `$(basename <folder>).md`.
2. **Fixed cross-project system slots stay ALLCAPS** — `PLAN.md`, `DECISIONS.md`, `CHECKLIST.md`, `GLOSSARY.md`, `CLAUDE.md`. These have the *identical* name in every project; ALLCAPS marks them as system slots, not project content. (`CLAUDE.md` is ALLCAPS-mandated by Anthropic regardless; the rest follow the 2026-05-18 ALLCAPS-bookkeeping convention.)

The payoff is a **self-identifying filesystem**: the single lowercase `.md` at a project root is the project's own overview; everything ALLCAPS is a predictable system slot. The visual distinction carries meaning — `website-builder.md` is "the project," `CLAUDE.md` / `PLAN.md` are "the machinery." This is the filesystem-level expression of **Fractal Self-Describing Nodes** (see *Design principles*) — the "a folder's overview is named after the folder" law applied at every altitude.

**Archive keeps the invariant.** When the mover's **archive** action year-prefixes a folder (`website-builder/` → `2025-website-builder/`), it renames the overview alongside it (`website-builder.md` → `2025-website-builder.md`) so rule 1 holds everywhere — including `Archive/`, which is a read-later keepsake shelf where the doc still gets opened. **Unarchive** is the symmetric inverse: it strips the year prefix and renames the overview back. The Active⇄Inactive moves (`deactivate` / `activate`) don't rename the folder, so they don't touch the overview.

### Scripts that operate on the projects system live in `~/project-system/bin/`

Custom scripts that manage the project system itself go in `~/project-system/bin/` — `newproject` (scaffolds a *new* project into `Active/` from the template) and `importproject` (brings an *existing* folder or git repo into `Active/` — copies/clones it in, then offers the same `/setup-project` intake); both update `INDEX.md` + the `~/.claude.json` trust entry and auto-commit & push. Plus the dashboard-launched `moveproject` (the state-aware front door to *all* transitions — deactivate / activate / archive / unarchive / delete), shared helpers sourced by them (`_lifecycle.sh` / `_ui.sh`), and standalone tooling (`make-release.sh`, `repo-visibility.sh`, `audit-backups.sh`, `list-projects.sh`). **The canonical per-script inventory lives in the maintenance `CLAUDE.md` and in `bin/` itself — not duplicated here**, so this rule doesn't drift every time a script is added.

Reasoning:
- They're infrastructure, not assets
- They're tightly coupled to the system layout (paths, conventions)
- Aliases in `.zshrc` point at them
- Keeping them in `~/project-system/` alongside CONVENTIONS / INDEX / LEXICON / _template
  reflects their role as part of the system, not part of the workspace

`Active/` (and `Inactive/` when set down) is for tools and assets that *you*
reach for during work (playbooks, skills, cheatsheets, templates).
`~/project-system/bin/` is for tools that the *system* uses to maintain itself.

### Project setup workflow: bash + Claude split

`newproject` is two stages by design — a bash script and a Claude slash command — because each handles what it's best at:

| Stage | Lives at | Handles |
|---|---|---|
| `newproject.sh` (bash) | `~/project-system/bin/newproject.sh` | Deterministic parts: title prompt, optional source-material drop, folder-name confirmation (echoes title + derived slug, accept-on-Enter — the typo net), template copy (`cp -r`), `.system/project.md` metadata, `INDEX.md` awk-update + auto-commit + auto-push, `~/.claude.json` pre-trust, launching Claude |
| `/setup-project` (Claude slash command) | `~/project-system/claude/commands/setup-project.md` (symlinked into `~/.claude/commands/` by this repo's `install.sh`) | Flexible parts: orientation, sort references/ (working content vs. source material), **Phase 0 — define the project** (seed cross-project lexicon terms → draft description → reflect → always-entered, self-terminating bounded grill → write the verified description into `.system/project.md`), inference of project type/stack, project-overview synthesis (`<project-name>.md`, when it adds over CLAUDE.md — skipped for thin projects), glossary generation (`GLOSSARY.md`, when terms exist), optional scaffolding, populating `CLAUDE.md` / `PLAN.md` / `DECISIONS.md` / `CHECKLIST.md`, per-entry review of Conventions/Don'ts, content-level audit, originating-brief cleanup, `git init`, optional git-remote connection |

The handoff is the last line of `newproject.sh`: `(cd "$project_dir" && claude "/setup-project")`. Bash finishes its structured work; Claude takes over for the conversational rest. `importproject` shares the same two-stage split and the same Claude handoff — only the "fill the folder" step differs (copy/clone an existing source instead of the template), and there the intake is *offered*, not forced, so bulk adoption stays fast.

Why split: bash is reliable for structured prompts and file operations but bad at content generation and project-type-specific branching. Claude is reliable for natural-language Q&A and content generation but slower and pricier for deterministic ops. Each piece does only what it's good at.

When to change which: a new bash-shaped prompt or file op → `newproject.sh`. A new conversational step, project-type variant, or content-generation step → `/setup-project`.

### Greenfield vs. adopt: bringing an *existing* project into the system

`/setup-project` runs in one of two modes, **auto-detected** from the `.system/project.md` `state:` marker — no separate command:

- **Greenfield** (`state: fresh`, written by `newproject`) — the project is a brand-new `_template/` scaffold; setup *generates over* the stubs, then advances the marker to `state: active` at closeout, so the signal is self-consuming.
- **Adopt** (marker absent · `state: active` · real existing content) — the project *already exists* (imported via `importproject`, or set up before). Setup runs **non-destructively**: it reads the existing files as the brief and **creates only the baseline docs that are missing** — never modifying, overwriting, or deleting anything already there. Deepening an existing doc is a deliberate `/grill`, offered at the end, not setup's job.

**The graft contract** (why adopt is safe by construction): create-if-absent · never modify/overwrite · never delete · *visibility-aware* writes (check `git remote` before committing identifying content — local-only → real names, public → abstract; account-secrets never enter the repo regardless) · no empty stubs (only always-applies docs are unconditional; `GLOSSARY.md` / overview earn their place). A project that already has its **own `CLAUDE.md`** keeps it untouched; setup offers `/grill` to reconcile it. Because adoption touches a person's *existing* work, the flow is **loud** — it announces the rule, shows a found-vs-missing inventory, and reports created-vs-skipped (same "announce every path" ethos as `install.sh`). This is also why `importproject` never writes into the project folder: a bare adoption has no `.system/`, and *absent ⇒ adopt*, so setup auto-detects it with nothing to stamp.

### Where logic lives (the placement test)

The bash-vs-prose split above generalizes to a test for *any* new capability — apply it deliberately, don't default by habit:

- **`bin/` (portable shell tool)** — deterministic, reusable, no judgment. Ships with the system; works for every adopter. **Even a piece of "agent behavior" belongs here if it has a deterministic core** — extract the core into a tool, leave only the judgment in prose. Example: `bin/repo-visibility.sh` returns a repo's `private`/`public`/`unknown` (robust to multi-account `gh` / SSH-alias setups); the *push-or-confirm* judgment that consumes it stays in the agent's git rule.
- **`claude/commands/*.md` (agent prose)** — needs judgment, synthesis, or conversation; varies per project. *Exception:* keep logic as prose when extracting it would **duplicate a format/spec defined once** — e.g. the `GLOSSARY.md` entry format lives in one place, so the lexicon-seed stays prose rather than re-encoding the format in bash.
- **Personal / machine-specific** (a user's `dotfiles`, global `CLAUDE.md`) — never the portable system. The system may *provide a tool* that a personal rule calls; the invocation stays personal, the tool stays shared.

The trap: filing a deterministic, reusable capability under "agent behavior" — and thus into personal config — just because a *rule* triggers it. Ask **"is there a pure-function core here?"** If yes, it's a `bin/` tool, and only the decision that uses it is prose.

## Session workflow

For multi-session projects:

1. Start session: `cd` into the project and run `claude` — global rules + per-project `CLAUDE.md` load automatically
2. Do the work
3. End session: keep `CHECKLIST.md` and `DECISIONS.md` current so the next session has working memory
4. Close out until next session

The project memory lives in files (`CLAUDE.md` / `<project-name>.md` / `PLAN.md` / `DECISIONS.md` / `CHECKLIST.md` / `GLOSSARY.md`), not in chat history.

## Lifecycle of a project

1. **Spawn** — `cp -r ~/project-system/_template ~/Projects/Active/new-project-name`
   (or use `newproject` alias, which prompts for title + optional source material)
2. **Work** — across one or many sessions, updating files as you go
3. **Set down or finish** — from the `proj` dashboard, type `m` on the project:
   `deactivate` it to `Inactive/` when you step away, or `archive` it to
   `Archive/YYYY-foo` when it's done.
4. **Maybe revive** — `unarchive` brings a project back from the cold vault (it
   thaws to `Inactive/`; `activate` it to go warm). Projects can come back if a
   client wants updates or you want to revisit. Don't agonize about it.

## Design principles

These meta-principles have guided the design of this system and should guide
future changes.

### Fractal Self-Describing Nodes

*The foundational structural law of this system — the one the other principles here
serve; in prose, "the node law."* **Every node describes itself, in a consistent shape,
at every altitude.** *Shorthand: **fractal selves** (canonical) / **FSDN** (written
acronym) / "fractal nodes" (accepted synonym — normalize to "fractal selves" in
writing). One-liner: **every node is a fractal self.** Public-facing first use is
always the full term — the prose shorthands collide (see Lineage); FSDN is fine once
the full term has appeared.*

A *node* is any unit of organization — the whole portfolio, a project, a sub-tool, a
catalog entry. Three properties:

1. **Self-describing** — each node carries its own identity/overview in a consistent,
   templated shape (the portfolio's `INDEX.md`; a project's `<project-name>.md`
   overview; a tool's `<tool>.md`; a catalog entry). The same "describe yourself" move
   at every level.
2. **Scale-invariant (fractal)** — that move repeats at *every altitude*. Zoom in or
   out and you always land on a node that explains itself. (Already stated under
   *Document naming* as "the same law used one level down" — `blocks/accordion/
   accordion.md`.)
3. **Whole *and* part at once** — each node is self-contained (understandable on its
   own) *and* simultaneously a member of the node above and an index to the nodes
   below. It's **built to point up** (to its parent/index) and **down** (to its
   children) — every node is both a map and a thing-on-a-map. The payoff is navigation
   that doesn't dead-end; like completeness, that's the goal the discipline serves, not
   a structural guarantee (see *What's structurally enforced vs. discipline* below).
   ("node" is the right word precisely because a node is inherently part of a graph.)

**Mechanism is medium-specific.** The law is the *behavior* (self-describe + point
up/down), not the file type. Organizational/navigational nodes — the folders a human
opens to understand structure — use `folder/folder.md`. Only **containers** — units with
children to index — earn the sidecar/index file; a **leaf** (a lone file) self-describes
in-band (its own header or docstring) and only points up, so not every file needs an
overview, just containers. Pure code packages satisfy it
through their native idiom (package docstring / README); don't add a parallel `.md`
that shadows the code's own self-description. **Generated/produced output is never a
node** — it's output, not authored structure (e.g. `node_modules`, build dirs), so it's
excluded with no judgment needed. For authored directories the *test* is: *would a human
navigate here to understand the system?* If yes, it's an organizational node and earns
the `.md`. The principle itself is medium-general — so are its ancestors (holon, HATEOAS,
Zettelkasten) — and this system realizes it in the filesystem, with no claim to have
built it elsewhere.

**What's structurally enforced vs. discipline.** Be precise about the word "law": what's
actually *enforced* is narrow. **Co-location is structural** — because an overview lives
inside its node and is named after it, the two can't drift apart (rename/move/delete
carries the description along). But **completeness** (that every node *has* its overview,
and every parent indexes its children) and **accuracy** (that the overview stays true)
are **disciplines the law asks for, not
guarantees it makes** — nothing structural compels them, and the outcomes that depend on
them (e.g. no dead-ends, Property 3) are goals, not guarantees. So, precisely:
*structurally enforced against orphaning/drift; a discipline toward completeness and
accuracy.*

The principle was already implicit across the system; naming it makes it a deliberate
law to apply going forward. **Known instances:**
- **The self-identifying filesystem** (*Document naming* below): a folder's overview is
  named after the folder, at every level.
- **A folder-per-tool catalog** (`stack/<tool>/<tool>.md` + a `README.md` defining
  the entry shape + a master index).
- **A platform tool-doc convention** (`<node>/<tool>/<tool>.md`, status-marked).
- **An ecosystem map** — a self-describing node for an entire multi-project ecosystem.

**Apply it when adding structure:** any new container — a project, a sub-tool, a
module, a grouping — gets a self-named overview in the shape its level uses, pointing
up (to its index) and down (to its children). *Don't create a structural node that
can't describe itself.*

**Lineage (prior art).** This is a deliberate synthesis, not a coinage from nothing.
The whole-and-part-at-once property is Koestler's **holon / holarchy** (1967); in code
it's the **Composite pattern** (treat part and whole uniformly); the no-dead-end
up/down linking is **HATEOAS** (hypermedia) and, in knowledge work, **Zettelkasten /
Maps of Content**; scale-invariance is plain **self-similarity**. Prior "fractal
documentation" / "fractal knowledge" systems exist, and "fractal node" is already a
term of art in complex-network science (self-similar connectivity) — which is why the
*public* name is the full **Fractal Self-Describing Nodes**, never the colliding
shorthand. What's ours is the synthesis applied as an *authoring law*: the
self-naming index file (`folder/folder.md`) at every altitude — "don't create a node
that can't describe itself" (what that "law" does and doesn't enforce is set out in
*What's structurally enforced vs. discipline* above).

_(First capture 2026-06-06; naming + lineage pass 2026-06-07; enforcement-claim trued + Property 3 aligned 2026-06-09. Still refining.)_

### If the answer is always the same, it's a convention, not a question

When a script, template, or workflow asks for the same answer every time,
that answer belongs in a default — not in a prompt.

Examples that applied this rule:
- `newproject` doesn't ask "what's the first action?" because the answer is
  always "draft PLAN.md." That goes in the template as a default.
- The global CLAUDE.md plan cut "name, role, location" prompts because those
  don't change Claude's behavior per session.

When designing new tooling, watch for repeated answers and convert them to
conventions.

### Templates only get pressure-tested when new instances are spawned

Tools and templates can't be tested through "normal use" — they only show
their flaws when actually instantiated.

This means:
- The pace of refinement = the pace of new instances, not calendar time
- Plan to deliberately spawn 2-3 new instances when testing a new template
- Don't wait passively for problems to surface — go find them by spawning new instances

Applies to: `_template/` project starter, `CLAUDE.md` templates, agent
templates, any reusable scaffolding.

### Alphabetize lists shown to humans

When tooling shows the user a choice list (projects, options), alphabetize
it. Predictable order = faster scanning. Applied in: the mover's project picker
(`moveproject`). Apply to future selectors as they're built.

### Cheatsheets show named workflows, not raw commands

A cheatsheet is a muscle-memory accelerator, not a reference manual. When a named
workflow exists (a function, an alias, a script), the cheatsheet shows that.
Raw commands appear on the cheatsheet only as fallback, when no named workflow
exists yet (e.g., completing a project — until a `complete` script exists, the
raw `mv` line stays).

Corollary: don't add an alias just because something *could* be one. Add an
alias only when you'll actually use it. Aspirational aliases are noise.

## Things to NOT do

- Don't make folders that describe medium (`code/`, `docs/`). Describe purpose.
- Don't pre-organize Active by type. Wait for real pain.
- Don't skip writing decisions down. Future-you will not remember why.
- Don't let INDEX.md drift too far from reality. Update it when starting/finishing/moving.
- Don't put system files in `~/Projects/`. The workspace stays clean — three top-level folders (Active, Inactive, Archive) and nothing else.
- Don't add a `README.md` by default — it's opt-in only, for projects about to go public (per the "Optional, opt-in per project" section above). When you do create one, it's content-only (no system frontmatter — that lives in `.system/project.md`).

## When this system itself needs to change

Edit this file for the principle; add a dated entry to `CHANGES.md` recording what
changed and *why*. Don't try to keep the system pristine — let it evolve like
everything else you keep. (`CHANGES.md` is the load-bearing design history —
future maintainers read it to understand why a rule exists.)

