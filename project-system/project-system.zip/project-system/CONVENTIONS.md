# Project System Conventions

The principles and decisions behind how my project system is organized.
Read this before reorganizing, adding structure, or changing the system.

**See also:** `SKILLS.md` — where Claude Code skills & agents live, plus the generated catalog. There is no project list to see: the workspace is the list.

## The split: workspace vs system

The project system lives in two sibling directories under `~/`:

```
~/
├── Projects/              # WORKSPACE — where the actual work happens
│   ├── Active/            # engaged now — building or using (shown)
│   ├── Inactive/          # dormant but alive — paused, placeholder, will-resume (shown)
│   └── Archive/           # done/terminal record, date-stamped (hidden by default)
│
└── project-system/       # SYSTEM — the meta-layer that defines and operates on the workspace
    ├── README.md          # what this repo is, how to bootstrap on a new machine
    ├── CONVENTIONS.md     # this file
    ├── LEXICON.md         # personal cross-project vocabulary (gitignored)
    └── bin/               # scripts that operate on the system itself
```

**Why split:** `~/Projects/` is the *workspace* — pure content, every item is a project or a folder of projects. `~/project-system/` is the *system* — the conventions, index, scaffolding, and tooling that define how the workspace is organized. They are different concerns and deserve to live separately. The capital-P / lowercase distinction reinforces that visually: Apple-style "this is content" vs. Unix-style "this is infrastructure."

`~/project-system/` is itself a private git repo (`y3klab/project-system` on GitHub). The workspace is not a git repo — individual projects in `~/Projects/Active/` and `~/Projects/Inactive/` may be their own git repos with their own remotes, but the workspace as a whole is just a folder.

**Workspace backup is per-project, and the system can see the gaps.** Because the workspace isn't a repo, a project is only recoverable off-machine if *it* is a git repo with a pushed `origin` remote. The system doesn't enforce that — but `bin/audit-backups.sh` (alias `audit-backups`) reports it: a read-only sweep of Active + Inactive that flags projects with no remote (or no repo at all), so "is my portfolio recoverable?" is answerable. `Archive/` is out of scope (a local-only keepsake shelf is fine). A project that is *deliberately* local opts out with a `backup: local` line in its `.system/project.md` (see `AUTHORING.md`), which the audit acknowledges instead of flagging.

## Project identity: umbrellas

Each project belongs to an **umbrella** — an *access identity*: a GitHub account, its SSH host-alias, and the orgs it can reach. A multi-identity user runs more than one; the identity map (human names, accounts, aliases, orgs) lives in the global `CLAUDE.md`, loaded into every session. A project declares its umbrella in `.system/project.md` (`umbrella: <id>`) — the *self-describing node* principle: the project carries the fact, the tooling reads it rather than guessing. **The id is the suffix of the umbrella's `~/.gitconfig-<id>` identity file** (e.g. `umbrella: acme` → `~/.gitconfig-acme`), not a friendly label — that suffix is the value the no-remote include resolves against (below); the human name (e.g. "Acme Corp") stays in the identity map.

The umbrella's job is to make **commit-author identity correct and never guessed**. Three identity axes are deliberately decoupled — conflating them is what stamps one umbrella's commits with another's email:

- **Access** — which `gh` account can *see* a repo (org membership). Lives on GitHub.
- **Push routing** — which SSH key reaches a remote. Pinned per repo by the remote URL's host-alias (`git@github.com-<id>:…`).
- **Commit author** — the name/email *stamped on commits*. Resolved by `~/.gitconfig.local`, never guessed. Repos **with a remote** are matched by their SSH alias (`includeIf "hasconfig:remote.*.url:…"` → `~/.gitconfig-<umbrella>`). Repos **with no remote** carry a repo-local `[include] path = ~/.gitconfig-<umbrella>` — *indirection, not a copied-in email*, so an umbrella's identity changes in one file and every no-remote repo of that umbrella follows. `user.useConfigOnly = true` makes git **refuse to commit** where neither matches — the refusal *is* the guarantee.

The candidate umbrellas are exactly the ones named by the `hasconfig` rules in `~/.gitconfig.local` (a `gitdir:`-routed file — a single project's override — is *not* an umbrella). The author-resolution rule is uniform: **write the include at `git init`** (so the project's first commit has an identity under `useConfigOnly`) and **drop it when a remote is connected** (the SSH alias routes from then on). One writer owns it — `setup-project`: Step 8 writes it after `git init`, before the first commit; Step 9 drops it on remote-connect; Step 8 also backfills it for an existing no-remote repo that lacks one. `newproject` never inits a repo, so its optional `--umbrella <id>` flag only records the field in `.system/project.md` for `setup-project` to consume. A remote added **by hand** leaves the include behind to shadow the alias — `audit-backups.sh` flags any repo whose remote and lingering include disagree.

A new umbrella is a new pair of `includeIf` rules + a `~/.gitconfig-<id>` identity file; a project moves umbrellas by changing one field (and its alias, if it has a remote). Single-identity users never need any of this — one global git author covers everything and `umbrella:` is omitted.

## Brand families — distinct from the umbrella

A multi-brand maker may organize projects under a **master brand** and its **families**. That's a *product/identity* taxonomy, and it is **orthogonal to the umbrella** above — stated explicitly here because the two have already been mis-conflated:

- **`umbrella:`** is the **git access identity** — *who commits* (which account commits route through), defined by `~/.gitconfig-<id>`.
- **Brand family** is the **sub-brand a project belongs to** — *what the project is*.

They do not line up one-to-one: a project in one family can commit under an access identity named for something else, when one account owns several orgs. **Never repurpose `umbrella:` as a family tag** — it has happened (two RC-family projects were briefly set `umbrella: y3krc`, then reverted). There is no `y3krc` access identity; those repos commit under the **`y3k-lab`** identity, because the account behind `y3k-lab` owns the `y3krc` org. Family ≠ who-commits.

**The shape (the author's model, illustrating the general form — adopters substitute their own):** a **master** brand → **families** → each family is a **hub repo + its member projects**.

- **Master.** The master's own brand-identity work is a project (here `y3k-brand`: the A3K design language, the wordmark, FSDN). The master's public **storefront** is a hub + docs pair (here **Y3K Lab** / y3klab.com = `y3klab-hub` + `y3klab/docs`) — a storefront, **not** a content family.
- **Families** carry the master's name as a prefix (here **Y3K RC**). On disk today the RC family is the live one: hub `y3krc-hub` + members `y3krc-garage`, `y3krc-radiomaster`. Further families take the same shape as they materialize.
- **A project's family is encoded in its folder-name prefix (`y3krc-…`) plus its family hub — deliberately *not* a metadata field.** The prefix is already visible in every `ls`, path, and import, and the hub already groups the family; a `family:` field would only duplicate them. (Contrast `umbrella:`, which *is* a field precisely because the access identity is *not* derivable from the folder name.)

**Naming is in-flight:** the model describes the target, and renames land project-by-project — so not every folder wears its family prefix yet. Read a prefix as intent where present; its absence isn't a statement. **One deliberate, permanent exception:** `y3k-homelab` keeps the `y3k-` prefix and will **not** be renamed to `y3khome-homelab` — its name already self-identifies as Home, and the rename's off-machine blast radius (the skynet agent's symlink + the Mac-mini referrers) isn't justified.

## The three folders: Active, Inactive, Archive

The workspace asks one question constantly: **am I engaged with this or not?** That's the `Active` ⇄ `Inactive` split. `Archive` is the third folder because archiving is an *action*, not merely a state — it date-stamps the folder and takes the project out of the daily view. Each folder has one clear role:

- **`Active/`** — Engaged now: building *or* using. Anything you're currently working on or currently reaching for — a half-built tool, a finished-but-in-use tool, a job in progress. A project's type or completion % is a property you *see on opening it*, not a folder.
- **`Inactive/`** — Dormant but alive: paused builds, captured-but-not-started placeholders, things waiting on a stakeholder or on your attention. Not engaged right now, but you might resume — so it stays *in view*.
- **`Archive/`** — Done/terminal, preserved for reference. The artifact has graduated elsewhere (into a separate repo, into `dotfiles/`, into a tool you've installed) or there was never a runnable artifact to begin with. Date-stamped (`foo` → `2026-foo`) and **hidden from the daily view** — you keep it to read later, not to re-run.

All three are **things you keep**. The trash bin is the mover's Delete action — separate and deliberate, never one keystroke away.

A **temperature map** captures it: Active = warm, Inactive = cool, Archive = grey (hot / cold / dead). The dashboard colours the headers to match — warm advances, cool recedes — so Active naturally pops forward and Inactive recedes; the colour enforces the hierarchy for free.

### Why type doesn't earn a folder

The old system kept a separate `Library/` for living tools, on the theory that a tool and a job are different kinds of object. They aren't — they're the same object at different completion %. The deciding insight: **using a tool produces a *result*, not a project.** The result goes to an external system of record (a client's Drive folder, your tax records), *not* the workspace. So a finished, in-production tool you still reach for is simply **Active** (you're engaged with it); a tool you've set down is **Inactive**; a tool whose job is wholly done is **Archive**. No type axis required — see "The tool vs job pattern" below.

### The artifact test — machine-generated output is not a project

"Type doesn't earn a folder" sorts *projects* by engagement, not kind. This is the prior question: **is this folder a project at all?** Some folders in the workspace aren't — they're machine-generated *output of* a project, and they were landing in `Active/` by accident (a producer script defaulted to a sibling path, so a clone got dropped next to real projects, where it had no `CLAUDE.md` and tripped the drift detector as a malformed project).

**The test: a folder is a project only if it holds hand-authored work — something that has, or could have, a `CLAUDE.md` and its own decisions.** A folder *fully machine-generated from a project* is **not** a project; it lives **inside the project that produces it**, never as a sibling in `Active`/`Inactive`/`Archive` (those tiers hold **only projects**), and its checkout is **gitignored** — its git remote (or system of record) is the durable copy. The producer script defaults to `<repo-root>/<bucket>/<name>` (self-locating), so there's no loose path to drift.

**But machine-generated output is two different things, and they earn two different buckets — told apart by one question: *if I delete it and let the producer regenerate, do I lose anything?***

- **Regenerable build artifact** — a deploy target or published-output clone whose *only* value is its current state: re-run the producer and you get it back **identical**; its own history is disposable. → lives **hidden** in a gitignored, dot-prefixed **`.deploy/<name>/`** (dot-prefixed so search tools and Claude don't index it — a guides clone would otherwise duplicate every guide). *Delete → regenerate → lose nothing.* Examples: a published guides-site clone; a static-site deploy target.
- **Canonical generated record** — audit history, snapshots, or change logs whose value is the **accumulation**: each run appends, and the past states are gone from the live source, surviving *only* in this repo's git log. → lives **visible** in **`records/<name>/`** — the checkout is gitignored (its own repo; its remote is the backup) but the `records/` bucket itself is kept tracked/visible. *Delete → regenerate → lose history you care about.* Example: a DNS-snapshot ledger (every past DNS state, the pre-change backup, the drift baseline).

**Visibility encodes the meaning — it's the load-bearing signal, not decoration.** A *hidden* `.deploy/` says "disposable cache, safe to nuke and rebuild." A *visible* `records/` says "canonical, do not treat as throwaway." Filing an audit archive under `.deploy/` would tell a future cleanup (or a future you) it's safe to delete — exactly backwards for the one thing whose history can't be rebuilt. You hide a cache; you do **not** hide a record.

**Promotion trigger — a record stays under its producer only while *that producer alone* reads it.** The moment a *second* tool needs to read it, it has become **shared infrastructure** and earns its own **top-level home** (its own project/repo at the workspace root), not a nested `records/` under one of its consumers.

**The boundary stays "hand-authored," not "is it a website / is it small."** A thin, hand-written static site (a landing-page "hub" you edit by hand) **is** a real project — adopt it (give it a `CLAUDE.md`), don't hide it. Only *fully machine-generated* output is an artifact. And this whole test is **Fractal Self-Describing Nodes' "generated/produced output is never a node"** (see § Design principles) one altitude up: at the file-tree level generated output isn't a node, at the workspace level it isn't a project — the same exclusion from the authored view.

Two worked examples, both moved out of `Active/` when this rule landed: a published documentation-site clone at `<project>/.deploy/guides/`, written by that project's own publish script (regenerable build artifact - re-run the producer and it returns identical); and a DNS-snapshot ledger at `<project>/records/dns-history/`, appended to by a scheduled job (canonical record - kept visible because its git log *is* the asset).

### The hub/subsite rule — a published face is not a standalone project

The artifact test draws one line: machine-generated output isn't a project. This is the line one step over — a **published *face*** of a project isn't a standalone project either; it's a **section of a hub**.

**A family/brand's public web presence lives in a single hub repo** (e.g. `y3klab-hub` → y3klab.com, `y3krc-hub` → y3krc.com). The hub is the front door (a hand-authored landing) plus its sections.

**Public subsites are sections of that hub, never standalone top-level projects.** A section takes one of two forms:

- **A tracked subdir of the hub** — either hand-authored in place, or **synced in from a source** (e.g. `y3klab-hub/blue-steel/` ← `dotfiles`; `y3klab-hub/a3k/` ← the `y3k-brand` work). A synced section is edited at its *source* and re-synced — never hand-edited at the hub.
- **A separate repo nested in the hub folder** — gitignored by the hub (its own remote is its backup), kept **visible** (not dot-hidden — it's hand-authored content, like a `records/` checkout, not a disposable cache), deploying to its **own subdomain**, and pre-positioned to fold into the hub later if you choose. Example: `y3krc-hub/radiomaster/` (`y3krc/radiomaster` → radiomaster.y3krc.com).

**The private-source → public-hub-section split.** The *work* lives in a private project; its *public face* is a hub section — two things, cross-linked, not one. Examples: `y3k-brand` (private design work) → the **a3k** section of `y3klab-hub`; `y3krc-radiomaster` (private source-of-truth) → the **radiomaster** section of `y3krc-hub`. So when a public site looks like it might be its own project, ask *whose face is this?* — if it's the published face of private work, it's a hub section, and the private project is where it's adopted.

**Same shape as the artifact test, one altitude over.** Generated output isn't a standalone *node* (it's output); a published face isn't a standalone *project* (it's a section). Both resolve "this looked like its own thing" into "it belongs inside the thing it serves."

**What a published face may contain - everything committed is served.** A face repo that publishes its **repo root** (the common case: `y3klab-hub`, `y3krc-hub`, `y3krc-hub/radiomaster/`, `y3klab-hub/monarchwaystations/`) serves *every tracked file* at its domain. **A private repo does not make its files private** - GitHub visibility governs who can read the repo *there*, not what the host serves. Two consequences, both already practiced and now written down:

- **Keep project docs out of the published repo.** Both hubs keep `CLAUDE.md`, `.system/` and `.claude/` **untracked** - `y3krc/hub` tracks only `index.html`, `favicon.svg`, `.gitignore`, `.assetsignore`. That curation is the reason nothing internal has ever leaked; it is a discipline, not an accident, so treat it as the rule. The project's docs live in the *private* half of the pair.
- **Root-publishing needs an `.assetsignore`.** Cloudflare publishes the build container's own checkout, so `.git/config`, `.git/HEAD` and `.git/logs/HEAD` are served unless excluded - and no amount of curation catches it, because `.git` is not a file you committed. Add `.assetsignore` with `.git` and `.gitignore` when the project is created. (Found 2026-07-24 on radiomaster.y3krc.com and y3krc.com, both introduced by Cloudflare's Pages → Workers migration; neither leaked while they were Pages projects.)

**Root-publish is a deny-list; a build dir is an allow-list.** `y3krc-garage` publishes `site/` and is immune by construction - only deliberately-generated output can reach the web. Root-publishing is safe only while everyone remembers what not to commit. **Don't restructure a hand-authored single-page face just to gain this** - with nothing to generate, a build dir is pure indirection. Reach for the `site/` layout when the face has a *generator* (garage renders many pages from a node tree), or when a face starts accumulating generated artifacts and the deny-list starts feeling load-bearing.

**Automating the pair: the publish credential.** When the private half generates
something the public face serves (regenerated data, a rebuilt asset), the job
runs in the *private* repo and pushes to the *face* repo. GitHub's automatic
`GITHUB_TOKEN` only reaches the repo the workflow runs in, so a cross-repo
credential is unavoidable. **Use a repo deploy key, not a personal access
token.** A PAT's scope is a policy that can be edited later and it acts as the
owner's whole account; a deploy key's single-repo scope is a property of what
the credential *is*, it impersonates nobody, and it never expires - which
matters for an unattended job that would otherwise fail silently when a
one-year PAT lapses. Generate it, install the public half as a write-enabled
deploy key, pipe the private half straight into an Actions secret, and delete
the local copy without ever displaying it.

**Deploy keys may be disabled org-wide**, and it surfaces only as a 422
"Deploy keys are disabled for this repository" when you try to create one. The
toggle lives at Organization Settings -> **Security and quality** -> **Deploy
keys** (not under Member privileges, where you would look first).

**A refresh job must fail closed.** Validate before publishing - row counts,
monotonic totals, expected columns, output shape - and abort *before* the
commit if anything trips, so the live site keeps serving the last good data. A
refresh that fails open is worse than no refresh: it replaces knowably-stale
data with confidently-wrong data. Derive any "as of" stamp from the data
itself rather than from wall-clock time, so identical input yields identical
output and an unchanged source produces no commit and no deploy.

### How projects move

```
   Active   ⇄  Inactive          (deactivate / activate)
   Active   →  Archive           (archive — date-stamped, leaves the view)
   Inactive →  Archive           (archive)
   Archive  →  Inactive          (unarchive — drops the date prefix; thaws to
                                  Inactive, then activate if you want it warm)
   (any)    →  Delete            (deliberate, double-confirmed)
```

**How you move things along it.** Transitions happen from the dashboard, not by memorising command names — there are no standalone *transition* scripts (creation has two standalone commands — `newproject` to scaffold, `importproject` to adopt — but moving along the lifecycle does not). At the `proj` / `list projects` picker, arrow to a project (or type its number to jump the cursor) and press `m` to open the mover for it — `m<#>` in the non-interactive fallback prompt. It offers only the transitions valid from where that project currently sits — Active → deactivate/archive/delete, Inactive → activate/archive/delete, Archive → unarchive/delete — and drives the shared registry engine. Moves are single-action (picking the destination is the confirm, since you already chose the project); only delete double-confirms. **Unarchiving thaws to `Inactive`, not `Active`** — coming back from the cold vault means "alive again," not "engaged again"; `activate` it afterward if you want it warm.

### Creation is register-then-offer — depth is a choice, not a toll

Landing a project in the workspace is **registration**, and the folder *is* the
record: a project exists because it is sitting in a tier, which is why the dashboard
can never be missing one. Registration adds the two things that do not follow from
the folder alone - a `~/.claude.json` trust entry, so opening it never stops to ask,
and, for a brand-new folder, the small floor of files it would otherwise be empty
without. Registration is a **complete outcome**.
A project can stop there forever and be a perfectly good citizen of the system:
it shows on the dashboard, it moves through the mover, the backup audit sees it.

Anything deeper is **offered, never imposed**:

```
register    bash, no Claude       the records, and a floor for a new folder
setup       /setup-project        drafts the docs the content warrants
grill       /grill                interrogates you; sharpens what exists
```

Each has exactly one write posture: register writes the floor, **setup creates
only what is absent and never touches what exists**, and grill edits existing
docs with your consent. Because setup is non-destructive, deferring it costs
nothing — running it a month later will not overwrite a word you wrote in between.

**Why it is not one ceremony any more.** Creation used to run the whole pipeline
unconditionally: every project, from a two-hour errand to a real build, was
marched through a Phase 0 grill, a phase-decomposition gate and a per-entry
conventions review before you could touch it. The cost showed up as abandoned
intake — projects scaffolded, never finished, left carrying hollow stubs and a
`_Description pending_ ` placeholder. Depth now scales to the project.

**Every project still says what it is.** Registration requires a description,
satisfiable three ways — a typed one-liner, a brief, or dropped source material —
and refuses only the empty-handed case. That one line fills both `CLAUDE.md`'s
Project section and the `.system/project.md` body, so a project that never runs
setup still describes itself. This is the one content question asked at intake,
and it is asked precisely because registration is terminal.

`newproject` has two **invocation** modes, gated solely on whether any flag is present:

- **Interactive** (zero args): the human is at the terminal. It prompts, registers, then *offers* setup — defaulting to no.
- **Headless** (`--title …` plus optional `--description` / `--folder` / `--brief` / `--source`): a non-interactive caller, typically *another Claude session* spinning up a project on your behalf. It registers without prompts and stages `--brief` to `references/brief.md`.

`importproject` has the same two modes, for the same reason. Its headless form (`--source <path|url>`) matters most for the case register-in-place exists to serve: a session that creates a folder in the workspace needs it to become visible to the dashboard, and without a non-interactive path it would have to ask a human to run a wizard. Both headless paths **copy, never move** — relocating files out from under whoever handed them over is not a call a non-interactive caller should make.

**The load-bearing rule: a headless caller registers but must DEFER setup — it never launches the grill.** The grill *interviews you*; auto-firing it from non-interactive bash would either block on input nobody is there to give or run a fake interview. So headless prints the `/setup-project` offer as a text line and a final `PROJECT_DIR=<absolute path>` line, so the calling session can read the path back and offer *you* setup. The handoff stays a human decision — by design, not omission.

### When to use which: three tests

**Test 1 — "Am I engaged with this right now — building it or using it?"**

- Yes → **Active**. (Type and completion don't matter: a tool you use daily is as Active as a build in progress.)
- No, but it's still alive — I'll come back → **Inactive**.
- No, and it's done/terminal → **Archive** (if worth keeping) or Delete.

**Test 2 — "Is it dormant, or is it done?"** (Inactive vs Archive — the line that matters most.)

- **Dormant** — paused, blocked, captured-but-not-started, might resume → **Inactive**. Stays in the daily view because you might pick it back up.
- **Done/terminal** — the work is finished or abandoned, the artifact (if any) has graduated elsewhere, you keep it only to *read* later → **Archive**. Leaves the daily view; gets a year prefix.

The signal between them: *will I open this folder again to keep working, or only to remember?* Keep-working → Inactive. Only-remember → Archive.

**Test 3 — "Should it leave the daily view?"**

- No (you want it in front of you) → Active or Inactive.
- Yes (out of sight, preserved) → **Archive**. Archiving is the deliberate act of clearing the view — that's what distinguishes it from Inactive, which is also "not engaged" but stays visible.

Deactivation is always a deliberate human choice — there's no auto-flag for "this looks abandoned." In the new model that signal would be false: Active legitimately holds finished, in-production tools with zero recent commits ("stable in prod" is indistinguishable from "abandoned" by any automatic measure). Moving a project to Inactive or Archive is something *you* decide.

### Examples

| Item | Folder | Why |
|---|---|---|
| 1Password migration | `Active/` → `Archive/` | Done when family is onboarded; record kept for reference |
| Screaming Frog audit skill | `Active/` | A tool you cd in to invoke — you're engaged with it |
| A specific client SEO audit | `Active/` → `Archive/` | Done when report is delivered; the work is preserved |
| The SEO audit playbook | `Active/` (→ `Inactive/` if set down) | Reusable tool you reach for; deactivate when you stop using it |
| Terminal cheatsheet | `Active/` | Always growing, always in use |
| Game design doc | `Active/` | Evolves with the game you're building |
| Game playtest #3 | `Active/` → `Archive/` | Specific event with a finish line |
| Tax filing agent (building *or* running it each year) | `Active/` | You're engaged with it — building or using |
| File 2026 taxes | `Active/` → `Archive/` | Done when filed |
| claude-md-setup buildout | `Active/` → `Archive/` | Built dotfiles + project-system, artifacts graduated out |
| "Build the home server" — captured but not started | `Inactive/` | Named project, alive, not yet engaged |
| Half-finished blog post, blocked on data | `Active/` → `Inactive/` → `Active/` | Deactivated while waiting; reactivated when data arrived |

## The tool vs job pattern

A tool is a reusable, evolving artifact (a script, skill, playbook, agent,
template). While you're building it or reaching for it, it lives in **Active**
like anything else you're engaged with — type doesn't earn its own folder (see
"Why type doesn't earn a folder" above). What still matters is the deposit rule:
**using a tool produces a *result*, not a new project.** The tool stays put; the
result goes to wherever that kind of work is kept — its *system of record*, which
is usually **outside** the workspace:

- **SEO audit process** (a tool) → each client's **report** → the client's
  Drive folder. No workspace project.
- **Tax filing agent** (a tool) → each year's **filing** → your tax records.
  No workspace project.

The deliverable lives in Drive / a CRM / the client's repo, so the tool's folder
is untouched and nothing new is created. (The test, from the folder's side:
would using the tool deposit a *separate work product* into a folder meant to
stay a clean, reusable tool? Usually no — the result leaves.)

**The one exception is a *generator* tool, whose output *is itself a project*:**

- A reusable **website build process** → each **client site** (a new Active
  project: its own repo, deployed, maintained — a living thing, not a document
  that ships out).
- The **project template** / `newproject` → each **new project**.

So: a use spins up a new project *only* when the thing it produces is itself a
living project. Everything else produces a result that leaves (Drive) or sits
inside the tool's own folder. When you set a tool down for a stretch, deactivate
it (`Active → Inactive`); when its job is wholly done, archive it.

When building a new tool, frame the project as building reusable infrastructure,
not a one-off. Example: "Build a reusable tax filing agent" rather than "File
this year's taxes."

## Slash-aliased commands list the primary name first

When multiple aliases point to the same thing, list the primary (canonical,
more descriptive) name first, with shorter aliases following:

```
projects / proj                primary first
workbench / bench
```

This shows up in two places:
- Shell-alias definitions in this repo's `shell/zshrc-fragment.sh` (sourced by `~/.zshrc` when project-system is installed; order is cosmetic but signals canonical form)
- `~/Notes/cheatsheet.md` slash-aliased lines (the `cheat` picker uses the first)

The primary is the self-documenting name you'd write in instructions. The shorter
alias is muscle-memory shorthand. When `cheat` puts a command on your prompt,
it uses the primary so the result is clear and unambiguous.

**Note:** Secondary aliases are *optional*, not mandatory. Add a secondary only
if you'll actually type it. If you find yourself always reaching for the primary,
the secondary is dead weight.

## Premature structure rule

**Add structure only when the lack of it starts to hurt.**

Signs you've hit that point:
- 10+ items at one folder level and `ls` is hard to scan
- You're consistently confused about whether something is X or Y
- You want to operate on a category as a whole

Until then, keep folders flat. The cost of reorganizing later is one afternoon.
The cost of premature structure is years of slight overhead.

### If Active grows big enough to need subfolders

Organize by **org or area**, not by type. Reaching for "something for an Acme job"
is more natural than reaching for "an agent."

```
Active/
├── acme/
├── home/
└── shared/
```

Don't do this yet.

## The personal lexicon

`LEXICON.md` is your **personal, cross-project canonical vocabulary** — terms you
reuse *across* projects, each with its official spelling and the wrong forms to
correct. It is the personal-scope sibling of a project's `GLOSSARY.md`: the same
`**Term**:` / definition / `_Avoid_:` format, but it lives once at the system level
instead of once per project.

**Scope line — what goes where.** Cross-project canon goes in `LEXICON.md`;
project-specific terms stay in that project's `GLOSSARY.md`. Brands are the common
case (an agency name, a client name, a product line), but recurring acronyms,
product/feature names, and coined terms used in more than one project belong here
too. A term that only ever means something in *one* project does not.

**Visibility line — what's safe to share.** A distinct axis from scope-as-placement
above: each entry is **private by default** (clients, company, personal ventures); a
term safe to appear in shared or published work — a product brand you ship — carries a
`_Visibility_: public` line. Two guards enforce this, both deriving the private-term
list from one shared helper (`bin/_leakscan.sh`) so they can't drift: `make-release`
itself **refuses to emit** a release whose staged copy still contains a private term
(it aborts, naming the term + file — it does not scrub, so a leak is fixed not hidden),
and the `test/adopter-test.sh` end-to-end check scans a built release the same way.
So private vocab can't slip into a shared copy embedded in a file that's meant to ship —
even if someone builds a release without running the test.
`/setup-project` and `/grill` set it when they promote a term (defaulting to
private). Format detail lives in `LEXICON.example.md`.

**The pull/promote loop.** The lexicon and project glossaries stay in sync through a
two-way flow that `/setup-project` and `/grill` run:

- **Pull (seed).** When a project is set up or grilled, any lexicon term that
  actually appears in it — in the title, the dropped sources, or the conversation —
  is copied into that project's `GLOSSARY.md` (definition + `_Avoid_` verbatim).
  Multiple terms may seed; that's expected. This is the per-project data behind the
  global "brand fidelity" rule: a project for a given agency starts knowing how to
  spell that agency's name.
- **Promote (push back).** When a term pinned into a project glossary is one you'll
  reuse across projects, the same commands offer to add it to `LEXICON.md` so future
  projects seed it — default yes for a clear cross-project term, never silent, never
  for project-specific terms.

### The lexicon is personal config (the `.example` pattern)

`LEXICON.md` is **gitignored** — it's *your* vocabulary, not shared system data. The
repo tracks only **`LEXICON.example.md`** (the format + generic placeholder terms).
This mirrors the `.env` / `.env.example` convention:

- **First run seeds it.** `install.sh` (and `newproject` defensively) copies
  `LEXICON.example.md` → `LEXICON.md` *only if `LEXICON.md` is absent* — an existing
  lexicon is never overwritten.
- **Pull-safe.** Rule/format changes ship via `LEXICON.example.md`; a `git pull` never
  touches your `LEXICON.md`.
- **Adoption-clean.** A friend who clones the repo doesn't inherit your brands — they
  get the placeholders plus the system's own vocabulary (FSDN) and make the lexicon
  their own.
- **Trade-off:** your lexicon is local-only (like `.system/` and `CLAUDE.local.md`) —
  not backed up via this repo. Back up `LEXICON.md` yourself if you want
  belt-and-suspenders.

## File conventions

### What a project contains

Three files arrive at **registration** and are always present. Everything else
**earns its place** - it appears when there is something real to put in it, and
its absence is a correct state, not a gap. A project that stops at the floor is
complete, not half-built.

```
Active/website-builder/
├── CLAUDE.md            always    per-project Claude config. Registration writes a
│                                  minimal one (the Project section, from your
│                                  one-line intake description); /setup-project
│                                  fills in the rest of the section menu if it runs
├── .gitignore           always    excludes .system/ + the common credential-bearing
│                                  files. Committed, so it protects anyone who clones
├── .system/             always    local-only, gitignored, never in the project's repo
│   ├── project.md       always    started date, title, the one-line description,
│   │                              optional umbrella
│   └── status           cached    the dashboard's status chip. Regenerable - delete
│                                  it and the next refresh rebuilds it
├── website-builder.md   earned    the project overview: Claude's synthesis, named
│                                  after the folder. Skipped when it would only
│                                  restate CLAUDE.md + the description
├── PLAN.md              earned    phases and concrete next actions
├── CHECKLIST.md         earned    running task list, by phase
├── DECISIONS.md         earned    the single decision record; carries its own bar
│                                  as a preamble (see AUTHORING.md)
├── GLOSSARY.md          earned    canonical project language. Only when there is at
│                                  least one term worth pinning
└── references/          if given  source material the project READS and never edits
```

**Opt-in, never scaffolded:**

- `CLAUDE.local.md` — personal-only Claude Code config (local tools, MCP preferences, machine-specific overrides). Gitignored globally via dotfiles' `~/.gitignore_global`, so it never enters the project repo even if accidentally committed. Create it only when a real need surfaces; it was empty-on-day-one for almost every project.
- `README.md` — almost no project goes public, the overlap with `CLAUDE.md` and the overview is heavy when it does, and a project that *does* go public wants a bespoke README rather than a generated one. Create it manually when a project is about to be shared externally.

**Why the always/earned split is structural, not stylistic.** The system used to
copy a `_template/` folder containing hollow `PLAN.md` / `CHECKLIST.md` /
`DECISIONS.md` stubs into every project. That silently asserted all three were
mandatory - contradicting this very section - and it manufactured exactly the
empty stubs the rest of the system forbids. A folder of files cannot express
"conditional"; the table above can, which is why the shape is documented here
rather than shipped as a directory to copy.

### `.system/project.md` — system metadata + project intro

`.system/project.md` carries two things:
- **Frontmatter:** the `started` date.
- **Body:** the project's title (as an H1) and the one-line description given at registration. There is no placeholder: registration requires a description (typed, from a brief, or from dropped material) precisely because it may be the only one the project ever gets. `/setup-project` and `/grill` sharpen it later if they run.

The folder location encodes lifecycle state — `Active/` for engaged (building or using), `Inactive/` for dormant-but-alive (paused/placeholder), `Archive/` for done/terminal (historical record, date-stamped). A `status:` field was tried previously but became silently incorrect because nothing rewrote it on `mv`. Folder-as-source-of-truth removed the drift.

**The status *chip* is the load-bearing successor that field's removal left room for** — the 2026-05-18 retirement explicitly said *reintroduce a field when there's proper update tooling*. `/project-status` (and the dashboard's `s` key) is that tooling: it does not store a hand-typed status, it **re-judges** a one-line verdict from the project's own artifacts (`PLAN.md` / `CHECKLIST.md` / `DECISIONS.md` / git — reconciling stale-but-done checkboxes a raw count would misread) and writes it to **one local home**: a `.system/status` cache line `<chip> ⟂ <date> ⟂ <judged-HEAD-sha>`, gitignored with the rest of `.system/`. **The refresh is purely local — it never edits `CLAUDE.md`, never commits, never pushes**: a deliberate choice so status churn never pollutes a project's git history or GitHub (a refresh is a local file write, nothing more). Because the cache stamps the HEAD it judged, the dashboard renders the chip dimmed and marks it ◆ **stale** the instant a *new commit* moves HEAD past that sha — so a missed refresh is *visible*, never silently wrong (the failure mode that killed the old field). Uncommitted edits don't count as stale (the chip is judged on the working tree; flagging every in-progress edit was noise). The chip is a **per-machine local view** — it doesn't travel with the repo, so a fresh clone simply has no chip until refreshed. Refresh is event-driven (on-demand `/project-status`, or the `s` key); the cache is regenerable: delete it and the next refresh rebuilds it. (The project's `CLAUDE.md ## Status` is a *separate*, human-maintained narrative — see `AUTHORING.md`.)

Why this layout:

- **`.system/` is ignored per-project.** `newproject` writes a `.gitignore`
  into every new project that excludes `.system/`. No per-repo editing required
  (the script does it), no chance of forgetting. Personal-system metadata
  (the started date) never accidentally enters a project's own git repo.
- **The generated `.gitignore` also hardens against secret leaks.** It excludes
  the common credential-bearing files (`.env*` with an `.env.example` exception,
  private keys — `*.pem` / `*.key` / `id_rsa*` / `id_ed25519*`, `*.p12` / `*.pfx`,
  `credentials.json` / `secrets.json` / `*.keystore`). Deliberately a *committed*
  per-project `.gitignore`, not the machine-global excludes (`dotfiles`' job for
  universal noise like `.DS_Store`): a committed ignore **travels with the repo**,
  so it protects everyone who clones it — adopters and collaborators who don't have
  your global excludes. This is the file-level half of secret protection; the
  inline half (a key pasted into source) is the agent's pre-push secret glance
  (see the global `CLAUDE.md` § "Git").
- **Internal projects use the same pattern.** Even projects that aren't their
  own git repo use `.system/project.md`. This means promoting a project to a
  public repo later costs zero refactoring — the title + intro travel along.
- **The body holds title + summary** so `/setup-project` and other tooling have a canonical place to read project intent during orientation, without needing a separate README that ends up duplicating `CLAUDE.md` and the project overview (`<project-name>.md`).

Both files are written at registration by `registry_write_project_files`
(`bin/_registry.sh`) rather than copied from a stored template, so there is no
template directory whose own `.system/` would need a tracking exception, and no
chance of the shipped shape drifting from the shape the code writes.

#### `.system/project.md` format

The YAML shape (and the optional `type: agent` marker for agent projects) lives in `AUTHORING.md`.

### The project overview and references

Two distinct concepts that used to live in the same folder and confused everyone — and the word "brief" used to name both, which made it worse. They're now cleanly separated:

**`<project-name>.md` — the project overview (Claude's synthesis)** — lives at the **project root** alongside other bookkeeping (`CLAUDE.md`, `PLAN.md`, etc.), named after the project folder (see [Document naming](#document-naming)). The canonical source-of-truth document: 1-2 paragraph statement of what this is, why it exists, what success looks like for v1, what's still unknown. Written by `/setup-project` when it adds over `CLAUDE.md`; **skipped for thin operational projects** where it would merely restate `CLAUDE.md` + the `.system/project.md` description. When present, downstream files (`PLAN.md`, `DECISIONS.md`, `CHECKLIST.md`) derive from it.

**`references/` — source material the user provides** — two sub-kinds, treated differently at cleanup:
- **Originating brief** — a descriptive document the user wrote/dropped to *spawn* the project (a brief, requirements doc, transcript). It is *consumed once* into the project overview + project files. **Safe to remove after it's fully absorbed** (it's recoverable from git history); `/setup-project` offers this at the end of synthesis, behind an explicit confirm — never a silent auto-delete.
- **Reference archive** — material meant to be *consulted forever* (e.g., a game project's `references/OriginalAssets/` of canonical source material). **Never auto-deleted or rewritten** — preserved as-is.

The common thread for both: the project *reads* `references/` for context but doesn't actively *edit* it. The originating-brief-vs-reference-archive distinction is what lets cleanup target the consumed brief without ever touching a consult-forever archive.

**Multi-source supported, in as many rounds as it takes.** `newproject.sh` accepts multiple paths at the source-material prompt (drag multiple files from Finder, or paste a space-separated list — escaped-spaces in filenames work), and the prompt **repeats** after each accepted drop rather than closing on the first one. Material is rarely gathered in a single Finder selection: a transcript in `~/Downloads`, a spec in `~/Documents` and a folder from another project are three separate reaches, so the prompt stays open until Enter on an empty line ends it. Accepted items accumulate, re-dropping something already banked is a no-op, and a half-good round keeps whatever resolved so only the misses need retyping. Each path can be a file or a directory; directories are recursive. Staging happens *before* Claude is launched.

**Move-vs.-copy rule for staging:** items in a known *scratch location* are **moved** into the new project's `references/` (so the scratch dir stays clean). Items anywhere else are owned by their original location — **copied**, so the original stays put.

Scratch locations:
- `~/Projects/` workspace root, *exact-match* only — top-level files like `~/Projects/<name>-brief.md` (NOT files inside `Active/`, `Inactive/`, or `Archive/` subprojects — those belong to another project).
- `~/Downloads/` (anywhere under) — drop zone for downloaded source material.
- `~/Desktop/` (anywhere under) — drop zone for in-progress files.

Anywhere else (`~/Documents/`, another project's folder, a system path, etc.) → copy, no move.

Practical: drag an originating brief from your Desktop and it's consumed (Desktop stays clean). Drag a folder from another project and it's copied (that project stays intact). Drag a file from `~/Documents/` and it's copied (your organized stuff stays where you put it).

**Working content auto-promoted out of `references/`.** When the user drags in items that are actually the project's working content (code, configs, media, project directories like `scripts/` or `sounds/`), `/setup-project` recognizes them during Step 1.5 (sort references intake) and moves them to project root. The rule: working content goes to project root; source material stays in `references/`. The slash command uses judgment based on what items contain, not a rigid pattern.

### Per-file authoring specs

The reference-grade *how to author* specs for the generated project files — **`CLAUDE.md`** (the section menu), **`GLOSSARY.md`** (canonical project language + format), and **`DECISIONS.md`** (the bar for what merits an entry) — live in **`AUTHORING.md`**, the authoring spec the slash commands cite. They are kept out of this principles doc deliberately: long, command-facing, and changing on a different cadence than the principles here. This file defines *what* those files are (see "Every project has these files"); `AUTHORING.md` defines *how* to write them.

### Grilling a plan into the docs

`/grill` (a project-system slash command — see `claude/commands/grill.md`) runs a relentless one-question-at-a-time interview that walks a plan's decision tree, sharpens fuzzy language, and cross-references claims against the code. It is **self-contained** — it carries its own `GLOSSARY.md` and `DECISIONS.md` format guidance and does not depend on any external skill.

When run inside a project here, its outputs reconcile to this system: **resolved terms → `GLOSSARY.md`** (glossary), **decisions that clear the bar → `DECISIONS.md`**. Its "cross-reference with code" step doubles as any survey/enumeration a phase needs.

**The grill is never automatic, and when it does run it runs *first*.** Setup used to enter a bounded interrogation on every project. It no longer does — most projects should be asked nothing. But the offer, when warranted, is made at a specific moment: **after setup has read everything and before it has written anything.** That is the only point where the answer is free. A grill that runs afterwards has to *revise* the overview and the phase plan; a grill that runs first *informs* them.

So `/setup-project` reads, judges, and — where the project has several interlocking open decisions, an unstateable success criterion, or vocabulary that keeps shifting — **stops and hands off**: run `/grill`, then re-run setup, which is non-destructive and simply builds on whatever the grill pinned down. It does not inline the interview; `/grill` is the single home for that discipline. Declined or unwarranted, setup writes immediately and does not raise it again. `/grill` remains invokable at any point in a project's life, not just at intake.

### Naming

- Project folders: `kebab-case`
- Archive folders: prefix with year for natural sorting (`2025-google-workspace-licensing/`)
- **Source materials are taken by path, in any of the three shapes a path arrives in.** A Finder drag (escaped), a "Copy as Pathname" paste (unescaped, real spaces), and a hand-quoted path all resolve to the same file. Two rules make that hold: `_reg_drag_path` undoes *all* of Finder's escaping, not just spaces, and the prompt tests the intact line as a single absolute path before it splits on whitespace. Requiring absolute is what lets the second rule coexist with the prose catch - a typed description can never be mistaken for a path.
- **The title keeps its punctuation; the folder hyphenates it.** One derivation (`_reg_slug` in `bin/_registry.sh`) turns a title into a folder name: lowercase, then `.` `_` `/` become hyphens, anything else non-alphanumeric is dropped, spaces become hyphens, runs collapse, ends trim. Separators become hyphens rather than *vanishing*, because a dot in a title is nearly always a word boundary - a domain, a version, an extension - and deleting it welds the parts together: `optient.io` → `optient-io`, not `optientio`. The title itself is never rewritten; only the folder name is derived.

### Document naming

Two positive rules govern what a root `.md` file is named — and the name itself tells you which kind of file you're looking at:

1. **A folder's overview doc is named after the folder** (lowercase kebab, mirroring it exactly). The project overview is `<project-name>.md` — e.g. `Active/website-builder/website-builder.md`. This is the same law already used one level down inside projects: `blocks/accordion/accordion.md`, `blocks/hero/hero.md`. A folder's own source-of-truth document carries the folder's name. Located programmatically as `$(basename <folder>).md`.

   **When the folder's own name isn't lowercase kebab, the *name* is what's mirrored, and the doc still gets kebab-cased** — `~/Projects/` carries `projects.md`, not `Projects.md`. Project folders are kebab-case by convention (§ *Naming*), so this only ever arises above them, at the workspace root. Renaming a home-directory folder to close a one-capital gap is not worth it.

   **Rule 1 is about the overview, not about how many `.md` files a folder may hold.** A generically-named doc can sit *beside* a self-named overview when it is a genuinely different document type — a `README.md` written for outsiders, a convention doc — as long as it isn't standing in *instead of* one. What rule 1 forbids is a folder whose self-description is filed under a generic name.
2. **Fixed cross-project system slots stay ALLCAPS** — `PLAN.md`, `DECISIONS.md`, `CHECKLIST.md`, `GLOSSARY.md`, `CLAUDE.md`. These have the *identical* name in every project; ALLCAPS marks them as system slots, not project content. (`CLAUDE.md` is ALLCAPS-mandated by Anthropic regardless; the rest follow the 2026-05-18 ALLCAPS-bookkeeping convention.)

The payoff is a **self-identifying filesystem**: the single lowercase `.md` at a project root is the project's own overview; everything ALLCAPS is a predictable system slot. The visual distinction carries meaning — `website-builder.md` is "the project," `CLAUDE.md` / `PLAN.md` are "the machinery." This is the filesystem-level expression of **Fractal Self-Describing Nodes** (see *Design principles*) — the "a folder's overview is named after the folder" law applied at every altitude.

**Archive keeps the invariant.** When the mover's **archive** action year-prefixes a folder (`website-builder/` → `2025-website-builder/`), it renames the overview alongside it (`website-builder.md` → `2025-website-builder.md`) so rule 1 holds everywhere — including `Archive/`, which is a read-later keepsake shelf where the doc still gets opened. **Unarchive** is the symmetric inverse: it strips the year prefix and renames the overview back. The Active⇄Inactive moves (`deactivate` / `activate`) don't rename the folder, so they don't touch the overview.

### Scripts that operate on the projects system live in `~/project-system/bin/`

Custom scripts that manage the project system itself go in `~/project-system/bin/` — `newproject` (scaffolds a *new* project into `Active/` from the template) and `importproject` (brings an *existing* folder or git repo into `Active/` — copies/clones it in, then offers the same `/setup-project` intake); both write the `~/.claude.json` trust entry. Neither writes to the `project-system` repo: the folder is the record, so there is nothing to commit. Plus the dashboard-launched `moveproject` (the state-aware front door to *all* transitions — deactivate / activate / archive / unarchive / delete), shared helpers sourced by them (`_registry.sh` / `_ui.sh`), and standalone tooling (`make-release.sh`, `repo-visibility.sh`, `audit-backups.sh`, `list-projects.sh`). **The canonical per-script inventory lives in the maintenance `CLAUDE.md` and in `bin/` itself — not duplicated here**, so this rule doesn't drift every time a script is added.

Reasoning:
- They're infrastructure, not assets
- They're tightly coupled to the system layout (paths, conventions)
- Aliases in `.zshrc` point at them
- Keeping them in `~/project-system/` alongside CONVENTIONS / LEXICON
  reflects their role as part of the system, not part of the workspace

`Active/` (and `Inactive/` when set down) is for tools and assets that *you*
reach for during work (playbooks, skills, cheatsheets, templates).
`~/project-system/bin/` is for tools that the *system* uses to maintain itself.

### Project setup workflow: bash + Claude split

`newproject` is two stages by design — a bash script and a Claude slash command — because each handles what it's best at:

| Stage | Lives at | Handles |
|---|---|---|
| `newproject.sh` (bash) | `~/project-system/bin/newproject.sh` | Deterministic parts: title prompt, optional source-material drop, folder-name confirmation (echoes title + derived slug, accept-on-Enter — the typo net), template copy (`cp -r`), `.system/project.md` metadata, `~/.claude.json` pre-trust, launching Claude |
| `/setup-project` (Claude slash command) | `~/project-system/claude/commands/setup-project.md` (symlinked into `~/.claude/commands/` by this repo's `install.sh`) | Flexible parts: orientation, sort references/ (working content vs. source material), **sharpen the definition** (seed cross-project lexicon terms → reflect the registration description back once → judge whether a `/grill` hand-off is warranted *before writing*, and stop if so), inference of project type/stack, project-overview synthesis (`<project-name>.md`, when it adds over CLAUDE.md — skipped for thin projects), glossary generation (`GLOSSARY.md`, when terms exist), optional scaffolding, populating `CLAUDE.md` / `PLAN.md` / `DECISIONS.md` / `CHECKLIST.md`, per-entry review of Conventions/Don'ts, content-level audit, originating-brief cleanup, `git init`, optional git-remote connection |

The handoff is the last line of `newproject.sh`: `(cd "$project_dir" && claude "/setup-project")`. Bash finishes its structured work; Claude takes over for the conversational rest. `importproject` shares the same two-stage split and the same Claude handoff — only the "fill the folder" step differs (copy/clone an existing source instead of the template), and there the intake is *offered*, not forced, so bulk adoption stays fast.

Why split: bash is reliable for structured prompts and file operations but bad at content generation and project-type-specific branching. Claude is reliable for natural-language Q&A and content generation but slower and pricier for deterministic ops. Each piece does only what it's good at.

When to change which: a new bash-shaped prompt or file op → `newproject.sh`. A new conversational step, project-type variant, or content-generation step → `/setup-project`.

### Setup has one mode, and it is non-destructive

`/setup-project` **creates only what is absent and never modifies, overwrites, or
deletes anything already there.** There is no second mode and no marker selecting
one. Whether the project was registered ten seconds ago or imported from five
years of someone else's work, the posture is identical: read what is here, draft
what is missing, touch nothing that exists.

It did once have two modes. *Greenfield* was licensed to generate **over** a
project's files, because `newproject` copied a `_template/` folder of hollow stubs
and something had to be allowed to overwrite them; *adopt* was the safe path for
real content, selected by a `state:` marker in `.system/project.md`. Remove the
stubs — as registration did — and there is nothing to overwrite, so the safe path
is correct for every project and the marker has no reader left. The mode split
existed only to license overwriting files the system had itself created empty.

**The contract** (why it is safe by construction): create-if-absent · never
modify/overwrite · never delete · *visibility-aware* writes (check `git remote`
before committing identifying content — local-only → real names, public →
abstract; account-secrets never enter the repo regardless) · no empty stubs (only
always-applies docs are unconditional; `GLOSSARY.md` and the overview earn their
place). A project that already has its **own `CLAUDE.md`** keeps it untouched;
setup offers `/grill` to reconcile it. Because setup can touch a person's
*existing* work, the flow is **loud** — it announces the rule, shows a
found-vs-missing inventory, and reports created-vs-skipped (the same "announce
every path" ethos as `install.sh`).

Note the direction of the guarantee. Create-if-absent is **structural**: there is
no code path that overwrites, so no judgment call can go wrong. The old marker was
an *instruction* — "read `state:` and pick the right branch" — guarding a
destructive default, with a prose escape hatch ("when unsure, treat it as adopt")
as the only backstop. Making the wrong thing unavailable beats remembering not to
do it.

### Where logic lives (the placement test)

The bash-vs-prose split above generalizes to a test for *any* new capability — apply it deliberately, don't default by habit:

- **`bin/` (portable shell tool)** — deterministic, reusable, no judgment. Ships with the system; works for every adopter. **Even a piece of "agent behavior" belongs here if it has a deterministic core** — extract the core into a tool, leave only the judgment in prose. Example: `bin/repo-visibility.sh` returns a repo's `private`/`public`/`unknown` (robust to multi-account `gh` / SSH-alias setups); the *push-or-confirm* judgment that consumes it stays in the agent's git rule.
- **`claude/commands/*.md` (agent prose)** — needs judgment, synthesis, or conversation; varies per project. *Exception:* keep logic as prose when extracting it would **duplicate a format/spec defined once** — e.g. the `GLOSSARY.md` entry format lives in one place, so the lexicon-seed stays prose rather than re-encoding the format in bash.
- **Personal / machine-specific** (a user's `dotfiles`, global `CLAUDE.md`) — never the portable system. The system may *provide a tool* that a personal rule calls; the invocation stays personal, the tool stays shared.

The trap: filing a deterministic, reusable capability under "agent behavior" — and thus into personal config — just because a *rule* triggers it. Ask **"is there a pure-function core here?"** If yes, it's a `bin/` tool, and only the decision that uses it is prose.

## Session workflow

For multi-session projects:

1. Start session: `cd` into the project and run `claude` — global rules + per-project `CLAUDE.md` load automatically
2. Do the work
3. End session: keep `CHECKLIST.md` and `DECISIONS.md` current so the next session has working memory
4. Close out until next session

The project memory lives in files (`CLAUDE.md` / `<project-name>.md` / `PLAN.md` / `DECISIONS.md` / `CHECKLIST.md` / `GLOSSARY.md`), not in chat history.

## The life of a project

1. **Register** — `newproject` (alias, or the dashboard's `n`): prompts for a
   title, a one-line description and optional source material, then writes the
   floor and the records. Setup is offered afterwards, defaulting to no.
2. **Work** — across one or many sessions, updating files as you go
3. **Set down or finish** — from the `proj` dashboard, type `m` on the project:
   `deactivate` it to `Inactive/` when you step away, or `archive` it to
   `Archive/YYYY-foo` when it's done.
4. **Maybe revive** — `unarchive` brings a project back from the cold vault (it
   thaws to `Inactive/`; `activate` it to go warm). Projects can come back if a
   client wants updates or you want to revisit. Don't agonize about it.

## Design principles

These meta-principles have guided the design of this system and should guide
future changes.

### Fractal Self-Describing Nodes

*The foundational structural law of this system — the one the other principles here
serve; in prose, "the node law."* **Every node describes itself, in a consistent shape,
at every altitude.** *Shorthand: **fractal selves** (canonical) / **FSDN** (written
acronym) / "fractal nodes" (accepted synonym — normalize to "fractal selves" in
writing). One-liner: **every node is a fractal self.** Public-facing first use is
always the full term — the prose shorthands collide (see Lineage); FSDN is fine once
the full term has appeared.*

A *node* is any unit of organization — the whole portfolio, a project, a sub-tool, a
catalog entry. Three properties:

1. **Self-describing** — each node carries its own identity/overview in a consistent,
   templated shape (the portfolio's overview; a project's `<project-name>.md`
   overview; a tool's `<tool>.md`; a catalog entry). The same "describe yourself" move
   at every level.
2. **Scale-invariant (fractal)** — that move repeats at *every altitude*. Zoom in or
   out and you always land on a node that explains itself. (Already stated under
   *Document naming* as "the same law used one level down" — `blocks/accordion/
   accordion.md`.)
3. **Whole *and* part at once** — each node is self-contained (understandable on its
   own) *and* simultaneously a member of the node above - and everything beneath it
   is findable by the same rule, with no list to keep. It's **built to point up** (to
   its parent) and **down** (to its children) — every node is both a map and a
   thing-on-a-map. The payoff is navigation
   that doesn't dead-end; like completeness, that's the goal the discipline serves, not
   a structural guarantee (see *What's structurally enforced vs. discipline* below).
   ("node" is the right word precisely because a node is inherently part of a graph.)

**The shape is the index.** Because every child names itself by rule, what lies below
any node is *computed* (the directory listing), never authored. A parent's overview
describes the parent, not its children; it may curate - an order, a *start here* - but
nothing may depend on that list being complete. The test: delete the list, and
everything must still be findable by the rule. The root is not special - it is merely
the node with nothing to point up to. (Sharpened 2026-08-21 with the public page: the
law's one-liner now ends "so there is no index to keep. The shape is the index.")

**The workspace obeys it directly.** `~/Projects` carries its own overview,
`projects.md`, and that overview names the three tiers and points at this file for
what they mean. It lists no projects. **A project is a folder in `Active/`,
`Inactive/` or `Archive/`** - that is the whole rule, and what lies in each tier is
computed by listing it. Where a project has an overview, that overview is named after
its folder (§ *Document naming*); many projects correctly have none, because the
overview is *earned* (§ *What a project contains*), so the rule is about **naming**,
not about coverage. `project-system/INDEX.md` was a documented deviation here until
2026-08-21 - a script-maintained list of every project, with a drift check in
`skills-catalog.sh` as the standing cost of keeping it. It was dissolved rather than
kept: the dashboard reads the workspace, so there is no second list to disagree with
the first, and the drift check is not disabled but impossible.

**The tiers themselves carry no overview, deliberately.** `Active/`, `Inactive/` and
`Archive/` are grouping folders - plural common nouns whose contents are self-evident
and computed. Naming all three in `projects.md` is what makes them findable; nothing
inside them has to be maintained. Adding `Active/Active.md` would create a node with
nothing to say that the rule does not already say.

**Mechanism is medium-specific.** The law is the *behavior* (self-describe + point
up/down), not the file type. Organizational/navigational nodes — the folders a human
opens to understand structure — use `folder/folder.md`. Only **containers** — units with
children to index — earn the sidecar/index file; a **leaf** (a lone file) self-describes
in-band (its own header or docstring) and only points up, so not every file needs an
overview, just containers. Pure code packages satisfy it
through their native idiom (package docstring / README); don't add a parallel `.md`
that shadows the code's own self-description. **Generated/produced output is never a
node** — it's output, not authored structure (e.g. `node_modules`, build dirs), so it's
excluded with no judgment needed. For authored directories the *test* is: *would a human
navigate here to understand the system?* If yes, it's an organizational node and earns
the `.md`. The principle itself is medium-general — so are its ancestors (holon, HATEOAS,
Zettelkasten) — and this system realizes it in the filesystem, with no claim to have
built it elsewhere.

**What's structurally enforced vs. discipline.** Be precise about the word "law": what's
actually *enforced* is narrow. **Co-location is structural** — because an overview lives
inside its node and is named after it, the two can't drift apart (rename/move/delete
carries the description along). But **completeness** (that every node *has* its overview,
and every parent indexes its children) and **accuracy** (that the overview stays true)
are **disciplines the law asks for, not
guarantees it makes** — nothing structural compels them, and the outcomes that depend on
them (e.g. no dead-ends, Property 3) are goals, not guarantees. So, precisely:
*structurally enforced against orphaning/drift; a discipline toward completeness and
accuracy.*

The principle was already implicit across the system; naming it makes it a deliberate
law to apply going forward. **Known instances:**
- **The self-identifying filesystem** (*Document naming* below): a folder's overview is
  named after the folder, at every level.
- **A folder-per-tool catalog** (`stack/<tool>/<tool>.md` + a `README.md` defining
  the entry shape + a master index).
- **A platform tool-doc convention** (`<node>/<tool>/<tool>.md`, status-marked).
- **An ecosystem map** — a self-describing node for an entire multi-project ecosystem.

**Apply it when adding structure:** any new container — a project, a sub-tool, a
module, a grouping — gets a self-named overview in the shape its level uses, pointing
up (to its index) and down (to its children). *Don't create a structural node that
can't describe itself.*

**Lineage (prior art).** This is a deliberate synthesis, not a coinage from nothing.
The whole-and-part-at-once property is Koestler's **holon / holarchy** (1967); in code
it's the **Composite pattern** (treat part and whole uniformly); the no-dead-end
up/down linking is **HATEOAS** (hypermedia) and, in knowledge work, **Zettelkasten /
Maps of Content**; scale-invariance is plain **self-similarity**. Prior "fractal
documentation" / "fractal knowledge" systems exist, and "fractal node" is already a
term of art in complex-network science (self-similar connectivity) — which is why the
*public* name is the full **Fractal Self-Describing Nodes**, never the colliding
shorthand. What's ours is the synthesis applied as an *authoring law*: the
self-naming index file (`folder/folder.md`) at every altitude — "don't create a node
that can't describe itself" (what that "law" does and doesn't enforce is set out in
*What's structurally enforced vs. discipline* above).

_(First capture 2026-06-06; naming + lineage pass 2026-06-07; enforcement-claim trued + Property 3 aligned 2026-06-09; the shape is the index + INDEX.md named a deviation 2026-08-21, then dissolved and the workspace brought under the law the same day. Still refining.)_

### If the answer is always the same, it's a convention, not a question

When a script, template, or workflow asks for the same answer every time,
that answer belongs in a default — not in a prompt.

Examples that applied this rule:
- `newproject` doesn't ask "what's the first action?" because the answer is
  always "draft PLAN.md." That goes in the template as a default.
- The global CLAUDE.md plan cut "name, role, location" prompts because those
  don't change Claude's behavior per session.

When designing new tooling, watch for repeated answers and convert them to
conventions.

### When you remove a mandate, inventory what it was carrying

A forced step is rarely doing only one thing. It mandates something *and* it
quietly guarantees a handful of side properties nobody wrote down, because the
mandate made them automatic. Delete the mandate and those properties leave with
it, silently — the removal looks clean, the tests still pass, and the loss
surfaces weeks later as "didn't this used to…?"

**The check, before removing any forced step: list everything that was true only
because it always ran, and decide each one explicitly** — re-home it, replace it,
or accept losing it *out loud*. Then verify the re-homing landed, rather than
assuming it did.

**And re-homing the mechanism is not enough — the *reason* has to survive the new
context too.** This is the half that bit within hours of the principle being
written. The audit found the Finder open missing, so it was restored to the new
ending: mechanism recovered, box ticked. But the old flow opened the folder at the
end of *setup*, when a full doc set was there to look at; a registered project has
exactly one visible file, so the restored `open .` popped a near-empty window that
made the project read as broken rather than ready. The property was carried
forward and was still wrong, because only its *implementation* had been asked
about. So the question is not "where does this go now?" but **"does the thing it
was for still hold here?"** — and if it doesn't, dropping it is the correct
re-homing.

Three from the 2026-08-13 flow redesign, in ascending order of how nearly they
escaped:

- **Deleting `_template/`** would have taken the `DECISIONS.md` **bar** with it —
  the folder's one piece of real content, sitting in a file everyone read as a
  hollow stub. Caught while inventorying; moved to `AUTHORING.md` and into the
  generator.
- **De-forcing the grill** dropped its **ordering**. The always-entered Phase 0
  ran *first* so it could inform the overview and the phases; moving the offer to
  the end meant a grill would instead have to *revise* them. Caught by David
  asking "should we END with the grill or offer it at the START?"
- **Not launching setup automatically** dropped the **Finder open** at closeout.
  Registration became the default ending, and `open .` lived only in setup's
  Step 10a, so the common path silently stopped doing something the old path
  always did. Caught only by a deliberate after-the-fact audit of this very
  question — two of the four candidates that audit turned up were false alarms
  (already safely re-homed in `grill.md`), which is exactly why it has to be
  checked rather than recalled. And then re-homed *wrongly* on the first attempt,
  per the clause above: the window was restored before anyone asked whether a
  three-file project was worth opening. It isn't; the correct answer was to drop
  it.

The pattern generalizes past this system: **a mandate is also a carrier.** Ask
what rides along on it before cutting it loose.

### Templates only get pressure-tested when new instances are spawned

Tools and templates can't be tested through "normal use" — they only show
their flaws when actually instantiated.

This means:
- The pace of refinement = the pace of new instances, not calendar time
- Plan to deliberately spawn 2-3 new instances when testing a new template
- Don't wait passively for problems to surface — go find them by spawning new instances

Applies to: the registration floor, `CLAUDE.md` templates, agent templates, any
reusable scaffolding.

### Alphabetize lists shown to humans

When tooling shows the user a choice list (projects, options), alphabetize
it. Predictable order = faster scanning. Applied in: the mover's project picker
(`moveproject`). Apply to future selectors as they're built.

### Cheatsheets show named workflows, not raw commands

A cheatsheet is a muscle-memory accelerator, not a reference manual. When a named
workflow exists (a function, an alias, a script), the cheatsheet shows that.
Raw commands appear on the cheatsheet only as fallback, when no named workflow
exists yet (e.g., completing a project — until a `complete` script exists, the
raw `mv` line stays).

Corollary: don't add an alias just because something *could* be one. Add an
alias only when you'll actually use it. Aspirational aliases are noise.

## Things to NOT do

- Don't make folders that describe medium (`code/`, `docs/`). Describe purpose.
- Don't pre-organize Active by type. Wait for real pain.
- Don't skip writing decisions down. Future-you will not remember why.
- Don't reintroduce a master list of projects. The workspace is the list (see *Fractal Self-Describing Nodes* — "the shape is the index"); a second copy is a thing that can disagree with it, and this system kept one for three months and paid for it with a drift check.
- Don't put system files in `~/Projects/`. The workspace holds the three tiers (Active, Inactive, Archive) and its own overview, `projects.md` — and nothing else. The overview is not an exception to this rule but the node law applying at the top altitude: every node describes itself, the root included.
- Don't add a `README.md` by default — it's opt-in only, for projects about to go public (per the "Optional, opt-in per project" section above). When you do create one, it's content-only (no system frontmatter — that lives in `.system/project.md`).

## When this system itself needs to change

Edit this file for the principle; add a dated entry to `CHANGES.md` recording what
changed and *why*. Don't try to keep the system pristine — let it evolve like
everything else you keep. (`CHANGES.md` is the load-bearing design history —
future maintainers read it to understand why a rule exists.)

