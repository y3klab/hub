#!/bin/bash
#
# install.sh — stand up project-system on this machine.
#
# Does the whole local setup:
#   • checks prerequisites (git, Claude Code, zsh)
#   • symlinks the slash commands into ~/.claude/commands/
#   • seeds your personal LEXICON.md from the shipped example
#   • creates the ~/Projects/{Active,Inactive,Archive} workspace
#   • offers to wire the shell aliases into ~/.zshrc
#   • asks what to launch when you open a project (default: Claude Code)
#
# Transparent by design: it announces every path it touches, shows the exact
# ~/.zshrc line before asking, and supports --dry-run to preview every change
# without making any. Fully interactive on a terminal (animated, with prompts);
# degrades to plain, non-blocking output when piped or in CI. Safe to re-run —
# every step is idempotent.
#
#   install.sh              run it
#   install.sh --dry-run    show every change it WOULD make, change nothing
#   install.sh --help       this help

set -e

SYSTEM_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

usage() {
  cat <<'EOF'
install.sh — set up project-system on this machine.

  install.sh              run the installer (interactive)
  install.sh --dry-run    show every change it WOULD make, and change nothing
  install.sh --help       show this help

It symlinks the project slash commands into ~/.claude/commands/, seeds your
LEXICON.md from the shipped example, creates the ~/Projects workspace, and
offers to add one line to ~/.zshrc. It touches nothing else, makes no network
calls except the ones you approve, and reports nothing about you.
EOF
}

DRY=0
for a in "$@"; do
  case "$a" in
    -n|--dry-run) DRY=1 ;;
    -h|--help)    usage; exit 0 ;;
    *) printf 'install.sh: unknown option %s (try --help)\n' "$a" >&2; exit 2 ;;
  esac
done

# ----------------------------------------------------------------------
# Capability detection + palette (no styling / no animation off a TTY)
# ----------------------------------------------------------------------
if [ -t 1 ] && [ "${TERM:-dumb}" != "dumb" ]; then
  FANCY=1
  C_RESET=$'\e[0m'; C_BOLD=$'\e[1m'; C_DIM=$'\e[2m'
  C_ACCENT=$'\e[38;5;39m'; C_OK=$'\e[38;5;42m'; C_WARN=$'\e[38;5;220m'
  # synthwave gradient stops (magenta → purple → blue → cyan)
  G1=$'\e[38;5;201m'; G2=$'\e[38;5;135m'; G3=$'\e[38;5;75m'; G4=$'\e[38;5;45m'
else
  FANCY=0
  C_RESET=''; C_BOLD=''; C_DIM=''; C_ACCENT=''; C_OK=''; C_WARN=''
  G1=''; G2=''; G3=''; G4=''
fi

# Vendored PHOS4 engine — single-sources the splash's wordmark data, synthwave
# ramp, and loadbar (the SYSTEM wordmark + ramp live once now, in the Y3K theme).
source "$SYSTEM_DIR/bin/phos4.sh"

ok()    { printf "  ${C_OK}${C_BOLD}[✓]${C_RESET} %s\n" "$1"; }
warn()  { printf "  ${C_WARN}${C_BOLD}[!]${C_RESET} %s\n" "$1"; }
info()  { printf "      ${C_DIM}%s${C_RESET}\n" "$1"; }
act()   { printf "      ${C_DIM}→${C_RESET} %s\n" "$1"; }              # a concrete change made
would() { printf "      ${C_DIM}[dry-run] would${C_RESET} %s\n" "$1"; } # a change previewed
phase() { printf "\n  ${C_ACCENT}${C_BOLD}▸ %s${C_RESET}\n" "$1"; }
pause() { if [ "$FANCY" = 1 ]; then sleep "${1:-0.18}"; fi; }
# ~-shorten a path for display
tilde() { case "$1" in "$HOME"/*) printf '~%s' "${1#"$HOME"}" ;; "$HOME") printf '~' ;; *) printf '%s' "$1" ;; esac; }

# A cosmetic "loading" bar that fills, then clears itself (TTY only).
# loadbar — folded onto PHOS4 (phos4_loadbar is byte-identical to the original).
loadbar() { phos4_loadbar "$@"; }

# ask_yes "question" → 0 if yes (default Yes). Non-interactive → 1 (skip, never blocks).
ask_yes() {
  local q="$1" reply
  [ -t 0 ] || return 1
  printf "  ${C_BOLD}%s${C_RESET} [Y/n] " "$q"
  read -r reply || reply=""
  case "$reply" in [Nn]*) return 1 ;; *) return 0 ;; esac
}

# banner_shimmer — power on the wordmark, then flow the gradient down it.
# Whole-line colouring (multibyte-safe); plain rows off a TTY.
banner_shimmer() {
  # SYSTEM wordmark from the Y3K theme (was hardcoded here; now single-sourced).
  local lines=() _l
  while IFS= read -r _l; do lines+=("$_l"); done < <(phos4_wordmark system)
  local nl=${#lines[@]} i
  if [ "$FANCY" != 1 ]; then
    for ((i=0; i<nl; i++)); do printf "    %s\n" "${lines[i]}"; done
    return
  fi
  local pal pn frame; read -ra pal <<< "$(phos4_anim_ramp)"   # ramp from the theme
  pn=${#pal[@]}
  # power-on: reveal each row in a vertical gradient
  for ((i=0; i<nl; i++)); do
    printf "    \e[38;5;%sm%s\e[0m\n" "${pal[i*2]}" "${lines[i]}"
    sleep 0.05
  done
  # shimmer: flow the gradient down the wordmark a few frames
  for ((frame=1; frame<=9; frame++)); do
    printf '\e[%dA' "$nl"
    for ((i=0; i<nl; i++)); do
      printf "\r    \e[38;5;%sm%s\e[0m\e[K\n" "${pal[(i+frame)%pn]}" "${lines[i]}"
    done
    sleep 0.06
  done
}

# ----------------------------------------------------------------------
# Banner
# ----------------------------------------------------------------------
printf "\n"
printf "  ${G1}░${G2}▒${G3}▓${G4}█${C_RESET}\n"; pause 0.06
banner_shimmer
printf "  ${G4}▔▔▔▔${C_RESET} ${C_DIM}a tiny operating system for your projects${C_RESET} ${G1}▔▔▔▔${C_RESET}\n"
pause 0.25

# ----------------------------------------------------------------------
# Disclosure — exactly what this touches, before anything changes
# ----------------------------------------------------------------------
A="${C_ACCENT}│${C_RESET}"
printf "\n"
printf "  ${C_ACCENT}┌─[ what this installer does ]───────────────────────${C_RESET}\n"
printf "  %s\n" "$A"
printf "  %s   Sets up project-system on this machine. It will:\n" "$A"
printf "  %s\n" "$A"
printf "  %s   ${C_DIM}•${C_RESET}  symlink the slash commands into ${C_BOLD}~/.claude/commands/${C_RESET}\n" "$A"
printf "  %s   ${C_DIM}•${C_RESET}  seed ${C_BOLD}~/project-system/LEXICON.md${C_RESET} ${C_DIM}(gitignored; yours)${C_RESET}\n" "$A"
printf "  %s   ${C_DIM}•${C_RESET}  create ${C_BOLD}~/Projects/{Active,Inactive,Archive}${C_RESET}\n" "$A"
printf "  %s   ${C_DIM}•${C_RESET}  offer to add ${C_BOLD}one line${C_RESET} to ${C_BOLD}~/.zshrc${C_RESET} ${C_DIM}(it asks, and shows the line)${C_RESET}\n" "$A"
printf "  %s   ${C_DIM}•${C_RESET}  ask what to launch when you open a project ${C_DIM}(default Claude Code)${C_RESET}\n" "$A"
printf "  %s   ${C_DIM}•${C_RESET}  if git is missing → run ${C_BOLD}xcode-select --install${C_RESET}\n" "$A"
printf "  %s\n" "$A"
printf "  %s   ${C_DIM}Every path it touches is printed as it happens. It won't${C_RESET}\n" "$A"
printf "  %s   ${C_DIM}touch your git config, SSH keys, or shell prompt, and${C_RESET}\n" "$A"
printf "  %s   ${C_DIM}reports nothing about you. No telemetry. Re-running is${C_RESET}\n" "$A"
printf "  %s   ${C_DIM}safe (idempotent). Preview it all first with --dry-run.${C_RESET}\n" "$A"
printf "  %s\n" "$A"
printf "  ${C_ACCENT}└────────────────────────────────────────────────────${C_RESET}\n"
if [ "$DRY" = 1 ]; then
  printf "\n  ${C_WARN}${C_BOLD}● DRY RUN${C_RESET} ${C_DIM}— showing what would happen; nothing will change.${C_RESET}\n"
elif [ -t 0 ]; then
  printf "\n  ${C_BOLD}Press Enter to begin${C_RESET} ${C_DIM}· Ctrl-C to cancel${C_RESET} "
  read -r _ || true
fi

# ----------------------------------------------------------------------
# 1. Prerequisites
# ----------------------------------------------------------------------
phase "Checking your system"

loadbar "looking for git…"
if command -v git >/dev/null 2>&1; then
  ok "git  ${C_DIM}($(git --version 2>/dev/null | awk '{print $3}'))${C_RESET}"
else
  warn "git not found"
  if [ "$(uname)" = "Darwin" ]; then
    if [ "$DRY" = 1 ]; then
      would "run:  xcode-select --install   ${C_DIM}(installs git via Command Line Tools)${C_RESET}"
    else
      info "running:  xcode-select --install   (installs git; finish the popup)"
      xcode-select --install 2>/dev/null || true
      info "the rest of setup continues without waiting on it."
    fi
  else
    info "install git with your package manager, then re-run."
  fi
fi

loadbar "looking for Claude Code…"
if command -v claude >/dev/null 2>&1; then
  ok "Claude Code"
else
  warn "Claude Code not found — the slash commands (/setup-project, /grill…) need it."
  if [ "$DRY" = 1 ]; then
    would "offer to open  https://claude.com/claude-code"
  elif ask_yes "Open the install page now?"; then
    info "opening  https://claude.com/claude-code"
    open "https://claude.com/claude-code" 2>/dev/null || info "Visit https://claude.com/claude-code"
  else
    info "Install it any time from https://claude.com/claude-code"
  fi
fi

loadbar "looking for zsh…"
if command -v zsh >/dev/null 2>&1; then
  ok "zsh"
else
  info "zsh not found — the aliases target zsh; bash works too."
fi

# ----------------------------------------------------------------------
# 2. Install  (each change is announced with its real path)
# ----------------------------------------------------------------------
phase "Installing"

loadbar "linking slash commands…"
linked=0
for cmd in "$SYSTEM_DIR"/claude/commands/*.md; do
  [ -e "$cmd" ] || continue
  base="$(basename "$cmd")"
  dst="$HOME/.claude/commands/$base"
  cur="$(readlink "$dst" 2>/dev/null || true)"   # link target, or "" if not a symlink
  if [ "$cur" = "$cmd" ]; then
    act "already linked  $(tilde "$dst")"
  elif [ -L "$dst" ] && [ "${cur%/claude/commands/"$base"}" != "$cur" ]; then
    # An existing project-system command link pointing somewhere else — a stale or
    # dangling target left by a repo rename/move. It's ours; repoint it (self-healing).
    if [ "$DRY" = 1 ]; then
      would "repoint  $(tilde "$dst")  →  $(tilde "$cmd")  ${C_DIM}(was $cur)${C_RESET}"
    else
      ln -sfn "$cmd" "$dst"
      act "repointed  $(tilde "$dst")  →  $(tilde "$cmd")  ${C_DIM}(was $cur)${C_RESET}"
    fi
  elif [ -e "$dst" ] || [ -L "$dst" ]; then
    warn "$(tilde "$dst") exists and isn't ours — left it alone"
    continue
  elif [ "$DRY" = 1 ]; then
    would "symlink  $(tilde "$dst")  →  $(tilde "$cmd")"
  else
    mkdir -p "$(dirname "$dst")"
    ln -s "$cmd" "$dst"
    act "linked  $(tilde "$dst")  →  $(tilde "$cmd")"
  fi
  linked=$((linked + 1))
done
ok "$linked slash command(s) in ~/.claude/commands/"

# Prune orphaned command links. The loop above only visits command files that
# still exist, so a link left by a command that was RENAMED or REMOVED in this
# repo (a command file renamed in a later release) is never revisited — the
# old link survives as a ghost command pointing at a target that's now gone.
# Sweep for it: remove any link in ~/.claude/commands/ that points into THIS
# repo's claude/commands/ but whose target no longer exists. Foreign links and
# live links are never touched.
pruned=0
if [ -d "$HOME/.claude/commands" ]; then
  for link in "$HOME/.claude/commands"/*; do
    [ -L "$link" ] || continue
    tgt="$(readlink "$link" 2>/dev/null || true)"
    case "$tgt" in
      "$SYSTEM_DIR"/claude/commands/*)
        [ -e "$tgt" ] && continue   # live link — leave it
        if [ "$DRY" = 1 ]; then
          would "remove orphaned link  $(tilde "$link")  ${C_DIM}(dead target $(tilde "$tgt"))${C_RESET}"
        else
          rm -f "$link"
          act "removed orphaned link  $(tilde "$link")  ${C_DIM}(dead target $(tilde "$tgt"))${C_RESET}"
        fi
        pruned=$((pruned + 1))
        ;;
    esac
  done
fi
[ "$pruned" -gt 0 ] && ok "pruned $pruned orphaned command link(s)"

loadbar "seeding LEXICON.md…"
LEX="$SYSTEM_DIR/LEXICON.md"
if [ -f "$LEX" ]; then
  act "$(tilde "$LEX") already exists — left untouched"
elif [ -f "$SYSTEM_DIR/LEXICON.example.md" ]; then
  if [ "$DRY" = 1 ]; then
    would "copy  LEXICON.example.md  →  $(tilde "$LEX")"
  else
    cp "$SYSTEM_DIR/LEXICON.example.md" "$LEX"
    act "seeded  $(tilde "$LEX")  from LEXICON.example.md"
  fi
fi
ok "LEXICON ready ${C_DIM}(your cross-project vocabulary — edit to make it yours)${C_RESET}"

loadbar "creating the ~/Projects workspace…"
for d in Active Inactive Archive; do
  wd="$HOME/Projects/$d"
  if [ -d "$wd" ]; then act "exists   $(tilde "$wd")/"
  elif [ "$DRY" = 1 ]; then would "create  $(tilde "$wd")/"
  else mkdir -p "$wd"; act "created  $(tilde "$wd")/"; fi
done
ok "Workspace ready"

# ----------------------------------------------------------------------
# 3. Shell aliases → ~/.zshrc  (show the exact line, then ask)
# ----------------------------------------------------------------------
phase "Shell aliases"

FRAG_LINE='[ -f "$HOME/project-system/shell/zshrc-fragment.sh" ] && source "$HOME/project-system/shell/zshrc-fragment.sh"'
ZSHRC="$HOME/.zshrc"

info "This one line activates the aliases (newproject, proj, list, …):"
printf "      ${C_BOLD}%s${C_RESET}\n" "$FRAG_LINE"
printf "      ${C_DIM}↳ would be appended to %s${C_RESET}\n\n" "$(tilde "$ZSHRC")"

if grep -qsF "project-system/shell/zshrc-fragment.sh" "$ZSHRC"; then
  act "already present in $(tilde "$ZSHRC") — left it alone"
elif [ "$DRY" = 1 ]; then
  would "append the line above to $(tilde "$ZSHRC")"
elif ask_yes "Add it to ~/.zshrc now?"; then
  printf '\n# project-system aliases\n%s\n' "$FRAG_LINE" >> "$ZSHRC"
  act "appended to $(tilde "$ZSHRC")"
else
  info "skipped — add the line above to ~/.zshrc yourself when ready."
fi

# ----------------------------------------------------------------------
# 4. Opening a project → what to launch  (PROJECTS_OPEN_CMD)
# ----------------------------------------------------------------------
phase "Opening a project"

info "From the dashboard (run 'proj', then type a project's number), opening a"
info "project cd's into it and can launch a command. Default: Claude Code."

if grep -qsF "PROJECTS_OPEN_CMD" "$ZSHRC"; then
  act "PROJECTS_OPEN_CMD already set in $(tilde "$ZSHRC") — left it alone"
elif [ "$DRY" = 1 ]; then
  would "ask whether to launch Claude Code (or a custom command) on open, then export PROJECTS_OPEN_CMD in $(tilde "$ZSHRC")"
elif [ -t 0 ]; then
  printf "  ${C_BOLD}Launch Claude Code when you open a project?${C_RESET} [Y/n] ${C_DIM}— or type a command to run instead${C_RESET} "
  read -r reply || reply=""
  case "$reply" in
    [Nn]|[Nn][Oo])         open_cmd="" ;;
    ""|[Yy]|[Yy][Ee][Ss])  open_cmd="claude" ;;
    *)                     open_cmd="$reply" ;;
  esac
  printf '\n# project-system: command run when you open a project (empty = just cd + ls)\nexport PROJECTS_OPEN_CMD=%q\n' "$open_cmd" >> "$ZSHRC"
  if [ -z "$open_cmd" ]; then
    act "set PROJECTS_OPEN_CMD=\"\"  ${C_DIM}(open = cd + ls only)${C_RESET}"
  else
    act "set PROJECTS_OPEN_CMD=\"$open_cmd\"  in $(tilde "$ZSHRC")"
  fi
else
  info "non-interactive — leaving the default (Claude Code). Set PROJECTS_OPEN_CMD in ~/.zshrc to change."
fi

# ----------------------------------------------------------------------
# Done
# ----------------------------------------------------------------------
pause 0.2
if [ "$DRY" = 1 ]; then
  printf "\n  ${C_WARN}${C_BOLD}● DRY RUN COMPLETE${C_RESET} ${C_DIM}— nothing was changed.${C_RESET}\n"
  printf "  ${C_DIM}Re-run without --dry-run to actually install.${C_RESET}\n\n"
  exit 0
fi

# The celebration banner (A3K §4): the ending gets the banner — the motto
# settles to a static gradient inside the panel, which keeps the instructions.
phos4_celebrate_banner --caption "SUCCESSFULLY INSTALLED" "PROJECT" "SYSTEM"

printf "\n"
printf "  ${C_OK}┌─[ ready ]──────────────────────────────────────────${C_RESET}\n"
printf "  ${C_OK}│${C_RESET}\n"
printf "  ${C_OK}│${C_RESET}   reload your shell:   ${C_BOLD}exec zsh${C_RESET}\n"
printf "  ${C_OK}│${C_RESET}   then make something:  ${C_BOLD}newproject${C_RESET}\n"
printf "  ${C_OK}│${C_RESET}\n"
printf "  ${C_OK}│${C_RESET}   "; phos4_gradient_text "░▒▓ certified Y3K-compliant ▓▒░"; printf "\n"
printf "  ${C_OK}└────────────────────────────────────────────────────${C_RESET}\n"
printf "\n"
printf "  ${C_DIM}to undo later: unlink the project-system commands in${C_RESET}\n"
printf "  ${C_DIM}~/.claude/commands/, remove the source line from ~/.zshrc,${C_RESET}\n"
printf "  ${C_DIM}and rm -rf ~/project-system (and ~/Projects if you like).${C_RESET}\n\n"
