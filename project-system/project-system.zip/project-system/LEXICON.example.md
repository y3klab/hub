# Personal Lexicon

Your personal, cross-project canonical vocabulary — terms you reuse across many
projects, each with its official spelling and the wrong forms to correct.

> **This is the template, not your live list.** `LEXICON.md` (your actual
> vocabulary) is gitignored — it's personal config the repo *seeds*, not data the
> repo owns. On first run the system copies this file to `LEXICON.md` if you don't
> have one yet. Then make it yours: replace the placeholders below with the
> brands, acronyms, and coined terms you reuse across projects. Rule/format
> updates ship here via `git pull` and never touch your `LEXICON.md`.

Same format and role as a project's `GLOSSARY.md`, but **personal-scope**: it
holds vocabulary shared *across* projects (brands are the common case, plus
recurring acronyms, product/feature names, and coined terms used in more than one
project). Project-specific terms stay in that project's `GLOSSARY.md`.

`/setup-project` and `/grill` **pull** from here (seed a project's
`GLOSSARY.md` with any lexicon term that actually appears in the project) and
**promote** back to here (offer to add a newly-pinned cross-project term), so the
lexicon stays current.

**Entry format.** Each term is a bold header, a one-line gloss, an `_Avoid_:` line
of wrong forms, and an optional `_Visibility_:` line:

- `_Visibility_: public` — the term is safe to appear in anything you share or publish
  (the brand of a product you ship, say). Omit it and the term is treated as
  **private** by default — your clients, company, and personal-venture names, kept
  out of shared artifacts. The maintenance tooling uses this: the shareable-release
  guard scans a built release for every private (unmarked) term and fails if one
  leaks, so a newly-added client name is protected the moment you add it here —
  the only thing you ever tag is the rare *public* term.

## System vocabulary

Real terms, not placeholders — they ship with the system and are yours to keep.
They name the ideas the system itself is built on, so every project inherits
their canonical spelling from day one.

**Fractal Self-Describing Nodes** (FSDN):
The Project System's foundational structural law — every node (portfolio →
project → sub-tool → catalog entry) describes itself in a consistent shape at
every altitude; each node is self-contained yet points up to its index and down
to its children. *Every node is a fractal self.* Shorthands: **fractal selves**
(canonical in prose) / **FSDN** (written acronym) / "fractal nodes" (accepted
synonym — normalize to "fractal selves" in writing). Public-facing first use is
always the full term — the prose shorthands collide ("fractal node" is a
complex-network-science term); FSDN is fine once the full term has appeared.
Canonical definition: `CONVENTIONS.md` § Design principles.
_Avoid_: fsdn, F.S.D.N., Fractal Self Describing Nodes, self-describing nodes (incomplete — drops the fractal/scale property)
_Visibility_: public

## Language

**Acme**:
A company or brand you work with across multiple projects. Replace with your own.
_Avoid_: ACME, acme, Acme Corp

**Globex**:
Another recurring org or brand. Replace with your own.
_Avoid_: globex, GlobeX

**WidgetKit**:
An example recurring product/feature name you ship publicly. Replace with your own.
_Avoid_: Widgetkit, widget kit, widgetkit
_Visibility_: public
