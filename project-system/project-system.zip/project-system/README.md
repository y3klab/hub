# project-system

The system that manages `~/Projects/` — my project workspace.

> **Self-contained.** This repo provides the project-lifecycle system: scripts, slash commands, templates, conventions. It runs standalone — install it on its own, or alongside [`y3klab/dotfiles`](https://github.com/y3klab/dotfiles) (a separate, optional personal Claude Code env). See [`dotfiles/ARCHITECTURE.md`](https://github.com/y3klab/dotfiles/blob/main/ARCHITECTURE.md) for the broader layered design.

This repo holds:

- **`CONVENTIONS.md`** — principles behind the system
- **`AUTHORING.md`** — how the slash commands author per-project files (`CLAUDE.md` section menu, `GLOSSARY.md`, `DECISIONS.md`)
- **`CHANGES.md`** — dated design-history changelog (the *why* behind each convention)
- **`projects.example.md`** — the seed for `~/Projects/projects.md`, the workspace's own overview (there is no master project list: the workspace *is* the list)
- **`LEXICON.md`** — your personal cross-project vocabulary (gitignored; seeded from `LEXICON.example.md`)
- **`bin/`** — `newproject.sh` (scaffold a new project into `Active/`) + `importproject.sh` (bring an existing folder or git repo into `Active/` — the adoption on-ramp) + `moveproject.sh` (the dashboard mover for all transitions: deactivate / activate / archive / unarchive / delete) + `list-projects.sh` (the dashboard) plus utilities (`make-release.sh` — build a sanitized, shareable copy; `repo-visibility.sh` — robust repo-visibility check; `audit-backups.sh` — flag projects with no off-machine backup)
- **`test/`** — zero-dependency end-to-end tests: `workspace-test.sh` (a project through every state) and `adopter-test.sh` (the shareable-release path)
- **`claude/commands/`** — Claude Code slash commands (`/setup-project`, `/init-claude-md`, `/grill`, `/architect`)
- **`ARCHITECT-PATTERN.md`** — the dual-session design workflow (a `/grill` executor + an `/architect` advisor, with you routing between them)
- **`shell/zshrc-fragment.sh`** — shell aliases that wrap the bin scripts and inspect the workspace
- **`install.sh`** — symlinks the slash commands into `~/.claude/commands/`; tells you how to source the shell fragment
- **`Double-Click to Install.command`** + **`Installation-Instructions.txt`** — the zip's double-click installer (macOS) and a plain-text note
- **`INSTALL.md`** — the retro front-door install guide that ships in the release zip; **`SETUP.md`** — the fuller adopter reference + the two adoption paths

## Install

See **[`SETUP.md`](SETUP.md)** for the step-by-step generic install (clone → `install.sh` → shell line → workspace folders → `newproject`).

**Two ways to adopt:**

- **Just the methodology** *(most people)* → follow [`SETUP.md`](SETUP.md). project-system runs standalone; you keep your own shell config and git identity.
- **The author's full stack** → also adopting the personal Claude Code + shell env ([`y3klab/dotfiles`](https://github.com/y3klab/dotfiles)), personalized to you, is a separate path handled by the **project-system-wizard**. Wanting `dotfiles` is what routes you there instead of `SETUP.md`. See dotfiles' `ARCHITECTURE.md` for the broader layered design.

**Bringing your existing projects in.** Once installed, `importproject` (or the dashboard's `i` doorway) brings an existing folder or git repo into `~/Projects/Active/` as a managed project — copied or cloned in, pre-trusted, indexed, committed. It's non-destructive (a local folder's original is left untouched; a repo is cloned fresh) and quick by default, with the full `/setup-project` intake offered afterward — so adopting a pile of existing folders stays fast.

## What this isn't

This is the *system* — not the projects themselves. The actual project work lives in `~/Projects/Active/`, `~/Projects/Inactive/`, and `~/Projects/Archive/` — many of which are their own git repos with their own histories.

