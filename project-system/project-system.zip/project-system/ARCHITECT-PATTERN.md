# The Architect Pattern — dual-session design with grill + architect

A two-session workflow for high-stakes design decisions. One session **grills** (executor); a second **architects** (advisor). You route between them. The payoff: an independent, big-picture perspective that catches what a single heads-down session misses.

## The two roles

- **The grill** (`/grill`, run *in* the project) — the **executor**. Walks the decision tree, asks pointed questions, and **owns the writing**: records decisions in `DECISIONS.md`, pins terms in `GLOSSARY.md`, prunes `CLAUDE.md` Open Decisions, propagates to `PLAN.md` / `CHECKLIST.md`. Deep but narrow — anchored in its own tree.
- **The architect** (`/architect`) — the **advisor**. Holds the cross-cutting view, pressure-tests the grill's framing, catches contradictions and premature closure, and drafts your relays. **Read-only on the grilled project** — the grill owns the files, and two sessions editing one repo collide. (Exception: it may act on a *different* related repo whose changes the decisions trigger — e.g. the project's parent system.)
- **You** — the **router and the decider**. You carry questions/answers between the windows, inject real-world ground-truth only you have, and make the locked-open calls.

**The partner can be a plain executor, not just a grill.** This pattern is written around `/grill`, but it works just as well when the other window is an ordinary Claude session that's never heard of this workflow. Three things change: relays must be in *your own voice* (no "architect"/"grill"/"relay" jargon — it won't understand the labels), nothing is auto-recorded to `DECISIONS.md`/`GLOSSARY.md` (you carry the decision-memory between windows, and tell it explicitly what to commit), and the architect verifies a decision landed via **git/code** rather than the decision docs. `/architect` establishes which mode it's in up front.

## Why it works

1. **Independent context → independent judgment.** The architect isn't anchored in the grill's tree, so it can say "that reverses what we decided" or "this contradicts the arc." The value is the *difference* in vantage, not more of the same.
2. **Role asymmetry, not redundancy.** One executes and propagates; one advises and pressure-tests.
3. **You're not a dumb pipe.** The hardest calls need ground-truth only you have — and the architect pushes back on *you*, not just the grill. The locked-open decisions are locked-open precisely because they need a human.

## When to use it

For **high-stakes, cross-cutting, hard-to-reverse design** — exactly what a grill is for. **Not** routine execution: it's slower (relay overhead) and it *invites* over-deliberation. Match it to the stakes.

## How to run it (v1 — paste-based)

1. **Window 1 (grill):** `cd` into the project, launch Claude, run `/grill <topic>`.
2. **Window 2 (architect):** launch Claude *from inside the project folder* so `/architect` auto-detects it (or from anywhere and pick from the list), run `/architect`. It reads the project's decision records to orient.
3. **The relay loop:**
   - Grill asks a question → **paste it to the architect.**
   - Architect responds with reasoning + a paste-ready relay block → **paste the block back to the grill.**
   - Grill records the decision and propagates it to the docs.
   - The docs are the **shared state**: when a decision lands, the architect re-reads them to stay synced.

The grill writes; the architect advises; you decide. The same docs both sessions touch keep them in sync without talking directly.

## Reducing the friction (roadmap)

The paste step is friction — but it's also your **edit-gate** (you control what's relayed, and can tweak before sending). Three levels, increasing automation and *decreasing your control*:

- **v1 — paste (today).** Zero new moving parts; full control. The friction is mostly text-selection on the long architect relays.
- **v2 — channel file (planned).** Both sessions read/write one gitignored file (`<project>/.system/architect-channel.md`). The architect appends its relay there; you say "sync" in the grill window instead of pasting. Kills the clipboard friction and leaves a **persistent log of the whole architect↔grill dialogue**. Cost: you still trigger each sync (sessions can't auto-poll), and `/grill` must learn the channel protocol — a bigger build. Add it when paste-friction actually bites.
- **v3 — orchestrator (future).** One session owns both as sub-agents and auto-routes — removes you from the middle. But it **sacrifices the human-at-the-forks value** unless it pauses at every locked-open decision for you. Right for *low-stakes* runs; wrong for the high-stakes design this pattern exists for.

## The architect's charter (summary)

Full operating rules: `claude/commands/architect.md`. In short — **pressure-test** (the grill *and* you), **flag** cross-cutting consequences and contradictions, **catch** premature closure, **ground** advice in the actual code/state (don't opine from memory), **surface** tradeoffs + a recommendation but leave locked-open calls to you, stay **read-only** on the partner's project, and **establish the partner's mode up front** (grill vs plain executor — it changes the relay voice and what's recorded).
