# Decisions

_This is the project's single decision record. Record a choice when all three hold: **(1) hard to reverse**, **(2) surprising without context**, **(3) the result of a real trade-off**. If any is missing, usually skip it. Standard entry shape: `## YYYY-MM-DD: <title>` followed by Context / Options / Chose / Reasoning, plus an optional `Revisit:` / `Revisit if:` trigger._
