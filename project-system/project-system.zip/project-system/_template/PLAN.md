# Plan

_Phases of work, with concrete next actions per phase. Reference the project overview (`<project-name>.md`) once it exists, then derive phases from there._
