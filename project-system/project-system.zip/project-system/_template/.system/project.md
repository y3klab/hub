---
started: YYYY-MM-DD
state: fresh
# umbrella: <id>   # access identity — the ~/.gitconfig-<id> suffix; see AUTHORING.md
---

# Project Title

_Description pending — `/setup-project` drafts this from the title
and any dropped sources, then sharpens it in a Phase 0 grill._

---

_This file holds system metadata and the project's intro. The description
above is drafted by `/setup-project`, not asked at creation. The
project's `.gitignore` (written by `newproject`) excludes `.system/`, so
this file never enters the project's own git repo._
