# Project Index

Master list of all projects. Update when starting, finishing, or moving a project.

**See also**: `CONVENTIONS.md` (system principles) and `LEXICON.md` (personal cross-project vocabulary)

## Active

_(empty — projects you're engaged with land here)_

## Inactive

_(empty — dormant but alive: placeholders, paused builds, will-resume)_

## Archive

_(empty — finished/terminal work, date-stamped, lands here)_

---

**Conventions**

- Project folders use kebab-case: `my-project-name`
- Each project has a `.system/project.md` with frontmatter (started date). See `_template/.system/project.md`.
- README is opt-in per project (not in the default scaffold; create when going public).
