# AUTHORING.md — per-file authoring specs

The reference-grade *how to author* specs for the per-project files the slash
commands generate and re-sync. **`CONVENTIONS.md` carries the system's
principles; this file carries the file-level detail it used to hold inline** —
split out so the principles doc stays short and these specs keep one canonical
home (no drift between commands).

The slash commands cite this file: `/setup-project` (greenfield generation),
`/init-claude-md` (re-sync), and `/grill` (glossary/decisions reconciliation).
Keep each spec single-sourced here — don't re-inline it into a command.

## `GLOSSARY.md` — canonical project language

`GLOSSARY.md` pins a project's **canonical language**: the coined terms specific to *this* project, each with a tight definition. It exists to prevent vocabulary drift across the overview, `PLAN.md`, `DECISIONS.md`, `CLAUDE.md`, and the code — and to let you (and Claude) say "the materialization cascade" instead of re-explaining the concept every session.

- **Glossary-only, no implementation detail.** Not a spec, not a scratch pad, not a decision log. Define what a term *is*, not what it does. One or two sentences per term.
- **Only project-specific terms.** General programming concepts (timeouts, error types, utility patterns) don't belong even if the project leans on them. Test before adding: is this a concept unique to this project, or a general one? Only the former.
- **Be opinionated, and capture the wrong forms.** When several words exist for one concept, pick the canonical one and list the rest under `_Avoid_`. **`_Avoid_` holds every form that should be corrected *to* the term** — wrong casings, **common misspellings**, spacing errors, deprecated synonyms — so the glossary doubles as an autocorrect/consistency source, not just a definition list. (E.g. `**GitHub**` with `_Avoid_: Github, github, Git Hub` catches the human typos before they spread.)
- **A parseable source of truth.** The `**Term**:` / `_Avoid_:` line shape is deliberately simple and stable so other skills/tools can *consume* the glossary — e.g. a consistency-lint that scans prose/commits for any `_Avoid_` form and flags it with the canonical term. Treat the shape as an interface: don't reformat ad hoc, and keep `_Avoid_` comma-separated on one line per term so it stays machine-readable.
- **Seeded from the personal lexicon.** As an **early opening move of Phase 0**, `/setup-project` reads `~/project-system/LEXICON.md` (your cross-project vocabulary — see `CONVENTIONS.md` § "The personal lexicon") and seeds `GLOSSARY.md` with any lexicon term that actually appears in this project — title, dropped sources, or early conversation — copying the term's definition and `_Avoid_` line verbatim. Brands are the common case (e.g. an agency name → **ACME**, all-caps), so a project for that agency starts knowing how to write its own brand; this is the per-project data behind the global "brand fidelity" rule. The Phase 0 grill then *extends* it with the project's coined terms as they surface, and **promotes** new cross-project terms back to the lexicon.
- **Generated when there's something to pin.** When ≥1 lexicon term applies or any coined term surfaces, the project gets a seeded `GLOSSARY.md`; `/setup-project` adds any further terms the brief/sources yield. Only a genuinely term-less project skips it; a later `/grill` pass creates/extends it as terms resolve. No static `_template/GLOSSARY.md` stub — a blank glossary is noise.

Format:

```md
# <Project Title>

{1-2 sentence description of what this glossary is.}

## Language

**Term**:
One or two sentence definition — what it IS, not what it does.
_Avoid_: wrong-casing, common-misspelling, rejected-synonym
```

`GLOSSARY.md` is sharpened during a `/grill` pass (see `CONVENTIONS.md` § "Grilling a plan into the docs").

## `CLAUDE.md` — the section menu

`CLAUDE.md` is the per-project Claude Code config — the terse, always-loaded layer over the fuller reference docs (the overview, `PLAN.md`, `DECISIONS.md`, `GLOSSARY.md`). Two slash commands build it from **this one menu**: `/setup-project` (greenfield generation, during intake) and `/init-claude-md` (re-syncing a `CLAUDE.md` that drifted from an evolved project). Each command carries only its **own framing** — setup's per-entry interview, init's diff-against-reality — and defers here for *what each section is and how to author it*. **Read this section before generating or updating a `CLAUDE.md`.** Keep it the single source; don't re-inline the section list into either command.

Two cross-cutting rules:

- **No "Working Agreement" section.** Don't generate a separate quick-reference summary of the behavioral rules — it duplicates Conventions/Don't and drifts from them as those evolve. Instead, **lead the Conventions and Don't sections with their most load-bearing entries** so the critical ones are seen first. One home per rule; no summary layer to keep in sync.
- **Length follows substance.** A substantive project (game, web app, ML pipeline) easily reaches 20-50 lines of real content; a thin pure-docs project, 5-10 lines. Don't pad; don't under-fill. **No `<placeholder>` text anywhere** — a section either has real content or is omitted.

The sections, in order — each included only when it has real content for *this* project:

- **Status** (right after the title): brief operating mode + what blocks progress. Include when project mode shapes how Claude should operate. Examples: *"Pre-decision — no code yet; foundational choices are open"* / *"Scaffolding — stack chosen, building out structure"* / *"In progress — feature work on `<area>`"* / *"Maintenance only — no new features planned"*. Cross-reference an `Open Decisions` section if one exists. **This is a human/`/grill`-maintained narrative — *not* the dashboard's status chip.** The dashboard reads a separate, **local** `.system/status` cache that `/project-status` (and the `proj` view's `s` key) re-judge independently; that refresh is purely local and never touches `CLAUDE.md`. See `CONVENTIONS.md` § "`.system/project.md`".
- **Project** (always): one sentence derived from the brief/overview. On a re-sync this is usually already correct — update only if scope or intent shifted.
- **Identifiers** (optional, immediately after Project — include only when concrete facts exist): a compact key/value block of the cold-start essentials a future Claude would otherwise grep for. Candidates: repo URL, primary deployed URL, account/org name, infra IDs (cloud project, region), key external IDs. **Only list facts that exist** — no `<placeholder>` rows. Skip the whole section for early-stage projects with nothing concrete yet. An evolved project is exactly when these accrue, so a re-sync should add the block once the facts exist. Don't list URLs that expose sensitive surface as navigational aids — anything here lands in every Claude session's context.
- **Open Decisions** (optional, high-impact): include when the project has 2+ gating decisions whose answers govern Stack, Structure, or Conventions. **Tag each entry with its target phase** (`(Phase 1)`, `(Phase 2)`) — pull phase from PLAN.md — so a reader of CLAUDE.md alone knows when each needs resolving. **State the actual open question, not the broader topic** — "Which income categories apply" beats "Filing complexity." Close the section with: *"Treat each as locked-open: don't commit to a choice without explicit user confirmation."*
  - **Meaning of `locked-open`:** the decision is held open *by design*. Claude must NOT close it via inference, "propose with reasoning, proceed by default," or any other usual mechanism. **Only explicit user confirmation closes it** — a deliberate override of the slash-command default for foundational decisions where guessing wrong is expensive.
  - **Style:** lowercase, hyphenated — `locked-open`. Match this form everywhere it appears in CLAUDE.md.
  - **Effect:** Stack and Structure can reference this section instead of repeating *"TBD"* inline.
- **Stack** — **No limbo.** Every item resolves to one of three states:
  - **Committed** → list it plainly. Major committed decisions should also have a DECISIONS.md entry.
  - **Default-yes carried forward from a related project** → list as `<item> (carried from <project>, revisit if X)` AND add a DECISIONS.md entry capturing the default-yes choice.
  - **Genuinely open** → don't put it in Stack at all; it belongs in Open Decisions.

  Avoid *"proposed"* / *"TBD"* without a resolution path — that's limbo, and it hides actual unknowns. For a "web app game", this section should at minimum identify language, runtime, build tool — or note their absence in Open Decisions.
- **Structure** (include when project shape implies one) — two modes:
  - **Project has project-specific dirs** (`src/`, `packages/sim/`, `templates/`, anything promoted at intake) → sketch the project-specific structure. **Do not auto-list** `<project-name>.md` / `PLAN.md` / `DECISIONS.md` / `CHECKLIST.md` / `GLOSSARY.md` / `CLAUDE.md` — guaranteed bookkeeping. **`references/` is bookkeeping when empty or holding only source-material** — skip it unless substantial source archives have accumulated worth pointing future-Claude at.
  - **Project has no project-specific dirs yet** (early-stage docs/process projects) → list the actual file inventory *including* bookkeeping, to spare future-Claude an `ls`. Drop bookkeeping from Structure once project-specific dirs emerge.
  - **Name anticipated dirs, don't materialize them.** Mark anticipated-but-not-yet-created dirs as *anticipated*; the CLAUDE.md naming is the contract. **Do not** create the empty folder or a `.gitkeep` on disk — the directory appears only when there's real content. Empty placeholders create false positives and filesystem noise.
  - **`README.md` is opt-in** (not shipped by `newproject`): list it in Structure if it exists; never suggest creating one.
- **Router table** (optional, after Structure — include when 3+ supporting docs are worth navigating to): a two-column `I need to… | Read this` table that turns CLAUDE.md into a dispatcher. Shape:

  ```
  | I need to… | Read this |
  |---|---|
  | <user-intent trigger phrase, 5-15 words> | <path/to/doc.md> — <one sentence of orientation> |
  ```

  An evolved project is exactly when enough docs exist to warrant one, so a re-sync should add it once the project crosses 3+ docs. **Cell-scope discipline:** the left column is the user's intent; the right is path + one sentence. **Don't pack the destination doc's summary into the cell** — if a parenthetical lists data shapes, schema names, or ship-dates, the router is becoming a second TOC. The destination doc carries the detail; the router only points.
- **Commands** — only if real commands exist (Dev / Build / Typecheck / Test / Lint with actual command strings). Don't propose placeholder commands.
- **Conventions** — include conventions derivable from project type, ecosystem norms, related projects, or expert patterns from the references — not only from brief/overview specifics (a real-time multiplayer game implies "deterministic simulation"; a Python ML project implies "type hints on public API"). **Propose each candidate one at a time before writing**, with one sentence of reasoning — never batch-write. (`/setup-project` runs a fixed `[1] confirm [2] change [3] reject` per-entry protocol for its greenfield interview; see its Step 6.) When drafting an entry, watch for these patterns:
  - **References a file by name → specify (a) where it lives and (b) what an entry looks like** (a skeleton). Both drift fast otherwise.
  - **Capture-style rules → also state what NOT to capture.** Pair `Capture: X, Y, Z` with `Don't capture: A, B`, or you get bloated journals of trivia.
  - **Scope depends on an open decision → flag the dependency inline.** Example: *"If we choose lockstep multiplayer, requirements tighten — revisit when that decision lands."*
  - **Originates from a real incident → include the date and what happened, inline.** A dated `Why:` line gives the rule temporal authority and resists future "still needed?" deletion. Ecosystem-inferred rules don't need this anchor; rules drawn from real failures do.
  - **Names a specific calling pattern → include the 2-5 line snippet, not just prose.** A rule that says *"always pass the database ID to `getFirestore()`"* carries the corrected call site embedded in the rule body.
  - **One rule = one failure mode.** If a rule grows a "follow-on" addendum covering a *different* wrong-path, split it into a new entry.
  - **Just restates a global rule → don't write it.** A rule like "render tool/brand names with their official spelling" merely echoes the global brand-fidelity rule in `~/.claude/CLAUDE.md`. More: the canonical spellings themselves are **vocabulary, not behavior** — third-party tool/product/brand names that are the project's subject matter belong in **`GLOSSARY.md`** with an `_Avoid_` line (e.g. `GitHub` — _Avoid_: Github, github), not as a Convention. A Convention names a **project-specific failure mode**, never a universal one.
- **Don't** — include don'ts from project shape (genre conventions, ecosystem norms, related-project history) when they'd plausibly help. Mark uncertain ones as *tentative*. **Same authoring discipline as Conventions** (incident-anchored `Why:`, embedded snippet for calling-pattern rules, one failure mode per entry — split a Don't that grows a follow-on), and **proposed one at a time** the same way.
  - **Name failure modes the user can actually commit** — using the wrong tool, skipping a step, hand-editing a wrong file — not self-policing of code that already enforces. *"Don't run `cp`/`rsync` manually to deploy — always use `deploy.sh`, which has the SD-card sanity check"* (strong) beats *"Don't bypass `deploy.sh`'s SD-card check"* (weak — the script already enforces it; the only bypass is modifying the script). If a candidate reduces to "don't undo the code that already enforces," skip or rephrase it.
  - **A Don't is a firm constraint, not a conditional.** If a related decision is open, the Don't states the constraint unconditionally and the Open Decision determines the compliance method. Good: *"Don't commit ELRS bind phrases. Verify `models/*.yml` before staging. How to comply (scrub / store-separately / accept-if-private) is the Phase 2 Open Decision."* Bad: *"Don't commit ELRS bind phrases (locked-open: see Open Decisions)."* The Don't doesn't qualify itself; it points at where the compliance choice lives.
- **Related projects** (optional): if a related project exists at `~/Projects/Active/<name>/` or `~/Projects/Archive/<name>/`, include a one-line pointer with what's relevant (shared canon, source-of-truth conventions, prior art).
- **Claude Code tooling** (optional, skip if N/A): if project-relevant slash commands or skills exist (custom commands at `~/.claude/commands/`, project-local skills, MCP servers Claude should reach for first), name them so future-Claude doesn't rediscover or ignore them. Skip the section entirely when nothing applies — don't pad.

## `DECISIONS.md` — the bar for what merits an entry

`DECISIONS.md` is this system's single decision record, in the existing Context / Options / Chose / Reasoning (+ `Revisit:` / `Revisit if:`) format. There is no separate decision-record file or folder — every recorded decision lives here.

The bar for **what merits an entry**: record a decision when all three hold:

1. **Hard to reverse** — the cost of changing your mind later is meaningful.
2. **Surprising without context** — a future reader will wonder "why did they do it this way?"
3. **The result of a real trade-off** — there were genuine alternatives and you picked one for specific reasons.

If any of the three is missing, it's usually not worth an entry — it'll either get reversed cheaply, or nobody will wonder why, or there was no real alternative to record. This bar is tighter than "meaningful choices" and cuts noise from the log. (The project-type/scope decision at creation is the standing exception — `/setup-project` always records that one.)


## `.system/project.md` format

```yaml
---
started: 2026-05-16
state: fresh
---
```

The **`state:` marker** tells `/setup-project` which mode to run:

- **`state: fresh`** — `newproject` writes this on a brand-new scaffold (the docs are `_template/` stubs). `/setup-project` runs **greenfield** (generates over the stubs), then advances it to `state: active` at closeout. So a *re-run* on an already-set-up project flips to adopt mode and can't clobber.
- **absent · `state: active` · real existing content** — the project already exists; `/setup-project` runs **adopt mode** (fills only what's missing, never overwrites). A bare `importproject` adoption writes no `.system/`, so *absent ⇒ adopt*.

For projects that are agents/skills, optionally add:

```yaml
type: agent
```

This lets you find all agents with `grep -rl "type: agent" ~/Projects/`.

To declare a project **intentionally local** — no off-machine backup wanted — add:

```yaml
backup: local
```

`bin/audit-backups.sh` reads this and acknowledges the project instead of flagging it as having no remote. The key's presence is the opt-out; any value works (e.g. `backup: icloud` if it's covered some other way). Omit it for normal projects — their expected state is "has a pushed remote," which is what the audit checks for.

To declare which **umbrella** (access identity) a project belongs to — and so which git author its commits carry — add:

```yaml
umbrella: acme
```

The value is the **suffix of the matching `~/.gitconfig-<value>` identity file** (e.g. `acme` → `~/.gitconfig-acme`), not a friendly label — it's what the no-remote include resolves against. The valid ids are exactly the ones named by the `hasconfig:remote.*.url` rules in `~/.gitconfig.local`; the human name (e.g. "Acme Corp") lives in the global `CLAUDE.md` identity map. It drives commit-author identity:

- **Repos with a remote** route automatically by the remote's SSH alias (`hasconfig` rules), so here the field is documentation matching what the remote already enforces — no include is written.
- **No-remote repos** carry a repo-local `[include] path = ~/.gitconfig-<umbrella>` — indirection, not a copied-in email, so an umbrella's identity changes in one place. The include is written at `git init` (before the first commit) and dropped when a remote is connected. `setup-project` owns this: Step 8 writes it; Step 9 drops it on remote-connect; adopt mode backfills it for an existing no-remote repo. `newproject` never inits a repo — pass `--umbrella <id>` to record the field for `setup-project` to consume.
- With `user.useConfigOnly = true`, a repo matching no rule **refuses to commit** rather than guessing.

A no-remote repo that later gains a remote *by hand* keeps its include, which shadows the alias; `audit-backups.sh` flags that. Single-identity users can omit the field — one global git author covers everything.

