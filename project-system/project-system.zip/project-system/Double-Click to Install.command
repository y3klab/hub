#!/bin/bash
#
# Double-Click to Install.command — the easy installer.
#
# Double-click this file in Finder. Terminal opens and it:
#   1. moves project-system into ~/project-system (where the system lives)
#   2. runs the installer
#   3. drops you into a fresh shell with the commands ready
#
# If macOS blocks it ("unidentified developer" / "cannot be opened"):
#   right-click this file → Open → Open.  You only do that once — macOS
#   just wants you to confirm you trust a script you downloaded.

set -e

SRC="$(cd "$(dirname "$0")" && pwd)"
DEST="$HOME/project-system"

# Move into place if we're being run from somewhere else (e.g. ~/Downloads).
if [ "$SRC" != "$DEST" ]; then
  if [ -e "$DEST" ]; then
    printf '\n  ~/project-system already exists — leaving it untouched.\n'
    printf '  To re-run the installer on it:\n      %s/install.sh\n\n' "$DEST"
    printf '  Press any key to close…'
    read -rsn1 _ || true
    echo
    exit 0
  fi
  printf '\n  Setting up project-system at ~/project-system …\n'
  cp -R "$SRC" "$DEST"
fi

# Run the (transparent, animated) installer.
"$DEST/install.sh"

# Leave the window in a usable login shell so the aliases are live right away.
printf '\n  The commands are ready in this window. Try:  newproject\n\n'
exec "${SHELL:-/bin/zsh}" -l
