# BRAND.md — project-system local rendering guide

> The Y3K look is now specified as **A3K** (the design language) in the `y3k-brand`
> project's `IDENTITY.md`; the engine is **Phos4**. This file keeps only
> project-system's local rendering guide.

How the dashboard and lifecycle tools render their on-brand chrome: where the
local code lives, the UX copy to keep consistent, and the steps to make a new
screen match. The look itself (palette, wordmarks, gradients, animation) is A3K;
surfaces *speak* A3K and are *rendered/themed* with Phos4. Link, don't copy —
read the function named here, not a duplicated value.

---

## 1. Reusable primitives — where the code lives

Link, don't copy. If you need a piece of chrome, source it; don't reimplement it.

- **`bin/_ui.sh`** — the shared toolkit, sourced by every lifecycle script:
  `header_brand`, `print_rule`, `print_header`, `choose` (arrow-key picker),
  `confirm`, `ui_input`, `spin`, `step_ok/warn/err/info`, `panel`, `celebrate`.
  Owns the `S_*` palette vars and the `PS_MONO` greyscale switch.
- **`bin/list-projects.sh`** — the dashboard renderer: `gradient_text`,
  `render_banner` (`PS_BANNER`), `_animate_banner` (`PS_ANIMATE`), and the
  section/header/chip colour logic.
- **`install.sh`** — sources the vendored `bin/phos4.sh` directly (it runs from
  the cloned repo, so the engine is present pre-install) and keeps its own
  `banner_shimmer` (the opening wordmark entrance). The ending is
  `phos4_celebrate_banner --caption "SUCCESSFULLY INSTALLED" "PROJECT" "SYSTEM"`
  — the **A3K celebration banner** (giant ANSI-Shadow letters, vertical ramp
  sweep, row power-on; canonical implementation in Phos4's engine, spec in
  y3k-brand `IDENTITY.md` §4), then the ready panel whose motto line is a static
  `phos4_gradient_text` (the old animated `shimmer` sign-off retired — the
  banner owns the ending's motion now).

---

## 2. Voice / copy

The words are part of the brand too. Keep them consistent.

- **Lifecycle vocabulary:** **deactivate / activate · archive / unarchive**; the
  top-level framing for all transitions is **"move or delete."**
- **Reassurance copy (import)** — non-destructive, stated plainly: *"a local
  folder's original is never moved, modified, or deleted — a git URL is cloned
  fresh, nothing pushed — and the copy is brought in exactly as-is."*
- **Legend phrasing:** bright keycap *verbs* up top (open, move); muted doorways
  *below* (new, import, view archive). The visual weight matches the sentence order.
  The interactive `--select` picker keeps the same scheme in its footer: each key
  is a coloured keycap pill with a dim verb beside it — bright purple for actions
  (`↑/↓ enter m jump q`; the jump pill's keycap is the live number range, e.g.
  `1-22` — real data that advertises multi-digit entry by itself), warm magenta
  for the warm doorways (`n`/`i` → Active), grey
  for `a` (→ Archive) and for `r` (refresh stale — a subordinate meta/maintenance
  key). In the cold vault (`PS_MONO`) the pills go greyscale.

---

## 3. Make a new screen on-brand — the local steps

A recipe for the local chrome. The look itself follows A3K (see the `y3k-brand`
project's `IDENTITY.md`); these are the project-system mechanics:

1. **Source `_ui.sh`.** `source "$(dirname "$0")/_ui.sh"`. You now have the palette,
   the pickers (`choose` / `confirm` / `ui_input`), the status lines, `panel`, and
   `celebrate`. Don't hand-roll what's already there.
2. **Open with `header_brand "title" "subtitle"`** — the accent `◆` + bold title +
   trailing rule. Every tool starts this way.
3. **If it's a distinct mode,** set `PS_MONO=1` and clear the screen on entry/exit —
   greyscale signals a focused tool (the mover and the Archive view do this), not
   "colour turned off."
4. **Match the voice (§2):** lifecycle verbs (deactivate/activate, archive/
   unarchive), the "move or delete" framing, non-destructive reassurance where a
   user might fear data loss.
5. **Close on-brand:** `panel` for a completion summary, `celebrate "✦ … ✦"` for a
   one-line shimmer sign-off — or, for a *big* finish (an install, a major
   completion), `phos4_celebrate_banner --caption "…" WORD…` (A3K §4: endings get
   the banner; openings get the compact header).
6. **Verify the fallback.** Run it piped (`yourtool | cat`) and confirm it emits
   clean plain text — no escapes, no sleeps, no hangs. If the smoke test drives it,
   this is mandatory.
