# CLAUDE.md — project-system maintenance

**Status**: Project-lifecycle system. Standalone. Maintenance mode.

## What this repo is

A self-contained system for managing a personal project portfolio. Owns:

- **`bin/`** — `newproject.sh` (scaffolds a *new* project into `Active/` from `_template`; **interactive** with no args, or **headless** when any flag is present — `--title` / `--folder` / `--brief` / `--source` — so another Claude session can create a project via Bash. Headless scaffolds + stages the brief but **defers** setup: it prints the `/setup-project` offer and a final `PROJECT_DIR=<path>` line, never launching the interactive grill) and `importproject.sh` (brings an *existing* folder or git repo into `Active/` — copy/clone + pre-trust + INDEX + commit, then offers `/setup-project`; the adoption on-ramp). These two are the standalone create-into-Active commands (aliases `newproject` / `importproject`, dashboard doorways `n` / `i`). Plus `moveproject.sh` (the dashboard-launched, state-aware front door to *all* transitions — deactivate / activate / archive / unarchive / delete — reached only via the `m` action in the `proj` view, no standalone alias; drives the shared `_lifecycle.sh` engine directly) and utilities: `list-projects.sh` (renders the dashboard), `make-release.sh` (build a sanitized, shareable copy), `repo-visibility.sh` (robust `private`/`public`/`unknown` detection, multi-account `gh`-aware), and `audit-backups.sh` (flag workspace projects with no off-machine git remote; read-only). Shared helpers `_lifecycle.sh` (trust/INDEX/commit/move/delete) + `_ui.sh` (prompts, spinners, panels) are sourced by the above, never run directly
- **`test/`** — zero-dependency end-to-end tests. `smoke.sh`: the lifecycle (sandboxed temp `$HOME` + bare git remote, runs newproject then drives the mover through deactivate→activate→archive→unarchive→archive→delete, then exercises importproject on a local folder + a git URL; asserts INDEX/folder/overview/trust/commit). `adopter-install.sh`: the shareable-release path (builds a release, installs it into a throwaway `$HOME` per `SETUP.md`, asserts no personal data leaks + commands wire up + `newproject` works). Run both before shipping changes to `bin/` or `make-release.sh`
- **`_template/`** — the skeleton copied into every new project
- **`claude/commands/`** — Claude Code slash commands: `setup-project.md`, `init-claude-md.md`, `grill.md`, `architect.md`, `project-status.md` (re-judges a project's status and caches the chip the dashboard shows — paired with `list-projects.sh`, which reads `.system/status`)
- **`shell/zshrc-fragment.sh`** — shell aliases that wrap the lifecycle scripts and inspect the workspace
- **`CONVENTIONS.md`** — the system's principles (the ~200-line constitution; reference-grade file-authoring detail lives in `AUTHORING.md`, the changelog in `CHANGES.md`)
- **`AUTHORING.md`** — per-file authoring specs the slash commands cite: how to author `CLAUDE.md` (the section menu), `GLOSSARY.md`, `DECISIONS.md`, and the `.system/project.md` format
- **`CHANGES.md`** — the dated design-history changelog (the *why* behind each convention change; excluded from `make-release` shared copies)
- **`BRAND.md`** — project-system's **local rendering guide** (the residue after the visual identity moved out). Keeps only what's local to this repo: where the rendering code lives (`bin/_ui.sh`, `bin/list-projects.sh`, `install.sh`), the lifecycle/import/legend UX copy, and the concrete steps to make a new screen on-brand (source `_ui.sh`, `header_brand`, `PS_MONO`, `panel`/`celebrate`, the piped-output smoke-test fallback). The look itself is now **A3K** — the Y3K design language — specified in the `y3k-lab` project's `IDENTITY.md`; the engine is **Phos4** (which owns the former engineering gotchas, in-situ in `phos4/src/engine.sh`). Ships in releases as-is (`make-release` strips personal files structurally, no token-scrubbing)
- **`INDEX.md`** — master project catalogue (the lifecycle scripts maintain it)
- **`LEXICON.md`** — personal cross-project vocabulary (gitignored; seeded from tracked `LEXICON.example.md`). The personal-scope sibling of a project's `GLOSSARY.md`; `/setup-project` and `/grill` pull terms from it and promote new ones back
- **`install.sh`** — the full local setup, transparent by design: checks prereqs (git → `xcode-select`, Claude Code, zsh), symlinks the slash commands, seeds `LEXICON.md`, creates the `~/Projects` workspace, and offers to wire `~/.zshrc`. Announces every path it touches; `--dry-run` previews without writing; retro animated UI, TTY-gated so it's non-blocking when piped
- **`Double-Click to Install.command`** + **`Installation-Instructions.txt`** — the zip's friendly front door: a double-clickable macOS bootstrap (relocates to `~/project-system`, runs `install.sh`, drops into a ready shell) and a plain-text note (double-click + the Gatekeeper right-click→Open tip)
- **`INSTALL.md`** — the friendly, retro-styled front-door install guide that ships in the release zip (the manual/terminal path)
- **`SETUP.md`** — the generic (Path-1) adopter install guide + the two-path adoption framing (the detailed reference behind `INSTALL.md`)
- **`ARCHITECT-PATTERN.md`** — the dual-session design workflow (`/grill` executor + `/architect` advisor)

The workspace it operates on is `~/Projects/{Active,Inactive,Archive}/` — a folder structure on disk, not a repo. See `CONVENTIONS.md` § "The three folders" for what each one means and the tests for deciding where something belongs.

## Optional integration with dotfiles

The companion repo `y3klab/dotfiles` is a personal Claude Code env. It's **independent** — install it or skip it. If both are installed at the conventional paths:
- dotfiles' `zsh/zshrc` ends with a conditional `source` of `~/project-system/shell/zshrc-fragment.sh`, so the shell aliases activate automatically.
- The slash commands in `claude/commands/` here are symlinked into `~/.claude/commands/` by *this* repo's `install.sh` (not dotfiles').

If you skip dotfiles, project-system still works — you just need to add one line to your `~/.zshrc` to source the shell fragment (`install.sh` prints the line for you on first run).

## Read these first (in order)

1. **`CONVENTIONS.md`** — the principles. For *why* a convention exists, read `CHANGES.md` (the dated design-history log); for how to author a per-project file, `AUTHORING.md`.
2. **`README.md`** — bootstrap on a new machine.
3. **`LEXICON.example.md`** — the cross-project vocabulary model (your live `LEXICON.md` is gitignored).
4. **`bin/newproject.sh`** — reading it teaches you how the system actually operates.

## Operating rules

- **System changes affect every project.** Be deliberate. Pair behaviour-affecting changes with a corresponding update to `CONVENTIONS.md` (the principle) and a dated entry in `CHANGES.md` (the *why*).
- **Lifecycle operations auto-commit + push their own `INDEX.md` updates.** Don't manually commit `INDEX.md` changes that came from running `newproject` or the mover (`moveproject`: deactivate / activate / archive / unarchive / delete) — they handle that. Manual `INDEX.md` edits (rare) do need manual commits.
- **Slash commands and scripts are paired.** `bin/newproject.sh` stages files; `claude/commands/setup-project.md` reads them. When you change one, check the other.
- **Shell aliases live in `shell/zshrc-fragment.sh`.** When you add a new script to `bin/`, decide whether it needs a corresponding alias and add one to the fragment.
- **`CHANGES.md` is load-bearing.** Every meaningful convention change gets a dated entry. Future maintainers rely on it to understand *why* a rule exists.
- **`_template/` is the canonical scaffold.** Don't add files there without confirming they belong in every new project. The current `_template/` is deliberately minimal; resist accumulation.

## Where the deep history lives

The full design history (decisions, friction logs, the multi-iteration buildout) is at `~/Projects/Archive/2026-claude-md-setup/` (specifically `DECISIONS.md` — 37 KB of reasoning). Open that archive when you need to know *why* a pattern exists and the live docs don't say.

## Don't

- **Don't break the contract that `INDEX.md` lists every active project.** The lifecycle scripts maintain it; manual breakage will cause `list-projects` (the `proj` / `list projects` view) and other tooling to lie.
- **Don't add a project-specific CLAUDE.md here.** This repo IS the system. CLAUDE.md files for individual projects live in `~/Projects/Active/<project>/`. The one you're reading is maintenance context for the system itself — different role.
- **Don't commit `.system/` directories from individual projects** — `newproject` writes a per-project `.gitignore` that excludes `.system/` at creation time. For projects that predate this, add `.system/` to the project's `.gitignore` manually.
- **Don't push project-system content into dotfiles.** The two repos are intentionally independent; coupling content from one into the other defeats the point.
