# CLAUDE.md — project-system maintenance

**Status**: Project-lifecycle system. Standalone. Maintenance mode.

## What this repo is

A self-contained system for managing a personal project portfolio. Owns:

- **`bin/`** — the scripts. Twelve files; the two leading-underscore ones are libraries, sourced and never run directly.
  - **`newproject.sh`** — **registers** a *new* project into `Active/`: title + one-line description + optional sources, then the floor (`.gitignore`, `.system/project.md`, a minimal `CLAUDE.md`) plus the `~/.claude.json` pre-trust. The folder is the record - it is on the dashboard the moment it exists. **Interactive** with no args; **headless** when any flag is present (`--title` / `--description` / `--folder` / `--brief` / `--source` / `--umbrella`). Both end by *offering* `/setup-project`, defaulting to no; headless never launches it, printing the offer and a final `PROJECT_DIR=<path>` line instead. A project must be described by a one-liner, a brief, or dropped material — the empty-handed case is refused.
  - **`importproject.sh`** — brings an *existing* project into `Active/`: clone a git URL, move a folder out of a scratch location, or copy one from anywhere else. A source **already in the workspace is refused** - the dashboard lists the workspace, so it is already visible and there is nothing to register (the old `register in place` mode was deleted 2026-08-21). Never writes inside the folder. **Interactive** with no args, or **headless** with `--source <path|url>` (+ optional `--folder`), which defers setup and prints `PROJECT_DIR=<path>` last — the path the calling session reads back. Headless never moves, only copies. Both endings *offer* `/setup-project`, defaulting to no.
  - **`moveproject.sh`** — the dashboard-launched, state-aware front door to *all* transitions (deactivate / activate / archive / unarchive / delete). Reached only via `m` in the `proj` view; no standalone alias.
  - **`list-projects.sh`** — renders the dashboard from the workspace on disk: every folder in `Active/`, `Inactive/`, `Archive/` is a project, so nothing can be missing from it. `--stale` is narrower on purpose - it lists only *registered* projects (those with a `.system/project.md`), because the `r` refresh writes into what it judges and an unregistered folder has no `.gitignore` excluding `.system/`. Also serves `--paths`, `--banner`, `--select`.
  - **`audit-backups.sh`** — read-only sweep flagging projects with no off-machine git remote. A registered-only project has no repo yet and will show as `not-a-repo`; `backup: local` in `.system/project.md` acknowledges a deliberate one.
  - **`make-release.sh`** — builds the sanitized, shareable zip. Protection is **structural** (exclude personal files) with a refuse-to-emit leak gate behind it. Re-vendors `phos4.sh` from the Phos4 engine when that repo is present.
  - **`repo-visibility.sh`** — robust `private` / `public` / `unknown` detection, multi-account `gh`-aware.
  - **`skills-catalog.sh`** — regenerates `skills-catalog.md` from the filesystem. Owner labels come from the gitignored `identity-map.local` (see `identity-map.example`); with no map it falls back to the remote's own org.
  - **`phos4.sh`** — the vendored Phos4 terminal-UI engine. **A build artifact: do not edit it here.** Its source is the `phos4` project; `make-release.sh` re-vendors it.
  - **`_registry.sh`** *(library)* — the project registry. The folder in the workspace **is** the record; the only thing kept beside it is the `~/.claude.json` trust entry. Also holds `_reg_slug` (the one folder-name derivation), `_reg_drag_path` (the one reader of a Finder-dragged path), `_reg_is_scratch` (the move-vs-copy rule) and `registry_write_project_files` (the one writer of the floor).
  - **`_ui.sh`** *(library)* — prompts, spinners, panels; a thin adapter over `phos4.sh`.
  - **`_leakscan.sh`** *(library)* — derives the private-term denylist from `LEXICON.md`; shared by `make-release.sh` and the adopter test so the two can't drift.
- **`test/`** — zero-dependency end-to-end tests. `workspace-test.sh`: drives a project through every state (sandboxed temp `$HOME` + bare git remote, runs newproject then drives the mover through deactivate→activate→archive→unarchive→archive→delete, then exercises importproject on a local folder + a git URL; asserts dashboard/folder/overview/trust, and that an unregistered folder is visible but never written to). `adopter-test.sh`: the shareable-release path (builds a release, installs it into a throwaway `$HOME` per `SETUP.md`, asserts no personal data leaks + commands wire up + `newproject` works). Run both before shipping changes to `bin/` or `make-release.sh`
- **`claude/commands/`** — Claude Code slash commands: `setup-project.md`, `init-claude-md.md`, `grill.md`, `architect.md`, `project-status.md` (re-judges a project's status and caches the chip the dashboard shows — paired with `list-projects.sh`, which reads `.system/status`)
- **`shell/zshrc-fragment.sh`** — shell aliases that wrap the bin/ scripts and inspect the workspace
- **`CONVENTIONS.md`** — the system's principles (the ~200-line constitution; reference-grade file-authoring detail lives in `AUTHORING.md`, the changelog in `CHANGES.md`)
- **`AUTHORING.md`** — per-file authoring specs the slash commands cite: how to author `CLAUDE.md` (the section menu), `GLOSSARY.md`, `DECISIONS.md`, and the `.system/project.md` format
- **`CHANGES.md`** — the dated design-history changelog (the *why* behind each convention change; excluded from `make-release` shared copies)
- **`BRAND.md`** — project-system's **local rendering guide** (the residue after the visual identity moved out). Keeps only what's local to this repo: where the rendering code lives (`bin/_ui.sh`, `bin/list-projects.sh`, `install.sh`), the lifecycle/import/legend UX copy, and the concrete steps to make a new screen on-brand (source `_ui.sh`, `header_brand`, `PS_MONO`, `panel`/`celebrate`, the piped-output smoke-test fallback). The look itself is now **A3K** — the Y3K design language — specified in the `y3k-brand` project's `IDENTITY.md`; the engine is **Phos4** (which owns the former engineering gotchas, in-situ in `phos4/src/engine.sh`). Ships in releases as-is (`make-release` strips personal files structurally, no token-scrubbing)
- **`SKILLS.md`** — where Claude Code skills & agents live (global vs single-project, the dotfiles-symlink pattern) and the rules behind the generated `skills-catalog.md`
- **`audits/`** — dated findings docs from one-off sweeps (`<slug>-<date>/<slug>-<date>.md`, per the node law). Private design history like `CHANGES.md`; excluded from `make-release`
- **`projects.example.md`** — the seed for `~/Projects/projects.md`, the workspace's own overview. `install.sh` copies it once and never overwrites it. It names the three tiers, points at `CONVENTIONS.md` for what they mean, and lists no projects
- **`LEXICON.md`** — personal cross-project vocabulary (gitignored; seeded from tracked `LEXICON.example.md`). The personal-scope sibling of a project's `GLOSSARY.md`; `/setup-project` and `/grill` pull terms from it and promote new ones back
- **`install.sh`** — the full local setup, transparent by design: checks prereqs (git → `xcode-select`, Claude Code, zsh), symlinks the slash commands, seeds `LEXICON.md`, creates the `~/Projects` workspace, and offers to wire `~/.zshrc`. Announces every path it touches; `--dry-run` previews without writing; retro animated UI, TTY-gated so it's non-blocking when piped
- **`Double-Click to Install.command`** + **`Installation-Instructions.txt`** — the zip's friendly front door: a double-clickable macOS bootstrap (relocates to `~/project-system`, runs `install.sh`, drops into a ready shell) and a plain-text note (double-click + the Gatekeeper right-click→Open tip)
- **`INSTALL.md`** — the friendly, retro-styled front-door install guide that ships in the release zip (the manual/terminal path)
- **`SETUP.md`** — the generic (Path-1) adopter install guide + the two-path adoption framing (the detailed reference behind `INSTALL.md`)
- **`ARCHITECT-PATTERN.md`** — the dual-session design workflow (`/grill` executor + `/architect` advisor)

The workspace it operates on is `~/Projects/{Active,Inactive,Archive}/` — a folder structure on disk, not a repo. See `CONVENTIONS.md` § "The three folders" for what each one means and the tests for deciding where something belongs.

## Optional integration with dotfiles

The companion repo `y3klab/dotfiles` is a personal Claude Code env. It's **independent** — install it or skip it. If both are installed at the conventional paths:
- dotfiles' `zsh/zshrc` ends with a conditional `source` of `~/project-system/shell/zshrc-fragment.sh`, so the shell aliases activate automatically.
- The slash commands in `claude/commands/` here are symlinked into `~/.claude/commands/` by *this* repo's `install.sh` (not dotfiles').

If you skip dotfiles, project-system still works — you just need to add one line to your `~/.zshrc` to source the shell fragment (`install.sh` prints the line for you on first run).

## Read these first (in order)

1. **`CONVENTIONS.md`** — the principles. For *why* a convention exists, read `CHANGES.md` (the dated design-history log); for how to author a per-project file, `AUTHORING.md`.
2. **`README.md`** — bootstrap on a new machine.
3. **`LEXICON.example.md`** — the cross-project vocabulary model (your live `LEXICON.md` is gitignored).
4. **`bin/newproject.sh`** — reading it teaches you how the system actually operates.

## Operating rules

- **System changes affect every project.** Be deliberate. Pair behaviour-affecting changes with a corresponding update to `CONVENTIONS.md` (the principle) and a dated entry in `CHANGES.md` (the *why*).
- **Registry operations write nothing to this repo.** `newproject`, `importproject` and the mover touch the workspace and `~/.claude.json` only - there is no index to update, so they never commit or push here. If you see one of them producing a commit, something has regressed.
- **Slash commands and scripts are paired.** `bin/newproject.sh` stages files; `claude/commands/setup-project.md` reads them. When you change one, check the other.
- **Shell aliases live in `shell/zshrc-fragment.sh`.** When you add a new script to `bin/`, decide whether it needs a corresponding alias and add one to the fragment.
- **`CHANGES.md` is load-bearing.** Every meaningful convention change gets a dated entry. Future maintainers rely on it to understand *why* a rule exists.
- **The registration floor is written in code, not copied from a template.** `registry_write_project_files` in `bin/_registry.sh` is the one writer; the shape it produces is documented in `CONVENTIONS.md` § "What a project contains". Adding a file to the floor means every project gets it forever - resist accumulation, and prefer letting `/setup-project` earn the file instead.

## Where the deep history lives

The full design history (decisions, friction logs, the multi-iteration buildout) is at `~/Projects/Archive/2026-claude-md-setup/` (specifically `DECISIONS.md` — 37 KB of reasoning). Open that archive when you need to know *why* a pattern exists and the live docs don't say.

## Don't

- **Don't reintroduce a master list of projects.** The workspace is the list - `list-projects.sh` reads the three tiers from disk, so the dashboard cannot be missing one and there is nothing to keep in sync. A second copy is a thing that can disagree with the first; this system kept one for three months and paid for it with a drift check.
- **Don't add a project-specific CLAUDE.md here.** This repo IS the system. CLAUDE.md files for individual projects live in `~/Projects/Active/<project>/`. The one you're reading is maintenance context for the system itself — different role.
- **Don't commit `.system/` directories from individual projects** — `newproject` writes a per-project `.gitignore` that excludes `.system/` at creation time. For projects that predate this, add `.system/` to the project's `.gitignore` manually.
- **Don't push project-system content into dotfiles.** The two repos are intentionally independent; coupling content from one into the other defeats the point.
