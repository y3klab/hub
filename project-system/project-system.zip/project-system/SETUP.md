# Setting up project-system

The **generic install** — it stands up the project-lifecycle system on its own: the `newproject` script and the dashboard mover, the Claude Code slash commands, the conventions, and the `~/Projects/` workspace. You keep your own shell config and your own git identity; this installs *the methodology*, nothing personal.

> **Two ways to adopt.** This doc is **Path 1 — just the methodology** (what most people want). **Path 2** is the full-stack route: also adopt the author's personal Claude Code + shell environment (`dotfiles`) and personalize it to you — handled by the separate **project-system-wizard**. If you only want a way to manage projects, you're in the right place; stay on Path 1. Wanting the author's `dotfiles` is exactly what routes you to Path 2 instead.

## Prerequisites

- **git** — required.
- **[Claude Code](https://claude.com/claude-code)** — the slash commands (`/setup-project`, `/grill`, `/init-claude-md`, `/architect`) run here.
- **gh** (GitHub CLI) — *optional*, only for the "create a new GitHub repo" branch of `/setup-project`. Skip it and you can still connect any remote by pasting its URL.

## Install

```sh
# 1. Clone (your fork, or directly from the source)
git clone <your-fork-or-the-source>/project-system.git ~/project-system
#    — or, if you were handed a release zip instead of a repo URL:
#    unzip project-system.zip -d ~      (it unpacks as a ready git repo)

# 2. Run the installer — checks prerequisites (git, Claude Code, zsh), symlinks
#    the slash commands into ~/.claude/commands/, seeds LEXICON.md from the
#    example, creates the ~/Projects/{Active,Inactive,Archive} workspace,
#    and offers to add the shell-aliases line to your ~/.zshrc. It announces
#    every path it touches; add --dry-run to preview it all without writing.
~/project-system/install.sh          # or: install.sh --dry-run  (preview only)

# 3. Reload the shell
exec zsh
```

## Make it yours

- **Lexicon.** `install.sh` seeded `LEXICON.md` from `LEXICON.example.md` with placeholder terms. Replace them with the brands, acronyms, and coined terms you reuse across projects — edit `LEXICON.md` directly. It's your personal cross-project vocabulary; `/setup-project` and `/grill` seed any matching term into a project's `GLOSSARY.md` and offer to promote new cross-project terms back. `LEXICON.md` is gitignored: it's *yours*, and pulls never clobber it.
- **Your identity stays yours.** project-system doesn't touch your git config, SSH, or shell prompt — it uses whatever you already have. (That's why there's nothing personal to "customize" here — Path 2's wizard exists for the case where you *are* adopting someone else's personal stack.)

## First run

```sh
newproject      # interactive — creates your first project in ~/Projects/Active/
importproject   # interactive — brings an EXISTING folder or git repo into Active/
```

`newproject` scaffolds a fresh project from the template; `importproject` is the **adoption on-ramp** — point it at a folder you've already been working in (or a git URL) and it copies/clones it into `~/Projects/Active/`, pre-trusts it, indexes it, and commits, then offers the full `/setup-project` intake. It's non-destructive (your original folder is never moved or changed) and quick by default, so bringing a pile of existing projects under management stays fast. Both are also reachable from the dashboard (`proj`): the `n` and `i` doorways.

That's it. For the principles behind the system, read `CONVENTIONS.md`; for the cross-project vocabulary model, `LEXICON.example.md`.
