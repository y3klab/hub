# shellcheck shell=bash
# project-system shell aliases + functions.
#
# Activate by sourcing from your shell rc. The companion dotfiles repo
# (y3klab/dotfiles) does this automatically if project-system is installed
# at the conventional path. If you're not using dotfiles, add this to your
# ~/.zshrc (or equivalent):
#
#   [ -f "$HOME/project-system/shell/zshrc-fragment.sh" ] && \
#     source "$HOME/project-system/shell/zshrc-fragment.sh"
#
# Everything in this file targets the project-system workspace at
# ~/Projects/{Active,Inactive,Archive}/. Without that workspace + the
# scripts in ~/project-system/bin/, these aliases are dead.

# ----------------------------------------------------------------------
# Quick jumps into the workspace
# ----------------------------------------------------------------------
# projects / proj: cd to ~/Projects/, show every project in the
# workspace grouped by section (Active / Inactive) with chip-style numbered
# selectors, then let you pick one to OPEN.
#
# On an interactive terminal the picker is POINT-AND-ACT (list-projects.sh
# --select): ↑/↓ (or j/k) move a highlighted cursor, typing a number jumps the
# cursor to that row (multi-digit accumulates — type 21 to land on 21), Enter
# opens the highlighted project, `m` moves it, and `q`/Esc leaves the dashboard.
# Numbers are kept for O(1) direct jump; arrows are for browse-and-pick — both
# coexist. The doorway keys below (`a`/`n`/`i`/`r`) are unchanged. When stdin/stdout
# isn't a TTY (piped, scripted) it falls back to the classic type-a-token prompt
# (a number then Enter to open, `m<#>` to move, Enter to stay) — same doorways.
#
# Opening a project = cd into it, then run $PROJECTS_OPEN_CMD (default: claude),
# so the dashboard is the front door to *working*, not just to a folder. Set
# PROJECTS_OPEN_CMD="" in your shell for the old behaviour (cd + ls only); set
# it to any command you like. If the command is empty or not found on PATH, it
# falls back to `ls -lt`. After it exits, you're left in the project dir.
#
# `m` on the highlighted project (or `m<#>` in the fallback prompt) opens the
# mover — a state-aware walk-through for deactivating / activating / archiving /
# unarchiving / deleting it. The dashboard is the only entry point to it; there's
# no standalone `moveproject` alias. When the mover finishes, the dashboard
# re-renders (showing the project in its new section) so you stay on it.
#
# `a` is the doorway to the Archive — a quiet, dimmed option under the legend.
# It re-renders in cold greyscale WITH the Archive section shown; there Enter
# opens the highlighted archived project for inspection (cd + ls only, never the
# open command — the vault is for looking, not working) and `m` still moves items.
# `a` again (or `q`/Esc) returns to the live colour view.
#
# `n` and `i` are the two warm (magenta) doorways under the legend — both land
# a project in Active/. `n` scaffolds a new one (newproject); `i` imports an
# existing folder or git repo (importproject). After either, the dashboard
# re-renders with the new project shown.
#
# `r` refreshes every project whose chip is STALE — the dashboard already knows
# which (the x / "needs" markers; `list-projects.sh --stale` emits the set). It
# runs the /project-status workflow HEADLESSLY per stale project (judge from
# PLAN/CHECKLIST/git, rewrite the local `.system/status` chip — no CLAUDE.md, no
# commit, no push), showing an honest batch-percentage bar + a live spinner, then
# re-renders so the chips flip fresh — all without leaving the dashboard. Bash
# finds the stale set, so only genuinely-stale projects get a (slow) judgment;
# the agent never walks the whole list. There's no `r<#>`: you never need to
# refresh a project that isn't stale (its chip already matches reality), so one
# key clearing exactly what's flagged covers everything.
#
# Behavior matches `list projects` (which delegates here).
#
# For direct folder jumps (skip the project picker), use the
# per-folder aliases instead: `bench` (Active), `inactive`.

# _open_project: from inside a project dir, run the configured open command.
# Default `claude`; honour an explicit empty override (cd-only); fall back to
# `ls -lt` if the command is empty or not on PATH. Runs in the current shell so
# you're left in the project dir when it exits.
_open_project() {
  local cmd="${PROJECTS_OPEN_CMD-claude}"
  if [ -z "$cmd" ] || ! command -v "${cmd%% *}" >/dev/null 2>&1; then
    ls -lt
    return
  fi
  eval "$cmd"
}

# ── status-chip refresh (the `r` doorway) ─────────────────────────────────────
# `r` re-judges every STALE project. Bash finds the stale set (list-projects.sh
# `--stale`, the same `_chip_state` that draws the x), so only genuinely-stale
# projects get a judgment — the agent never walks the whole list. Each judgment
# is HEADLESS `claude -p`: it auto-exits (an interactive `claude` would run the
# command then sit in the REPL, stranding you), and we feed the command FILE's
# contents as the prompt (headless can't invoke a custom slash command by name) —
# one source of truth. `-p` stops dead on any tool prompt, so we pre-authorize:
# acceptEdits + an allow-list for Read/Write and Bash (git reads + `date`). The
# refresh is PURELY LOCAL — it writes only the gitignored `.system/status` chip
# (stamped with the current HEAD); it never edits CLAUDE.md, never commits, never
# pushes, so status churn never touches a project's git history or GitHub. Progress
# is honest: a batch-percent bar (completed/total, real) + a live spinner per
# project (we can't measure inside one opaque `-p` call, so no fabricated per-project %).

# _ps_bar <pct> → a fixed-width [████░░░] bar for the honest BATCH percentage.
_ps_bar() {
  local pct=$1 width=16 i fill=$(( $1 * 16 / 100 )) out=""
  for (( i = 0; i < width; i++ )); do
    if (( i < fill )); then out+="█"; else out+="░"; fi
  done
  printf '%s' "$out"
}

# _refresh_one <dir> <name> <i> <total>: one project's headless refresh, with a
# spinner + batch bar while it runs, then a ✓ line carrying the new chip (read
# back from `.system/status` — more reliable than parsing the agent's stdout).
_refresh_one() {
  local dir="$1" name="$2" i="$3" total="$4"
  local cmd_file="$HOME/project-system/claude/commands/project-status.md"
  local pct=$(( (i - 1) * 100 / total )) bar; bar=$(_ps_bar "$pct")
  ( cd "$dir" 2>/dev/null && {
      cat "$cmd_file"
      printf '\n%s\n%s\n' \
        "--- Headless invocation (from the dashboard) ---" \
        "Refresh ONLY this project — the current directory IS the project. Write the chip to .system/status ONLY; do NOT touch CLAUDE.md, do NOT git add/commit, do NOT push — this is a purely local refresh. Final output: one line — the project and its new chip."
    } | claude -p --permission-mode acceptEdits --allowedTools "Bash,Read,Edit,Write" >/dev/null 2>&1 ) &
  local pid=$! frames='⠋⠙⠹⠸⠼⠴⠦⠧⠇⠏' f=0
  while kill -0 "$pid" 2>/dev/null; do
    printf "\r\033[K  %s  [%s] %3d%%   %s …" "${frames[$(( f % 10 + 1 ))]}" "$bar" "$pct" "$name"
    f=$(( f + 1 )); sleep 0.1
  done
  wait "$pid" 2>/dev/null
  local chip="(no chip written)"
  [ -f "$dir/.system/status" ] && { chip=$(head -n1 "$dir/.system/status"); chip="${chip%% ⟂ *}"; }
  printf "\r\033[K  ✓ [%d/%d] %s  →  %s\n" "$i" "$total" "$name" "$chip"
}

# _refresh_stale: refresh every stale project (bash finds them; only those run).
# Confirms before a multi-project run; Ctrl-C aborts (finished ones stay done).
_refresh_stale() {
  setopt localoptions nomonitor      # no "[1] 12345 done" job spam under the spinner
  if ! command -v claude >/dev/null 2>&1; then
    echo "Claude Code (claude) not found — open a project and run /project-status."
    return 1
  fi
  local stale
  stale=("${(@f)$("$HOME/project-system/bin/list-projects.sh" --stale)}")
  [ ${#stale[@]} -eq 1 ] && [ -z "${stale[1]}" ] && stale=()   # empty output → empty set
  local total=${#stale[@]}
  if (( total == 0 )); then
    echo "✓ all status chips are current — nothing to refresh."
    return 0
  fi
  if (( total > 1 )); then
    printf "%d projects need a status refresh. Go? [Y/n] " "$total"
    local ans; read -r ans
    case "$ans" in [nN]*) echo "Skipped."; return 0 ;; esac
  fi
  echo ""
  echo "↻ refreshing $total stale project(s) — Ctrl-C to stop (finished ones stay done)"
  local i=0 rel name
  for rel in "${stale[@]}"; do
    i=$(( i + 1 )); name="${rel##*/}"
    _refresh_one "$HOME/Projects/$rel" "$name" "$i" "$total"
  done
  printf "  [%s] 100%%   all set\n" "$(_ps_bar 100)"
}

# projects(): the dashboard front door. Interactive TTY → the arrow-key picker
# (_projects_tui); non-TTY / piped → the classic line-read prompt (_projects_lineread,
# which is also the documented fallback). Both render via list-projects.sh.
projects() {
  cd "$HOME/Projects" || return
  if [ -t 0 ] && [ -t 1 ]; then
    _projects_tui
  else
    _projects_lineread
  fi
}

# _projects_tui: drive list-projects.sh --select. The script owns the raw-mode
# keyboard loop (point-and-act: ↑/↓/jk move a cursor, digits jump it, Enter opens,
# m moves, q quits) and prints ONE decision line we capture + dispatch here — so
# cd/open still happen in THIS shell. The script draws its UI to /dev/tty; only the
# decision reaches stdout. `view` toggles the cold-vault (--archive); the banner
# power-on animates on first render only (_anim), matching the prior dashboard.
_projects_tui() {
  local LP="$HOME/project-system/bin/list-projects.sh"
  local view="live" decision verb arg target archflag _anim=1
  while true; do
    archflag=""; [ "$view" = archive ] && archflag="--archive"
    decision=$(PS_ANIMATE="$_anim" "$LP" --select $archflag)
    _anim=""
    verb="${decision%% *}"
    arg="${decision#"$verb"}"; arg="${arg# }"
    case "$verb" in
      open)
        # decision carries the GLOBAL number; resolve via --paths and open for work.
        target=$("$LP" --paths | awk -F: -v n="$arg" '$1 == n { print $2 }')
        [ -n "$target" ] && { cd "$HOME/Projects/$target" || return 1; _open_project; }
        return 0 ;;
      inspect)
        # cold vault → open for inspection only (cd + ls), never the open command.
        target=$("$LP" --paths | awk -F: -v n="$arg" '$1 == n { print $2 }')
        [ -n "$target" ] && { cd "$HOME/Projects/$target" || return 1; ls -lt; }
        return 0 ;;
      move)    "$HOME/project-system/bin/moveproject.sh" "$arg"; continue ;;
      new)     "$HOME/project-system/bin/newproject.sh"; view="live"; continue ;;
      import)  "$HOME/project-system/bin/importproject.sh"; view="live"; continue ;;
      refresh) _refresh_stale; continue ;;
      archive) view="archive"; [ -t 1 ] && printf '\e[2J\e[H'; continue ;;
      live)    view="live";    [ -t 1 ] && printf '\e[2J\e[H'; continue ;;
      *)       return 0 ;;   # quit / empty / unknown → leave the dashboard
    esac
  done
}

# _projects_lineread: the classic type-a-token prompt. The non-TTY/piped fallback,
# and still the documented behaviour for scripted callers.
_projects_lineread() {
  # Declare the loop-locals ONCE, up front — not inside the loop. In zsh,
  # re-running a bare `local choice` each iteration makes the *next* `read`
  # echo "choice=<previous value>" onto the prompt (a stray "choice=m" after you
  # return from the mover). Declaring once (or resetting before read) avoids it.
  local choice _btn _r _amuted _nwarm target view="live" _anim=1 _aidx _gnum
  # Loop so a move/delete (or toggling the archive view) drops back onto a
  # freshly-rendered dashboard instead of the bare shell. Opening a project and
  # Enter-to-stay (from the live view) still leave the loop.
  #
  # Animate the PROJECTS wordmark's power-on ONLY on the first render of a `proj`
  # session (_anim=1), then go static for every loop re-render (_anim="" after the
  # first pass). The dashboard re-renders constantly — after each move, archive
  # toggle, or return from new/import — so replaying the ~0.6s entrance every time
  # would grate (and double up right after newproject/importproject's own
  # animation). First-entry-only keeps the wow on open without the tedium.
  # PS_ANIMATE="" is treated as off; the animation is also TTY-gated inside
  # list-projects.sh, so piped callers stay instant regardless.
  while true; do
    if [ "$view" = "archive" ]; then
      PS_ANIMATE="$_anim" "$HOME/project-system/bin/list-projects.sh" --archive
    else
      PS_ANIMATE="$_anim" "$HOME/project-system/bin/list-projects.sh"
    fi
    _anim=""
    # Chip the input affordances (`#`, `m`, `enter`) as a keyboard legend.
    # Darkest-purple keycap (55, the palette's deepest purple) with bright text:
    # a dark fill reads as a subtle tint that blends into the black terminal —
    # not a garish solid block — while staying legible. The `a` doorway is a
    # muted *grey* chip (not the live purple keycap) — the way to the cold vault
    # should itself be understated. Plain off a TTY.
    _btn=""; _r=""; _amuted=""; _nwarm=""
    # `_amuted` = grey letter (→ Archive, cold); `_nwarm` = magenta letter, the
    # Active hue (→ new project lands in Active, warm). Same dark muted chip bg so
    # both stay subordinate to the bright keycaps — each doorway tinted by where
    # it leads, mirroring the dashboard's warm/cold temperature map.
    if [ -t 1 ]; then _btn=$'\e[48;5;55m\e[97m'; _r=$'\e[0m'; _amuted=$'\e[48;5;236m\e[38;5;245m'; _nwarm=$'\e[48;5;236m\e[38;5;201m'; fi
    if [ "$view" = "archive" ]; then
      printf "Type ${_btn} %s ${_r} to open (look only) · ${_btn} %s ${_r} to move or delete · ${_btn} %s ${_r} to return to the live view\n" "#" "m" "enter"
    else
      printf "Type ${_btn} %s ${_r} to open · ${_btn} %s ${_r} to move/archive/delete · ${_btn} %s ${_r} to refresh stale · ${_btn} %s ${_r} to stay\n" "#" "m" "r" "enter"
      printf "     ${_nwarm} %s ${_r}  ·  new project    ${_nwarm} %s ${_r}  ·  import project    ${_amuted} %s ${_r}  ·  view archive\n" "n" "i" "a"
    fi
    choice=""
    read -r choice
    # Enter: from the archive view it returns to the live view; from the live
    # view it leaves the dashboard (stay in ~/Projects).
    if [ -z "$choice" ]; then
      if [ "$view" = "archive" ]; then view="live"; [ -t 1 ] && printf '\e[2J\e[H'; continue; fi
      return 0
    fi
    # `a` toggles the cold-storage Archive view on/off.
    case "$choice" in
      a|A)
        if [ "$view" = "archive" ]; then view="live"; else view="archive"; fi
        # Clear on the archive↔live toggle so each view opens fresh (matches the
        # mover's clean entry/exit), instead of stacking under the prior render.
        [ -t 1 ] && printf '\e[2J\e[H'; continue ;;
      n|N)
        "$HOME/project-system/bin/newproject.sh"; view="live"; echo ""; continue ;;
      i|I)
        "$HOME/project-system/bin/importproject.sh"; view="live"; echo ""; continue ;;
      r|R)
        # `r` → refresh every stale project (bash finds the set; progress shown).
        _refresh_stale; echo ""; continue ;;
    esac
    # In the ARCHIVE view the displayed numbers are a local 1..N index into the
    # Archive section only (the cold vault is its own list). Map the pick back to
    # its GLOBAL --paths number so the mover + the resolver below work unchanged.
    # Bare `m` (no number) is left alone — it re-lists inside the mover.
    if [ "$view" = "archive" ]; then
      case "$choice" in
        [0-9]*|m[0-9]*|M[0-9]*)
          _aidx="${choice#[mM]}"
          case "$_aidx" in ''|*[!0-9]*) echo "Invalid selection."; return 1 ;; esac
          _gnum=$("$HOME/project-system/bin/list-projects.sh" --paths \
            | grep ':Archive/' | sed -n "${_aidx}p" | cut -d: -f1)
          [ -z "$_gnum" ] && { echo "Invalid selection."; return 1; }
          case "$choice" in [mM]*) choice="m$_gnum" ;; *) choice="$_gnum" ;; esac ;;
      esac
    fi
    # `m` / `m<#>` hand off to the dedicated mover (the only way to reach it —
    # there's no standalone alias). Bare `m` lets it re-list and ask which #;
    # `m3` acts on project 3 straight away. After it returns, re-render.
    case "$choice" in
      m|M)             "$HOME/project-system/bin/moveproject.sh"; echo ""; continue ;;
      m[0-9]*|M[0-9]*) "$HOME/project-system/bin/moveproject.sh" "${choice#[mM]}"; echo ""; continue ;;
    esac
    target=$("$HOME/project-system/bin/list-projects.sh" --paths \
      | awk -F: -v n="$choice" '$1 == n { print $2 }')
    if [ -n "$target" ]; then
      cd "$HOME/Projects/$target" || return 1
      # Live view opens for *work* (the configured open command); the Archive
      # view opens for *inspection* only (cd + ls), never the open command.
      if [ "$view" = "archive" ]; then ls -lt; else _open_project; fi
      return 0
    else
      echo "Invalid selection."
      return 1
    fi
  done
}
alias proj='projects'
alias workbench='cd ~/Projects/Active && ls -lt'
alias bench='cd ~/Projects/Active && ls -lt'
alias inactive='cd ~/Projects/Inactive && ls -lt'

# Jump into the project-system repo itself (the tooling, not the workspace).
alias projectsystem='cd "$HOME/project-system"'
alias project-system='cd "$HOME/project-system"'

# ----------------------------------------------------------------------
# Project scripts (bash; live in ~/project-system/bin/)
# ----------------------------------------------------------------------
# newproject (scaffold) and importproject (adopt) are the standalone commands
# that land a project in Active/. Deactivate / activate / archive / unarchive /
# delete all live behind the dashboard's `m` mover (reach it from `proj`), so
# transitions — and especially delete — are never a single memorised keystroke away.
alias newproject='$HOME/project-system/bin/newproject.sh'
# importproject: bring an EXISTING folder or git repo into Active/ as a managed
# project (copy/clone + pre-trust, then offers /setup-project).
# The adoption on-ramp; also reachable via the dashboard's `i` doorway.
alias importproject='$HOME/project-system/bin/importproject.sh'
alias make-release='$HOME/project-system/bin/make-release.sh'
# audit-backups: report which workspace projects lack an off-machine backup
# (a pushed git remote). Read-only. Mark a project intentionally-local with
# `backup: local` in its .system/project.md to silence it.
alias audit-backups='$HOME/project-system/bin/audit-backups.sh'

# ----------------------------------------------------------------------
# `new <thing>` dispatcher
# ----------------------------------------------------------------------
new() {
  local subcommand="$1"

  if [ -z "$subcommand" ] || [ "$subcommand" = "help" ] || [ "$subcommand" = "-h" ] || [ "$subcommand" = "--help" ]; then
    cat <<EOF
Usage: new <thing>

Available:
  new project       Create a new active project (interactive)

For help on a specific subcommand: new <thing> --help
EOF
    return 0
  fi

  case "$subcommand" in
    project)
      shift
      "$HOME/project-system/bin/newproject.sh" "$@"
      ;;
    *)
      echo "Unknown: 'new $subcommand'"
      echo "Run 'new' (no args) to see available subcommands."
      return 1
      ;;
  esac
}

# ----------------------------------------------------------------------
# `list <thing>` dispatcher
# ----------------------------------------------------------------------
list() {
  local subcommand="$1"

  if [ -z "$subcommand" ] || [ "$subcommand" = "help" ] || [ "$subcommand" = "-h" ] || [ "$subcommand" = "--help" ]; then
    cat <<EOF
Usage: list <thing>

Available:
  list active           Show active project folders
  list inactive         Show inactive folders (dormant / will-resume)
  list archive          Show archived project folders
  list projects         Show the project dashboard
  list rules            Show CONVENTIONS.md (system principles)

For help on a specific subcommand: list <thing> --help
EOF
    return 0
  fi

  case "$subcommand" in
    active)
      ls "$HOME/Projects/Active/"
      ;;
    inactive)
      ls "$HOME/Projects/Inactive/"
      ;;
    archive)
      ls "$HOME/Projects/Archive/"
      ;;
    projects)
      projects
      ;;
    rules)
      cat "$HOME/project-system/CONVENTIONS.md"
      ;;
    *)
      echo "Unknown: 'list $subcommand'"
      echo "Run 'list' (no args) to see available subcommands."
      return 1
      ;;
  esac
}
