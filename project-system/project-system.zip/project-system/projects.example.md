# Projects

The workspace. Everything being worked on lives in one of three folders here.

- `Active/` - engaged now
- `Inactive/` - dormant but alive
- `Archive/` - done, kept for reference

What each tier means, and the tests for deciding where something belongs, are in
`~/project-system/CONVENTIONS.md` (§ The three folders). This file points at them
rather than restating them, so they can only be wrong in one place.

**A project is a folder in one of those three.** That is the whole rule. There is
no list of projects to keep anywhere - what lies in a tier is whatever is sitting
in it. Run `proj` to see them all, or `ls` a tier.

Where a project has an overview of its own, it is named after its folder
(`my-project/my-project.md`). A project need not have one - its absence is a
correct state, not a gap.

The system that operates on this workspace - the scripts, the conventions, the
slash commands - lives next door in `~/project-system/`.

## Notes

<!--
  Yours. A start-here pointer, a reading order, anything worth telling
  future-you on opening this folder.

  ONE CONSTRAINT: nothing written here may become false when a project is
  added, renamed, moved between tiers, or deleted. So no counts, no lists of
  project names, no characterizing the population ("mostly client work"). A
  DATED observation is exempt - "2026-08-21: 47 active" records what was true
  on a day, and a record of the past never becomes a lie.

  This section is the only part of this file that refers to what lies below
  it, which makes it the whole staleness surface. Nothing checks it but you,
  at the moment you write it.
-->
