# SKILLS.md — where Claude Code skills live, and why

How to decide where a skill belongs, grounded in how Claude Code actually loads
them. Companion to `CONVENTIONS.md` (the broader system rules). The live catalog of *what skills exist and where* is
**generated**, not kept here by hand (see § The catalog).

## The mechanism — what Claude Code actually does

Skills load from exactly three places:

- **Global** — `~/.claude/skills/<name>/SKILL.md` (and global commands in
  `~/.claude/commands/`). Loads in **every** session, everywhere.
- **Project** — `<repo>/.claude/skills/<name>/SKILL.md`. Loads only when the
  working directory is inside that repo.
- **Plugin** — bundled in a plugin installed from a marketplace. Loads wherever
  the plugin is enabled.

Three facts constrain every decision below:

- **Plugin enablement is global-only.** There is no per-project plugin toggle, so
  an installed plugin loads *everywhere*. A plugin gives **universal** scope —
  never "this family of repos."
- **There is no native "family of repos" scope.** Claude Code has no concept of
  "all my client repos but not my personal ones." The only repo-scoping is per-repo
  project skills.
- **Built-ins ship inside the `claude` binary** (`deep-research`, `/review`,
  `/init`, …). They have no file on disk. They are not yours — nothing to locate,
  track, or manage. If a skill has no file anywhere, it's a built-in.

## The decision rule

**A skill lives where it's *invoked* and *conceptually owned* — never where it
*writes*.** A skill that writes into another repo (or an external API) still has
one invocation context and one owner; that is its home. The write-target is just
a destination it knows the path to. (`triage` writes into OPS but lives in the
catalog; `log-time` would write to FreshBooks but lives where you invoke it.)

Then split by how it triggers:

- **Ambient skills** fire *on context* — e.g. "whenever rig photos land in
  `_inbox/`." These **must** be tightly scoped to the repo where they should
  fire; loading them elsewhere risks a *misfire*. → **single-project**.
- **Invoked tools** run only when you explicitly ask — "log time", "author a
  guide", "provision a key." Loading one where you won't use it is harmless
  menu-noise, not a misfire. → **global is fine**; scope only for tidiness or
  ownership, never for safety.

## The two personal tiers (no repo-family tier; the team tier is § below)

The "brand family" tier people reach for doesn't exist in Claude Code, and in
practice isn't needed — every brand skill turns out to be either scoped to one
repo or used broadly. (Plugins don't create it either: a plugin still loads
*everywhere*; what it adds is a **distribution** axis — see § Team-shared.)
So for where a skill loads *for you*, there are two homes:

1. **Universal / personal → global.** Your cross-project toolkit. Lives in
   `~/.claude/skills/` or `~/.claude/commands/`. **Version-control it** — globals
   are valuable and a dead laptop loses anything untracked:
   - personal skills → real files in `~/dotfiles/claude/skills/`, **symlinked**
     into `~/.claude/skills/` (the same pattern as the global `CLAUDE.md`).
   - project-system process commands → tracked in `project-system` itself.
2. **Single-project → the repo's `.claude/skills/`.** Anything specific to one
   project. It is auto-owned by that repo's identity (its git remote) and tracked
   there. If the repo gitignores `.claude/`, add the carve-out so the skill is
   still tracked:
   ```gitignore
   .claude/*
   !.claude/skills/
   ```

A skill that is *invoked-from-anywhere* but only ever used in **one** project
(e.g. authoring guides, which live in one catalog repo) is just **single-project
in that repo** — not a special case.

### The middle case — project-owned, but globally invoked

A skill can *belong* to one project (it manages that project's domain and evolves
with it) yet be invoked from *many* projects. That's neither pure tier. Keep the
real skill **in its owning repo's `.claude/skills/`** — versioned alongside what
it manages — and **symlink it into `~/.claude/skills/`** for global reach. Same
mechanism as the dotfiles pattern above, just sourced from the owning project
instead of dotfiles. Declare `trigger: invoked`.

Reserve it for skills *genuinely* invoked from multiple projects: one project →
single-project; generic personal tooling with no owning project → dotfiles. The
symlink ties global availability to the owning repo's presence, so use it only for
a stable, long-lived project. (The **Agents** section below applies this exact
pattern, with **Skynet** as the worked example.)

## Team-shared → a private plugin marketplace

The third home sits on a different axis. The two tiers above answer *where does
this load for me*; the team tier answers *who else gets it*: a skill or agent
teammates should run too lives in a **private plugin-marketplace repo**, installed
once per person (`/plugin marketplace add <org>/<repo>` → `/plugin install`), and
every push to `main` is the release (SHA-versioned — omit `version` from the
manifests). Worked example: an org's **`<org>/claude-plugins`** repo (one marketplace, one or
more plugins) - the team's shared agents live there rather than in each person's
dotfiles, and GitHub org access is the access control.

The rules that come with it:

- **Delete the personal copy when an agent graduates.** Same-name agents in
  `~/.claude/agents/` (or a repo's `.claude/agents/`) **shadow** the plugin's —
  keeping one means silently running a different version than the team. The
  maintainer installs the plugin like everyone else and edits in the marketplace
  clone.
- **Bundle what it depends on.** A plugin auto-discovers its `agents/` and
  `skills/` dirs — a personal skill an agent invokes must ride along
  (`frontend-design` ships with 'Los; bundled skills are namespaced
  `<plugin>:<skill>`). An agent whose *engine* is code + credentials elsewhere
  (Critter → BrowserStack/Keeper) isn't shareable by `.md` alone — solve the
  access story first.
- **Scrub for portability before it graduates**: no operator-specific names, no
  absolute personal paths (Wapuu needed 4 such edits).
- **Team agents carry the self-learning trio** — `## Improving yourself` (a
  self-capture instruction: the agent ends reports with ready-to-file Gotcha/Trick
  candidates; a human approves, the session PRs) + `## Tricks` + `## Gotchas` —
  baked in structurally by the repo's `_template/agent.md`, mirroring the global
  skills Gotchas+Tricks rule (CLAUDE.md § Skills).
- **Plugin agents can't use `hooks`, `mcpServers`, or `permissionMode`**
  frontmatter — an agent needing those stays repo-level.

## Agents (subagents) — the same model

Subagents (`.claude/agents/<name>.md`) load by the **identical** two-tier
mechanism as skills and commands: **global** `~/.claude/agents/<name>.md` (every
session) vs **project** `<repo>/.claude/agents/<name>.md` (only inside that repo).
The decision rule carries over unchanged — an agent you **invoke** (`@name` /
"use the X subagent") is never ambient, so globalizing it is safe menu-presence,
not a misfire risk. Version-control it the same way: keep the **real file in its
owning repo** and **symlink** it into `~/.claude/agents/`.

Worked example — **Skynet**, a homelab / Home-Assistant expert agent. The
real file lives in its owning repo at `y3k-homelab/.claude/agents/skynet.md` (so
it's versioned with the docs it reads), symlinked to `~/.claude/agents/skynet.md`
for global reach. It resolves its knowledge base by **absolute** repo path, so it
works from any cwd. Recreate the symlink on a new machine:

```sh
ln -s ~/Projects/Active/y3k-homelab/.claude/agents/skynet.md ~/.claude/agents/skynet.md
```

(An agent owned-by *and* invoked-only-within one project could equally stay
**project-scoped** — globalizing is the override you pick when you want to call it
without `cd`-ing into the repo. Skynet took the override.)

**A skill and an agent can wrap the same capability — DRY them.** The skill runs
*inline* (the main Claude does the work in your conversation); the agent runs
*delegated* (a separate context does it and hands back the result). Keep **one**
source of guidance: the skill holds it, and the agent **invokes the skill** (agents
carry the `Skill` tool) rather than duplicating it. Example: the inline
`frontend-design` skill + the delegated **`los`** agent, whose body is thin working
style that invokes that skill (both now team-shared in a plugin). Keep the mode(s) you actually use — both is fine when
they're DRY'd this way.

## Retiring

A stalled or superseded skill → move its repo/folder to `Inactive/`, drop it from
the dashboard's Active view with it, and (if it was its own skill-repo) it
leaves the skill inventory.
Don't leave dead skeletons loadable.

## The catalog

*What* skills exist and *where* is **generated from the filesystem, never kept by
hand** — hand-maintained indexes drift. (The project system used to keep one,
`INDEX.md`; it was dissolved on 2026-08-21 for exactly this reason. This catalog
survives because it is *generated*, never authored.) Run:

```sh
bin/skills-catalog.sh
```

It scans every skill, command, and agent location (`~/.claude/{skills,commands,agents}`
and each Active/Inactive repo's `.claude/{skills,commands,agents}`), skips the
marketplace cache and third-party clones, tags each by **scope** (from location)
and **owner** (from the repo's git remote — for a globally-symlinked agent, the
owner is its *source* repo), and writes `skills-catalog.md`. A project-owned agent
symlinked into `~/.claude/agents/` is listed once, as its GLOBAL row. It
It reports no project-index drift any more, and cannot: the workspace is the
only list of projects, so there is nothing for it to disagree with.

**Trigger (ambient vs invoked) is declared in the skill, not guessed.** Add a
`trigger:` key to each skill's frontmatter — it's safe (Claude Code ignores
unknown keys, the way official skills carry `allowed-tools` / `user-invocable`)
and it's co-located with the skill, so it can't drift:

```yaml
---
name: garage-gallery-scene
description: …
trigger: ambient        # ambient = fires on context · invoked = only when asked
---
```

The catalog reads `trigger:` as ground truth; where a skill hasn't declared it,
it falls back to a description heuristic and flags the guess with `?` (the
heuristic is unreliable — declare the field). Every new skill should set it.

## Gotchas

- A `SKILL.md` at a repo **root** does NOT load — skills load only from
  `.claude/skills/<name>/SKILL.md`. A skill authored as its own repo must install
  into a `.claude/skills/` dir (or a plugin) to actually run.
- A `~/.claude/skills/<name>` entry can be a **symlink** into dotfiles — it still
  loads, and now it's version-controlled.
- **Names are identifiers — keep them shell-safe.** Lowercase, no apostrophes,
  quotes, or spaces — an apostrophe breaks the *filename* (shell quoting), the YAML
  `name:` value, and the `@invoke` handle. Preserve any stylization (e.g. `'Los`) in
  the *description* and *body*, never the identifier or filename.
- Don't mistake a built-in for a missing skill. If it appears in the menu but has
  no file anywhere, it ships inside the `claude` binary.
- A `~/.claude/agents/<name>.md` can be a **symlink** into a project repo — it
  still loads, and now it's version-controlled (same trick as skills/commands).
  If the agent reads repo docs, give it an **absolute** repo-root in its prompt so
  it resolves them from any cwd, not just inside the repo.
